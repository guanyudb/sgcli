"""Databricks Serverless GPU CLI package."""

__version__ = "0.0.5"
__git_sha__ = "4b52b85aeadef3976e1b90be64482b6b70151d59"
