"""Display utilities for CLI output formatting.

This module contains functions for formatting and displaying CLI output,
including status information, run tables, and YAML configurations.
"""

from __future__ import annotations

import concurrent.futures
import datetime
import logging
import time
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

from databricks.sdk import WorkspaceClient
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from cli.utils import get_workspace_client

if TYPE_CHECKING:
    from cli.jobs_api_client import JobsApiClient

log = logging.getLogger(__name__)


def _format_timestamp(timestamp: int) -> str:
    """Format timestamp from milliseconds to human-readable string.

    Args:
        timestamp: Timestamp in milliseconds

    Returns:
        Formatted timestamp string (e.g., "2024-01-15 14:30 PST")
    """
    # Convert from milliseconds to datetime
    dt = datetime.datetime.fromtimestamp(timestamp / 1000.0)
    # Format as local time
    formatted_timestamp = dt.strftime("%Y-%m-%d %H:%M %Z").strip()
    if not formatted_timestamp.endswith("PT") and not formatted_timestamp.endswith("UTC"):
        # Add timezone if not already present
        if time.daylight:
            tz = time.tzname[1]
        else:
            tz = time.tzname[0]
        formatted_timestamp = f"{dt.strftime('%Y-%m-%d %H:%M')} {tz}"
    return formatted_timestamp


def _format_duration(milliseconds: int) -> str:
    """Format duration from milliseconds to human-readable string.

    Args:
        milliseconds: Duration in milliseconds

    Returns:
        Formatted duration string (e.g., "2h 15m 30s", "45m 12s", "30s")
    """
    seconds = milliseconds / 1000.0
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    parts = []
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if secs > 0 or not parts:  # Always show seconds if no other parts
        parts.append(f"{secs}s")

    return " ".join(parts)


def _strip_user_prefix_from_experiment(experiment_name: str) -> str:
    """Strip /Users/{username}/ prefix from experiment name if present.

    MLflow experiment names often include the full path like "/Users/{username}/experiment_name".
    This function extracts just the experiment name for cleaner display.

    Args:
        experiment_name: Full experiment name (e.g., "/Users/john.doe/my_experiment" or "my_experiment")

    Returns:
        Experiment name without user prefix (e.g., "my_experiment")
    """
    if experiment_name != "N/A" and experiment_name.startswith("/Users/"):
        parts = experiment_name.split("/", 3)
        if len(parts) >= 4:
            return parts[3]
    return experiment_name


def _format_status_box(
    run_id: str,
    status_info: Dict[str, Any],
    attempt_number: Optional[int] = None,
    workspace_url: str = "",
    workspace_id: str = "",
    client: Optional["JobsApiClient"] = None,
) -> str:
    """Format status information into a rich table display.

    Args:
        run_id: The run ID
        status_info: Status information dict from Jobs API SDK
        attempt_number: Number of retry attempts for the run
        workspace_url: Databricks workspace URL for hyperlinks
        workspace_id: Workspace ID for constructing job run URLs
        client: JobsApiClient instance for fetching MLflow info

    Returns:
        Formatted string with table display
    """
    # Determine status from lifecycle and result states
    state = status_info.get("state") or {}
    lifecycle_state = state.get("life_cycle_state") or "UNKNOWN"
    result_state = state.get("result_state") or ""

    # Combine states for a meaningful status
    # TODO: Break this out into a function and handle all states in a unified way.
    if result_state:
        status = result_state  # CANCELED, FAILED, SUCCESS, etc.
    else:
        status = lifecycle_state  # PENDING, RUNNING, TERMINATING, etc.

    # Format submission time
    start_time = status_info.get("start_time")
    if start_time:
        submitted = _format_timestamp(start_time)
    else:
        submitted = "N/A"

    # Calculate duration
    end_time = status_info.get("end_time")
    if start_time:
        if end_time:
            # Terminal state: use end_time
            duration_ms = end_time - start_time
        else:
            # Active state: use current time
            current_time_ms = int(time.time() * 1000)
            duration_ms = current_time_ms - start_time
        duration = _format_duration(duration_ms)
    else:
        duration = "N/A"

    # Always show retries, default to 0
    retries = attempt_number if attempt_number is not None else 0

    # Create Run ID hyperlink
    run_id_display = str(run_id)
    if workspace_url and workspace_id:
        job_run_url = f"{workspace_url}/jobs/runs/{run_id}?o={workspace_id}"
        run_id_display = f"[link={job_run_url}]{run_id}[/link]"

    # Get MLflow experiment and run info
    experiment_display = "N/A"
    mlflow_url_display = "N/A"
    if client:
        try:
            run_output = client.get_run_output(run_id)
            run_info = run_output.get("gen_ai_compute_output", {}).get("run_info", {})
            mlflow_experiment_id = run_info.get("mlflow_experiment_id", None)
            mlflow_run_id = run_info.get("mlflow_run_id", None)

            # Get experiment name from tasks
            experiment_name = "N/A"
            tasks = status_info.get("tasks", [])
            if tasks and len(tasks) > 0:
                gen_ai_task = tasks[0].get("gen_ai_compute_task", {})
                experiment_name = gen_ai_task.get("mlflow_experiment_name", "N/A")
                experiment_name = _strip_user_prefix_from_experiment(experiment_name)

            # Create experiment hyperlink
            if mlflow_experiment_id and experiment_name != "N/A" and workspace_url:
                experiment_url = f"{workspace_url}/ml/experiments/{mlflow_experiment_id}"
                experiment_display = f"[link={experiment_url}]{experiment_name}[/link]"
            else:
                experiment_display = experiment_name

            # Create MLflow run URL
            if mlflow_run_id and mlflow_experiment_id and workspace_url:
                log_artifacts_path = "logs/node_0"
                mlflow_url = f"{workspace_url}/ml/experiments/{mlflow_experiment_id}/runs/{mlflow_run_id}/artifacts/{log_artifacts_path}"
                # Create a short clickable link - show just the run_id (last 8 chars)
                short_id = mlflow_run_id[-8:] if len(mlflow_run_id) > 8 else mlflow_run_id
                mlflow_url_display = f"[link={mlflow_url}]...{short_id}[/link]"
        except Exception as e:
            log.debug(f"Failed to get experiment info for run {run_id}: {e}")
            experiment_display = "N/A"
            mlflow_url_display = "N/A"

    # Create rich table
    table = Table(show_header=True, header_style="bold")
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value", style="white")

    table.add_row("Run ID", run_id_display)
    table.add_row("Status", status)
    table.add_row("Submitted", submitted)
    table.add_row("Retries", str(retries))
    table.add_row("Duration", duration)
    table.add_row("Experiment", experiment_display)
    table.add_row("MLflow URL", mlflow_url_display)

    # Render table to string
    console = Console()
    with console.capture() as capture:
        console.print(table)

    return capture.get()


def _display_foreach_sweep_status(
    client: "JobsApiClient",
    run_id: str,
    status_info: Dict[str, Any],
    workspace_url: str = "",
    workspace_id: str = "",
) -> None:
    """Display status for a ForEach sweep with a table of iteration tasks.

    Args:
        client: JobsApiClient instance
        run_id: The run ID of the ForEach sweep
        status_info: Status information from get_workload_status
        workspace_url: Databricks workspace URL for hyperlinks
        workspace_id: Workspace ID for constructing job run URLs
    """
    console = Console()

    # Get full run details to access iteration task information
    w = client._get_workspace_client()
    try:
        run = w.jobs.get_run(run_id=int(run_id))
    except Exception as e:
        log.error("Failed to get run details: %s", e)
        return

    # Extract ForEach stats for summary
    for_each_stats = (status_info.get("for_each_stats") or {}).get("task_run_stats", {})

    # Create Run ID hyperlink
    run_id_display = run_id
    if workspace_url and workspace_id:
        job_run_url = f"{workspace_url}/jobs/runs/{run_id}?o={workspace_id}"
        run_id_display = f"[link={job_run_url}]{run_id}[/link]"

    # Display summary box
    console.print(f"\n[bold]Sweep Run ID:[/bold] {run_id_display}")
    console.print(f"[bold]Status:[/bold] {(status_info.get('state') or {}).get('life_cycle_state', 'UNKNOWN')}")

    if for_each_stats:
        console.print(f"[bold]Total Iterations:[/bold] {for_each_stats.get('total_iterations', 0)}")
        console.print(f"[bold]Completed:[/bold] {for_each_stats.get('completed_iterations', 0)}")
        console.print(f"[bold]Succeeded:[/bold] {for_each_stats.get('succeeded_iterations', 0)}")
        console.print(f"[bold]Failed:[/bold] {for_each_stats.get('failed_iterations', 0)}")
        console.print(f"[bold]Active:[/bold] {for_each_stats.get('active_iterations', 0)}")

    console.print("\n[bold]Sweep Tasks:[/bold]")

    # Create table for iteration tasks
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Task Name", style="dim")
    table.add_column("Task Run ID")
    table.add_column("Status")
    table.add_column("MLflow Experiment")

    # Find the ForEach task and get its run_id
    foreach_task_run_id = None
    if run.tasks:
        for task in run.tasks:
            if hasattr(task, "for_each_task") and task.for_each_task:
                foreach_task_run_id = task.run_id
                break

    # Fetch the ForEach task run to get iterations
    if foreach_task_run_id:
        try:
            foreach_run = w.jobs.get_run(run_id=int(foreach_task_run_id))

            # Iterations are in the 'iterations' field
            if hasattr(foreach_run, "iterations") and foreach_run.iterations:
                for iteration in foreach_run.iterations:
                    task_name = getattr(iteration, "task_key", "N/A")
                    task_run_id = getattr(iteration, "run_id", "N/A")

                    # Get status
                    task_status = "UNKNOWN"
                    if hasattr(iteration, "state") and iteration.state:
                        if hasattr(iteration.state, "result_state") and iteration.state.result_state:
                            task_status = iteration.state.result_state.value
                        elif hasattr(iteration.state, "life_cycle_state") and iteration.state.life_cycle_state:
                            task_status = iteration.state.life_cycle_state.value

                    # Create Task Run ID hyperlink
                    task_run_id_display = str(task_run_id)
                    if task_run_id != "N/A" and workspace_url and workspace_id:
                        task_job_run_url = f"{workspace_url}/jobs/runs/{task_run_id}?o={workspace_id}"
                        task_run_id_display = f"[link={task_job_run_url}]{task_run_id}[/link]"

                    # Get MLflow experiment from gen_ai_compute_task
                    mlflow_experiment = "N/A"
                    mlflow_experiment_display = "N/A"
                    if hasattr(iteration, "gen_ai_compute_task") and iteration.gen_ai_compute_task:
                        gen_ai_task = iteration.gen_ai_compute_task
                        if hasattr(gen_ai_task, "mlflow_experiment_name"):
                            mlflow_experiment = gen_ai_task.mlflow_experiment_name
                            experiment_name = _strip_user_prefix_from_experiment(mlflow_experiment)

                            # Try to get MLflow experiment ID and create hyperlink
                            mlflow_experiment_display = experiment_name
                            try:
                                task_run_output = client.get_run_output(str(task_run_id))
                                task_run_info = task_run_output.get("gen_ai_compute_output", {}).get("run_info", {})
                                mlflow_experiment_id = task_run_info.get("mlflow_experiment_id", None)
                                if mlflow_experiment_id and workspace_url:
                                    experiment_url = f"{workspace_url}/ml/experiments/{mlflow_experiment_id}"
                                    mlflow_experiment_display = f"[link={experiment_url}]{experiment_name}[/link]"
                            except Exception as e:
                                log.debug(f"Failed to get MLflow URL for task run {task_run_id}: {e}")

                    table.add_row(task_name, task_run_id_display, task_status, mlflow_experiment_display)
            else:
                console.print("[yellow]No iteration tasks found. Tasks may still be initializing.[/yellow]")
        except Exception as e:
            log.error("Failed to fetch iteration tasks: %s", e)
            console.print("[red]Error fetching iteration task details.[/red]")
    else:
        console.print("[yellow]ForEach task not found.[/yellow]")

    console.print(table)
    console.print()


def _fetch_and_display_yaml_config(yaml_path: str) -> None:
    """Fetch and display YAML config from workspace.

    Args:
        yaml_path: Path to YAML file in workspace (e.g., /Workspace/path/to/config.yaml)

    Raises:
        NotFound: If the YAML config file doesn't exist in workspace
        PermissionDenied: If access to the file is denied
        UnicodeDecodeError: If the file content is not valid UTF-8
        Exception: For any other unexpected errors during fetch/display
    """
    w: WorkspaceClient = get_workspace_client()

    # Read the file from workspace
    log.debug("Fetching YAML config from: %s", yaml_path)
    with w.workspace.download(yaml_path) as f:
        yaml_content = f.read().decode("utf-8")
    console = Console()

    # Create syntax-highlighted YAML
    yaml_syntax = Syntax(yaml_content, "yaml", theme="monokai", line_numbers=False)

    # Display in a panel
    console.print()
    console.print(
        Panel(
            yaml_syntax,
            title="[bold cyan]Training Configuration[/bold cyan]",
            border_style="cyan",
        )
    )
    console.print()


def display_runs_table(
    runs: List[Dict[str, Any]],
    client: "JobsApiClient",
    workspace_url: str,
    has_sweeps: bool,
    workspace_id: str,
) -> None:
    """Display submitted runs in a formatted table.

    Args:
        runs: List of run dictionaries from Jobs API
        client: JobsApiClient instance for fetching run details
        workspace_url: Databricks workspace URL for MLflow links
        has_sweeps: Whether any sweeps are present in the runs
        workspace_id: Workspace ID for constructing job run URLs
    """
    console = Console()

    # Display sweep helper message if sweeps detected
    if has_sweeps:
        console.print(
            "[yellow]Note: Sweep detected in listed runs. "
            "To see sweep task details, use the 'get status' command with the sweep run ID.[/yellow]\n"
        )

    # Pre-fetch all run outputs in parallel (I/O bound - network calls)
    def _fetch_run_output(run: Dict[str, Any]) -> Tuple[str, Optional[Dict[str, Any]]]:
        run_id = str(run.get("run_id", "N/A"))
        try:
            return run_id, client.get_run_output(run_id)
        except Exception as e:
            log.debug(f"Failed to get run output for run {run_id}: {e}")
            return run_id, None

    max_workers = min(len(runs), 10)
    run_outputs: Dict[str, Optional[Dict[str, Any]]] = {}
    if runs:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            for run_id, output in executor.map(_fetch_run_output, runs):
                run_outputs[run_id] = output

    # Display runs in a table
    table = Table(title=f"Your Submitted Runs (showing {len(runs)})")

    table.add_column("Run ID", style="cyan", no_wrap=True)
    table.add_column("Experiment", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Started", style="blue")
    table.add_column("Duration", style="magenta")
    table.add_column("MLflow URL", style="bright_blue", no_wrap=True)

    for run in runs:
        run_id = str(run.get("run_id", "N/A"))

        # Create Run ID hyperlink to job run page
        run_id_display = "N/A"
        if run_id != "N/A" and workspace_id:
            job_run_url = f"{workspace_url}/jobs/runs/{run_id}?o={workspace_id}"
            run_id_display = f"[link={job_run_url}]{run_id}[/link]"
            if run.get("is_foreach_sweep"):
                run_id_display += " (sweep)"
        else:
            run_id_display = run_id
            if run.get("is_foreach_sweep"):
                run_id_display = f"{run_id} (sweep)"

        # Get MLflow experiment name from task config
        experiment_name = "N/A"
        try:
            tasks = run.get("tasks", [])
            if tasks and len(tasks) > 0:
                gen_ai_task = tasks[0].get("gen_ai_compute_task", {})
                experiment_name = gen_ai_task.get("mlflow_experiment_name", run.get("run_name", "N/A"))
                experiment_name = _strip_user_prefix_from_experiment(experiment_name)
        except Exception as e:
            log.debug(f"Failed to get experiment name for run {run_id}: {e}")
            experiment_name = run.get("run_name", "N/A")

        # Get status
        state = run.get("state", {})
        life_cycle_state = state.get("life_cycle_state", "UNKNOWN")
        result_state = state.get("result_state", "")

        if result_state:
            status = f"{life_cycle_state}/{result_state}"
        else:
            status = life_cycle_state

        # Format start time
        start_time = run.get("start_time")
        if start_time:
            start_str = _format_timestamp(start_time)
        else:
            start_str = "N/A"

        # Calculate duration
        end_time = run.get("end_time")
        if start_time:
            if end_time:
                duration_ms = end_time - start_time
                duration_str = _format_duration(duration_ms)
            else:
                # Still running
                current_time_ms = int(time.time() * 1000)
                duration_ms = current_time_ms - start_time
                duration_str = _format_duration(duration_ms) + " (running)"
        else:
            duration_str = "N/A"

        # Get MLflow/UI URL from metadata and create experiment hyperlink
        log_artifacts_path = "logs/node_0"
        mlflow_url_display = "N/A"
        experiment_display = experiment_name
        run_output = run_outputs.get(run_id)
        if run_output is not None:
            try:
                run_info = run_output.get("gen_ai_compute_output", {}).get("run_info", {})
                mlflow_run_id = run_info.get("mlflow_run_id", None)
                mlflow_experiment_id = run_info.get("mlflow_experiment_id", None)

                if mlflow_run_id and mlflow_experiment_id:
                    mlflow_url = f"{workspace_url}/ml/experiments/{mlflow_experiment_id}/runs/{mlflow_run_id}/artifacts/{log_artifacts_path}"
                    # Create a short clickable link - show just the run_id (last 8 chars)
                    short_id = mlflow_run_id[-8:] if len(mlflow_run_id) > 8 else mlflow_run_id
                    mlflow_url_display = f"[link={mlflow_url}]...{short_id}[/link]"

                    # Create experiment hyperlink
                    if experiment_name != "N/A":
                        experiment_url = f"{workspace_url}/ml/experiments/{mlflow_experiment_id}"
                        experiment_display = f"[link={experiment_url}]{experiment_name}[/link]"
            except Exception as e:
                log.debug(f"Failed to get mlflow URL for run {run_id}: {e}")
                mlflow_url_display = "N/A"

        table.add_row(run_id_display, experiment_display, status, start_str, duration_str, mlflow_url_display)

    console.print(table)


def display_pool_info_table(
    pool_data: List[Dict[str, Any]],
    workspace_url: str,
    workspace_id: str,
) -> None:
    """Display GPU pool information in a Rich table.

    Args:
        pool_data: List of pool dictionaries with reserved_pool info
        workspace_url: Base workspace URL (e.g., https://example.databricks.com)
        workspace_id: Workspace ID for URL construction
    """
    console = Console()

    if not pool_data:
        console.print("[yellow]No reserved GPU pools available.[/yellow]")
        return

    # Display workspace pool page URL
    pool_page_url = f"{workspace_url}/compute/gpu-pools?o={workspace_id}"
    console.print(f"\nGPU Pools for Workspace: [link={pool_page_url}]{pool_page_url}[/link]")

    # Create table
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Pool ID", style="white", no_wrap=False)
    table.add_column("Pool Name", style="white", no_wrap=False)
    table.add_column("GPU Type", style="green", no_wrap=True)
    table.add_column("Total GPUs", style="yellow", justify="right")
    table.add_column("Used GPUs", style="yellow", justify="right")
    table.add_column("Idle GPUs", style="yellow", justify="right")

    # Add rows for each pool
    for pool_opt in pool_data:
        pool = pool_opt["reserved_pool"]
        pool_id = pool["id"]
        pool_name = pool["name"]

        # Map GPU type to display name
        gpu_type = pool_opt.get("gpu_type", "")
        if gpu_type == "h100_80gb":
            gpu_type_display = "H100"
        elif gpu_type == "a10":
            gpu_type_display = "A10"
        else:
            gpu_type_display = gpu_type

        total_gpus = str(pool.get("total_gpus", "N/A"))
        used_gpus = str(pool.get("used_gpus", "N/A"))
        idle_gpus = str(pool.get("idle_gpus", "N/A"))

        table.add_row(
            pool_id,
            pool_name,
            gpu_type_display,
            total_gpus,
            used_gpus,
            idle_gpus,
        )

    console.print(table)
