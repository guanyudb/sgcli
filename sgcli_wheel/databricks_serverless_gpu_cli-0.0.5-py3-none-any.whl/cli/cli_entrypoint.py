#!/usr/bin/env python3
"""
CLI entry point for Skyrun (sgcli).
"""

from __future__ import annotations

import argparse
import copy
import logging
import shutil
import sys
import os
import tempfile
import time
from dataclasses import dataclass
from difflib import get_close_matches
from pathlib import Path
from pydantic import TypeAdapter, ValidationError
from typing import Any, Dict, Optional, Union, Tuple, Literal, List
from omegaconf import OmegaConf, DictConfig
from contextlib import contextmanager

import yaml
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound, PermissionDenied
from rich.console import Console

from cli import __version__
from cli.version import get_changelog
from cli.jobs_api_client import (
    JobsApiClient,
    _is_air_workload,
    _attempt_auto_login,
)
from cli.compute import GPUType
from cli.cli_display import (
    _format_status_box,
    _display_foreach_sweep_status,
    _fetch_and_display_yaml_config,
    display_runs_table,
)
from cli.docker_utils import maybe_wait_for_docker_image_cache
from cli.image_registration import (
    ImageClient,
    ImageStatus,
    ImagePolicyHandler,
    parse_image_policy,
    setup_docker_credentials_interactive,
)
from cli.cli_output import (
    RichLoggingHandler,
    RichLoggingFormatter,
    print_exception,
    print_success,
    print_error,
    print_warning,
    print_info,
)
from cli.log_streaming import (
    monitor_and_stream_logs,
    print_all_logs,
    TERMINAL_STATES,
    TERMINAL_RESULT_STATES,
    download_all_node_logs,
    display_debug_logs,
)
from cli.yaml_config import (
    YamlConfig,
    WorkspaceConfig,
    EnvironmentConfig,
    ComputeConfig,
    CodeSourceConfig,
    SnapshotSourceConfig,
    DockerImageConfig,
)
from cli.yaml_help import display_yaml_help
from cli.utils import (
    find_host_for_profile,
    get_cli_launch_dir,
    get_current_user_email,
    upload_python_script_as_zip,
    upload_file_to_workspace,
    upload_file_to_volume,
    ScriptType,
    get_git_sha,
    has_uncommitted_changes,
    has_uncommitted_changes_in_paths,
    detect_remote_name,
    check_workspace_file_exists,
    check_volume_file_exists,
    get_compute_options,
    get_workspace_client,
    log_auth_context,
    retry,
    is_http_5xx,
    upload_parameters_as_yaml,
    validate_include_paths_exist,
    create_git_archive_snapshot,
    fetch_branch_sha,
    is_git_repository,
    create_plain_tarball,
)

# ---------------- Custom Exceptions ----------------


class YamlValidationError(Exception):
    """Raised when YAML validation, parsing, or configuration fails."""

    pass


class PathValidationError(Exception):
    """Raised when path validation fails (not a file/directory, wrong type, etc)."""

    pass


# ---------------- Constants ----------------

DEFAULT_ENV_SYNC_TIMEOUT_SECONDS = 300  # 5 minutes
MAX_GPU_PER_NODE = 8

# ---------------- Logging ----------------


def configure_logging(verbose_count: int) -> None:
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)  # don't block; handlers decide

    for h in list(root.handlers):
        root.removeHandler(h)

    # Use Rich-based colored logging handler
    console = RichLoggingHandler()
    if verbose_count >= 1:
        level = logging.DEBUG
    else:
        level = logging.INFO
    console.setLevel(level)
    console.setFormatter(RichLoggingFormatter("[%(levelname)s] %(message)s"))

    root.addHandler(console)

    # Suppress noisy SDK internals regardless of verbosity
    logging.getLogger("databricks.sdk").setLevel(logging.WARNING)


log = logging.getLogger("sgcli")


# ---------------- Helpers ----------------


def _set_profile_env(profile: Optional[str]) -> Optional[str]:
    """Temporarily set DATABRICKS_CONFIG_PROFILE environment variable.

    Args:
        profile: The profile name to set, or None to use default behavior.

    Returns:
        The original profile value (or None if it wasn't set).

    Note:
        This function saves the original value and provides a way to restore it.
        Use with try/finally to ensure restoration.
    """
    if not profile:
        return None
    # Save original value (if any)
    original_profile = os.environ.get("DATABRICKS_CONFIG_PROFILE")
    if not original_profile:
        log.debug("No existing Databricks profile found: DATABRICKS_CONFIG_PROFILE is unset")
    os.environ["DATABRICKS_CONFIG_PROFILE"] = profile
    return original_profile


def _restore_profile_env(original_profile: Optional[str]) -> None:
    """Restore DATABRICKS_CONFIG_PROFILE environment variable.

    Args:
        original_profile: The original profile value to restore, or None to delete the key.
    """
    if original_profile is not None:
        os.environ["DATABRICKS_CONFIG_PROFILE"] = original_profile
    elif "DATABRICKS_CONFIG_PROFILE" in os.environ:
        del os.environ["DATABRICKS_CONFIG_PROFILE"]


def _configure_workspace_auth(workspace_host: str) -> None:
    """Configure authentication for Databricks workspace.

    Sets up the DATABRICKS_HOST environment variable. Also tries to find a matching
    profile in databrickscfg and sets DATABRICKS_CONFIG_PROFILE if found.

    Args:
        workspace_host: The workspace host URL to authenticate to.
    """
    from cli.utils import find_profile_for_host

    # Ensure host has https:// prefix
    host = workspace_host
    if not host.startswith("http://") and not host.startswith("https://"):
        host = f"https://{host}"

    # Set the host environment variable
    os.environ["DATABRICKS_HOST"] = host

    # Try to find a matching profile and set DATABRICKS_CONFIG_PROFILE
    profile = find_profile_for_host(host)
    if profile:
        os.environ["DATABRICKS_CONFIG_PROFILE"] = profile
        log.debug("Set DATABRICKS_CONFIG_PROFILE=%s for workspace %s", profile, host)
    else:
        print_error(f"Cannot find profile in databrickscfg matching specified {host}.")
        if not _attempt_auto_login(workspace_host):
            raise RuntimeError(
                f"Cannot login to {host}. Please run 'databricks auth login --host {host}' to authenticate."
            )


@retry(
    exceptions_to_check=Exception,
    tries=3,
    delay_s=1,
    backoff_s=2,
    logger=log,
    log_level=logging.DEBUG,
    retry_if=is_http_5xx,
)
def update_mlflow_run_name(mlflow_run_id: str, run_name: str) -> None:
    w = WorkspaceClient()
    w.api_client.do(
        "POST",
        "/api/2.0/mlflow/runs/update",
        body={"run_id": mlflow_run_id, "run_name": run_name},
    )


def _update_mlflow_run_name(
    client: JobsApiClient,
    run_id: str,
    run_name: str,
    max_wait_seconds: int = 10,
    poll_interval_seconds: int = 1,
    max_api_retries: int = 3,
) -> None:
    """Poll for MLflow run ID and update the run name with retry logic.

    Args:
        client: JobsApiClient instance
        run_id: Jobs API run ID
        run_name: Desired MLflow run name
        max_wait_seconds: Maximum time to wait for MLflow run ID
        poll_interval_seconds: Polling interval in seconds
        max_api_retries: Maximum retries for API call
    """
    start_time = time.time()

    # Poll for MLflow run ID
    mlflow_run_id = None
    while (time.time() - start_time) < max_wait_seconds:
        try:
            run_output = client.get_run_output(run_id)
            run_info = run_output.get("gen_ai_compute_output", {}).get("run_info", {})
            mlflow_run_id = run_info.get("mlflow_run_id", None)

            if mlflow_run_id:
                log.debug(f"MLflow run started with ID: {mlflow_run_id}")
                break

        except Exception as e:
            log.debug(f"Polling for MLflow run ID: {e}")

        time.sleep(poll_interval_seconds)

    if not mlflow_run_id:
        log.debug(f"Timed out waiting for MLflow run ID after {max_wait_seconds}s")
        return

    log.debug(f"Updating MLflow run name to: {run_name}")
    update_mlflow_run_name(mlflow_run_id, run_name)


def _parse_run_id(run_id: str) -> str:
    """Validate and parse a run ID argument.

    Args:
        run_id: The run ID string to validate.

    Returns:
        str: The validated run ID.

    Raises:
        argparse.ArgumentTypeError: If run_id is not a numeric identifier.
    """
    if not run_id.isdigit():
        raise argparse.ArgumentTypeError(f"Invalid run-id '{run_id}'. Expected a numeric identifier.")
    return run_id


def _require_file_exists(p: Path) -> Path:
    """Validate that a file path exists and is a file.

    Args:
        p: The path to validate.

    Returns:
        Path: The validated path.

    Raises:
        argparse.ArgumentTypeError: If path doesn't exist or is not a file.
    """
    if not p.exists():
        raise argparse.ArgumentTypeError(f"File not found: {p}")
    if not p.is_file():
        raise argparse.ArgumentTypeError(f"Not a file: {p}")
    return p


def _resolve_project_root_path(raw: str, yaml_dir: Path) -> Path:
    """Resolve a path that may use the project_root/ prefix.

    Paths starting with 'project_root/' are resolved relative to the YAML file's directory.
    Other relative paths are also resolved relative to the YAML directory.
    Absolute paths are returned as-is.

    Args:
        raw: The raw path string from the YAML file.
        yaml_dir: The directory containing the YAML file.

    Returns:
        Path: The resolved absolute or relative path.
    """
    raw = raw.strip()
    if raw.startswith("project_root/"):
        return yaml_dir / raw.replace("project_root/", "", 1)
    p = Path(raw)
    return p if p.is_absolute() else (yaml_dir / p)


# ---------------- YAML Override Utilities ----------------


def _parse_overrides(override_list: list[str]) -> Dict[str, str]:
    """Parse --override KEY=VALUE override arguments.

    Args:
        override_list: List of KEY=VALUE strings from command line.

    Returns:
        Dict[str, str]: Dictionary mapping dotted paths to new values.

    Raises:
        SystemExit: If any entry is malformed.
    """
    result: Dict[str, str] = {}
    for item in override_list:
        if "=" not in item:
            raise SystemExit(
                f"Invalid --override entry '{item}'. " f"Expected KEY=VALUE format (e.g., compute.gpus=32)."
            )
        key, value = item.split("=", 1)
        key = key.strip()
        if not key:
            raise SystemExit(f"Invalid --override entry '{item}'. Empty key.")
        result[key] = value
    return result


def _convert_override_value(new_value: str, old_value: Any, path: str) -> Any:
    """Convert string override value using Pydantic's type coercion."""
    if old_value is None:
        return new_value

    try:
        target_type = type(old_value)
        adapter = TypeAdapter(target_type)
        return adapter.validate_python(new_value)
    except Exception as e:
        raise YamlValidationError(
            f"Failed to convert override value for '{path}': "
            f"cannot convert '{new_value}' to {type(old_value).__name__}. "
            f"Error: {e}"
        )


def _apply_overrides_to_yaml_dict(yaml_dict: Dict[str, Any], overrides: Dict[str, str]) -> Dict[str, Any]:
    """Apply CLI overrides to YAML configuration dictionary.

    Supports dotted path notation (e.g., "compute.gpus", "environment.env_variables.MY_VAR").
    Logs each change and validates that the path exists in the YAML.

    Args:
        yaml_dict: The parsed YAML configuration dictionary
        overrides: Dict of dotted paths to new values (e.g., {"compute.gpus": "32"})

    Returns:
        Modified YAML dictionary with overrides applied (new copy, original unchanged)

    Raises:
        YamlValidationError: If an override path is invalid or doesn't exist in YAML
    """
    result = copy.deepcopy(yaml_dict)

    for path, new_value in overrides.items():
        parts = path.split(".")
        current = result
        for i, part in enumerate(parts[:-1]):
            if not isinstance(current, dict):
                raise YamlValidationError(
                    f"Invalid override path '{path}': " f"'{'.'.join(parts[:i])}' is not a dictionary"
                )
            if part not in current:
                # Check for close matches to detect typos
                available_keys = list(current.keys())
                close_matches = get_close_matches(part, available_keys, n=3, cutoff=0.6)

                if close_matches:
                    suggestion = f"Did you mean one of: {', '.join(close_matches)}?"
                else:
                    suggestion = f"Available fields: {', '.join(available_keys)}"

                raise YamlValidationError(
                    f"Invalid override path '{path}': "
                    f"field '{part}' not found in '{'.'.join(parts[:i]) or 'root'}'. "
                    f"{suggestion}"
                )
            current = current[part]

        final_field = parts[-1]
        if not isinstance(current, dict):
            raise YamlValidationError(
                f"Invalid override path '{path}': " f"'{'.'.join(parts[:-1])}' is not a dictionary"
            )

        if final_field not in current:
            # Check for close matches
            available_keys = list(current.keys())
            close_matches = get_close_matches(final_field, available_keys, n=3, cutoff=0.6)

            if close_matches:
                suggestion = f"Did you mean one of: {', '.join(close_matches)}?"
            else:
                suggestion = f"Available fields: {', '.join(available_keys)}"

            raise YamlValidationError(
                f"Invalid override path '{path}': "
                f"field '{final_field}' not found in '{'.'.join(parts[:-1]) or 'root'}'. "
                f"{suggestion}"
            )

        old_value = current[final_field]
        typed_new_value = _convert_override_value(new_value, old_value, path)
        current[final_field] = typed_new_value
        print_info(f"Override: changing {path} from {repr(old_value)} to {repr(typed_new_value)}")

    return result


def _load_with_bases(yaml_path: str, visited: Optional[set] = None) -> DictConfig:
    yaml_dir: Path = Path(yaml_path).parent
    resolved_path = Path(yaml_path).resolve()

    if visited is None:
        visited = set()
    if resolved_path in visited:
        raise YamlValidationError(f"Circular base reference detected in yaml composition: {resolved_path}")
    visited.add(resolved_path)

    try:
        cfg = OmegaConf.load(yaml_path)
    except FileNotFoundError:
        raise FileNotFoundError(f"Base file not found for use in yaml composition: {resolved_path}")

    if "_bases_" in cfg:
        bases = cfg.pop("_bases_")
        merged = OmegaConf.create()
        for base_path in bases:
            resolved_base = yaml_dir / base_path
            base_cfg = _load_with_bases(resolved_base, visited)  # recursive
            merged = OmegaConf.merge(merged, base_cfg)
        # Final config overrides bases
        merged = OmegaConf.merge(merged, cfg)
        return merged

    return cfg


@contextmanager
def create_temp_yaml_file(parameters: DictConfig, no_interpolation: Optional[bool] = None) -> str:
    """Create temporary YAML file with parameters.

    Args:
        parameters: Dictionary containing hyperparameters/config.
        no_interpolation: Whether to resolve the parameters using OmegaConf.


    Yields:
        str: Path to the temporary YAML file.
    """
    if no_interpolation is None:
        if hasattr(parameters, "no_interpolation"):
            no_interpolation = parameters.no_interpolation
        else:
            no_interpolation = False

    parameters_dict = OmegaConf.to_container(parameters, resolve=not no_interpolation)

    # Create temporary YAML file with parameters
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
        yaml.safe_dump(parameters_dict, f, default_flow_style=False, sort_keys=False)
        temp_path = f.name

    try:
        yield temp_path
    finally:
        # Clean up the temporary file
        try:
            os.unlink(temp_path)
        except FileNotFoundError:
            pass  # File already deleted


# ---------------- Config model & validation ----------------


@dataclass(frozen=True)
class RunConfig:
    """Configuration for a training run parsed from YAML."""

    experiment_name: str
    requirements_txt: Optional[Union[Path, str]]  # Path for local workflow, str for git workflow
    script: Path
    script_type: ScriptType
    gpus: int
    gpu_type: str
    gpu_node_pool_id: Optional[str]  # Optional GPU node pool ID for compute placement
    env_variables: Dict[str, str]  # Regular env vars from YAML env_variables
    env_variables_secrets: Dict[
        str, str
    ]  # Secret refs from YAML env_variables_secrets header; maps "ENV_VAR_NAME" to "scope/key"
    max_retries: int
    timeout_seconds: int
    workspace_host: Optional[str]  # Workspace host URL from Yaml field workspace.host
    parameters: Optional[Dict[str, Any]]
    idempotency_token: Optional[str]  # Optional idempotency token for submission
    docker_image_url: Optional[str]  # Custom docker image URL from environment.docker_image.url
    runtime_version: Optional[str]  # Runtime version from requirements.yaml ("3" or "4")
    run_name: Optional[str]  # Custom MLflow run name
    code_source: "InternalCodeSource"  # New discriminated union for code source
    raw_dict: Dict[str, Any]
    no_interpolation: Optional[bool]
    experiment_directory: Optional[str]  # Custom experiment directory (overrides default /Users/{user_name})
    grant_permissions: Optional[List[Any]]  # List of permission grants (PermissionGrant objects from yaml_config)
    budget_policy_id: Optional[str]  # Optional budget policy UUID to assign to this workload


@dataclass(frozen=True)
class InternalSnapshotSource:
    """Internal representation of snapshot source after validation."""

    repo_path: Path  # resolved absolute path
    remote_volume: Optional[str]
    git_commit: Optional[str]
    git_branch: Optional[str]
    include_paths: Optional[List[str]]
    allow_uncommitted: bool
    remote_alias: Optional[str]
    use_remote_head: bool


@dataclass(frozen=True)
class InternalCodeSource:
    """Discriminated union for internal use."""

    type: Literal["snapshot", "none"]
    snapshot: Optional[InternalSnapshotSource] = None


def _get_parent_model(error_loc: Tuple[Any, ...]) -> Optional[type]:
    """Get the Pydantic model class for a given error location.

    Args:
        error_loc: Tuple of field names from Pydantic error (e.g., ('workspace', 'hast'))

    Returns:
        The Pydantic model class if found, None otherwise.
    """
    if not error_loc:
        return YamlConfig

    # Map top-level field names to their model classes
    field_to_model = {
        "workspace": WorkspaceConfig,
        "environment": EnvironmentConfig,
        "compute": ComputeConfig,
        "code_source": CodeSourceConfig,
    }

    # For nested fields within code_source
    if len(error_loc) >= 2:
        if error_loc[0] == "code_source":
            if error_loc[1] == "snapshot":
                return SnapshotSourceConfig
        elif error_loc[0] == "environment" and error_loc[1] == "docker_image":
            return DockerImageConfig

    # For top-level fields or direct children
    if len(error_loc) >= 1:
        parent_field = str(error_loc[0])
        return field_to_model.get(parent_field, YamlConfig)

    return YamlConfig


def _validate_yaml_structure(d: Dict[str, Any], yaml_path: Path) -> YamlConfig:
    """Validate YAML structure and types using Pydantic.

    This handles:
    - Unknown field detection (via extra='forbid')
    - Type validation (str, int, dict, etc.)
    - GPU count validation (multiples of GPUs per node)
    - Field format validation (remote_volume, etc.)

    Args:
        d: Dictionary parsed from YAML file.
        yaml_path: Path to the YAML file (for error messages).

    Returns:
        YamlConfig: Validated Pydantic model.

    Raises:
        YamlValidationError: If validation fails with user-friendly error messages.
    """
    try:
        return YamlConfig.model_validate(d)
    except ValidationError as e:
        # Convert Pydantic errors to user-friendly messages
        error_lines = []
        for error in e.errors():
            field_path = ".".join(str(loc) for loc in error["loc"]) if error["loc"] else "root"

            # Provide helpful error message for unknown fields
            if error["type"] == "extra_forbidden":
                unknown_field = str(error["loc"][-1]) if error["loc"] else "unknown"
                # Get the parent model to show available fields
                parent_model = _get_parent_model(error["loc"])
                if parent_model:
                    available_fields = sorted(parent_model.model_fields.keys())
                    error_lines.append(
                        f"  - {field_path}: Unknown field '{unknown_field}'. "
                        f"Available fields are: {', '.join(repr(f) for f in available_fields)}"
                    )
                else:
                    error_lines.append(f"  - {field_path}: {error['msg']}")
            else:
                error_lines.append(f"  - {field_path}: {error['msg']}")

        raise YamlValidationError(f"YAML validation failed for '{yaml_path.name}':\n" + "\n".join(error_lines))


def _validate_git_specific_fields(
    git_branch: Optional[str],
    git_commit: Optional[str],
    include_paths: Optional[List[str]],
    resolved_path: Path,
    is_git_repo: bool,
) -> None:
    """Validate that git-specific fields are only used with git repositories.

    Args:
        git_branch: Git branch field value
        git_commit: Git commit field value
        include_paths: Include paths field value
        resolved_path: Resolved path to the repository
        is_git_repo: Whether the path is a git repository

    Raises:
        ValueError: If git-specific fields are used with non-git repository
    """
    git_specific_fields = []

    if git_branch is not None:
        git_specific_fields.append("git_branch")
    if git_commit is not None:
        git_specific_fields.append("git_commit")
    if include_paths is not None:
        git_specific_fields.append("include_paths")

    if not is_git_repo and git_specific_fields:
        fields_list = "\n".join(f"  - {field}" for field in git_specific_fields)
        raise ValueError(
            f"The directory '{resolved_path}' is not a git repository.\n"
            f"The following fields are only supported for git repositories:\n"
            f"{fields_list}\n"
            f"Please remove these fields from your configuration or initialize a git repository."
        )


def _validate_and_convert_code_source(yaml_config: YamlConfig, yaml_dir: Path) -> InternalCodeSource:
    """Validate and convert code_source to internal representation.

    Args:
        yaml_config: Validated YAML configuration.
        yaml_dir: Directory containing the YAML file (for resolving relative paths).

    Returns:
        InternalCodeSource: Internal representation of code source configuration.

    Raises:
        FileNotFoundError: If path does not exist.
        PathValidationError: If path is not a directory.
    """
    if yaml_config.code_source is not None:
        if yaml_config.code_source.type == "snapshot":
            snapshot_cfg = yaml_config.code_source.snapshot
            assert snapshot_cfg is not None  # validated by Pydantic

            # Resolve repo_path (handle project_root/ prefix and environment variables)
            path_str = snapshot_cfg.repo_path
            # Expand environment variables like $HOME, ${HOME}, $USER, etc.
            path_str = os.path.expandvars(path_str)
            if path_str.startswith("project_root/"):
                resolved_path = yaml_dir / path_str.removeprefix("project_root/")
            else:
                resolved_path = Path(path_str)

            # Validate path exists and is directory
            if not resolved_path.exists():
                raise FileNotFoundError(f"repo_path does not exist: {resolved_path}")
            if not resolved_path.is_dir():
                raise PathValidationError(f"repo_path must be a directory: {resolved_path}")

            # Validate git-specific fields for non-git repositories
            is_git_repo = is_git_repository(resolved_path)
            _validate_git_specific_fields(
                git_branch=snapshot_cfg.git_branch,
                git_commit=snapshot_cfg.git_commit,
                include_paths=snapshot_cfg.include_paths,
                resolved_path=resolved_path,
                is_git_repo=is_git_repo,
            )

            return InternalCodeSource(
                type="snapshot",
                snapshot=InternalSnapshotSource(
                    repo_path=resolved_path.resolve(),
                    remote_volume=snapshot_cfg.remote_volume,
                    git_commit=snapshot_cfg.git_commit,
                    git_branch=snapshot_cfg.git_branch,
                    include_paths=snapshot_cfg.include_paths,
                    allow_uncommitted=snapshot_cfg.allow_uncommitted,
                    remote_alias=snapshot_cfg.remote_alias,
                    use_remote_head=snapshot_cfg.use_remote_head,
                ),
            )
    # No code source specified - workspace workflow
    else:
        return InternalCodeSource(type="none")


def _validate_script_file(yaml_config: YamlConfig, yaml_dir: Path) -> Tuple[Path, ScriptType]:
    """Validate script file exists and determine script type.

    For bash_script: validates file exists (workspace workflow).
    For command: creates temporary file with command content.

    Args:
        yaml_config: Validated YAML configuration.
        yaml_dir: Directory containing the YAML file (for resolving relative paths).

    Returns:
        Tuple of (resolved_script_path, script_type).

    Raises:
        FileNotFoundError: If script file not found (for workspace workflow).
        PathValidationError: If script path is not a file.
    """
    # Handle command field - create temporary script file
    if yaml_config.command:
        script_type = ScriptType.COMMAND

        return None, script_type

    # Handle bash_script
    script_type = ScriptType.BASH
    script_path = _resolve_project_root_path(yaml_config.bash_script, yaml_dir)

    if not script_path.exists():
        raise FileNotFoundError(
            f"bash_script: script not found at '{script_path}'. " f"Please check the path in your YAML configuration."
        )
    if not script_path.is_file():
        raise PathValidationError(
            f"bash_script: script must be a file, not a directory. "
            f"Path: '{script_path}'. Please check the path in your YAML configuration."
        )

    return script_path, script_type


def _parse_requirements_yaml(req_path: Path) -> str:
    """Parse requirements.yaml to extract and validate version field.

    This function only extracts the version field for runtime image selection.
    The requirements.yaml file itself is uploaded to the workspace and parsed
    on the worker side to support complex pip install scenarios (index URLs,
    local wheels, git repos, reference files, etc.).

    TODO: remove this function once AI Training natively supports environments.

    Args:
        req_path: Path to requirements.yaml file.

    Returns:
        Version string ("3" or "4")

    Raises:
        YamlValidationError: If file format is invalid or version is not supported.
    """
    import yaml

    try:
        with open(req_path, "r", encoding="utf-8") as f:
            req_data = yaml.safe_load(f)
    except Exception as e:
        raise YamlValidationError(f"Failed to parse requirements.yaml: {e}") from e

    if not isinstance(req_data, dict):
        raise YamlValidationError("requirements.yaml must contain a YAML dictionary")

    # Extract version field (default to 4 if not specified)
    version = req_data.get("version", "4")
    version_str = str(version)

    # Validate version is supported
    # TODO: Use safe flag to validate version so we don't have to hardcode the supported versions.
    supported_versions = ["3", "4"]
    if version_str not in supported_versions:
        raise YamlValidationError(
            f"Unsupported client image version '{version_str}' in requirements yaml {req_path}. "
            f"Supported client image versions: {', '.join(supported_versions)}"
        )

    # Validate dependencies field exists and is a list
    dependencies = req_data.get("dependencies", [])
    if not isinstance(dependencies, list):
        raise YamlValidationError("requirements.yaml 'dependencies' must be a list")

    return version_str


def _validate_requirements_file(
    yaml_config: YamlConfig, yaml_dir: Path
) -> tuple[Optional[Union[Path, str]], Optional[str]]:
    """Validate requirements.yaml file exists and parse version.

    Args:
        yaml_config: Validated YAML configuration.
        yaml_dir: Directory containing the YAML file (for resolving relative paths).

    Returns:
        Tuple of (requirements_yaml_path, version_string) where:
        - requirements_yaml_path: Path to requirements.yaml file (always local)
        - version_string: Extracted version from requirements.yaml ("3" or "4")
        Both are None if dependencies not specified.

    Raises:
        FileNotFoundError: If requirements.yaml file not found.
        PathValidationError: If requirements.yaml is not a file.
        YamlValidationError: If file has invalid format or unsupported version.
    """
    if not yaml_config.environment.dependencies:
        return None, None

    # Requirements.yaml is ALWAYS local (uploaded from user's machine)
    # Resolve and validate the local path
    req_path = _resolve_project_root_path(yaml_config.environment.dependencies, yaml_dir)

    if not req_path.exists():
        raise FileNotFoundError(
            f"environment.dependencies: requirements.yaml not found at '{req_path}'. "
            f"Please check the path in your YAML configuration."
        )
    if not req_path.is_file():
        raise PathValidationError(
            f"environment.dependencies: requirements.yaml must be a file, not a directory. "
            f"Path: '{req_path}'. Please check the path in your YAML configuration."
        )

    # Only .yaml/.yml files are supported
    if req_path.suffix not in [".yaml", ".yml"]:
        raise YamlValidationError(
            f"environment.dependencies: Only requirements.yaml format is supported. "
            f"Found file with extension '{req_path.suffix}'. "
            f"Please use a .yaml or .yml file."
            f"See https://docs.databricks.com/aws/en/admin/workspace-settings/base-environment#example-environment-specification for more information."
        )

    # Parse requirements.yaml to extract version and validate format
    # The YAML file will be uploaded to workspace and parsed on worker side
    # to support complex pip scenarios (index URLs, wheels, git repos, reference files, etc.)
    try:
        version = _parse_requirements_yaml(req_path)
    except YamlValidationError as e:
        raise YamlValidationError(f"environment.dependencies: {e}") from e

    return req_path, version


def _validate_gpu_node_pool_id(yaml_config: YamlConfig, pool_id: Optional[str]) -> None:
    """Validate GPU node pool ID is available for the specified GPU type.

    Args:
        yaml_config: Validated YAML configuration.
        pool_id: The pool ID to validate (may be resolved from pool name).

    Raises:
        YamlValidationError: If pool ID is not available for the GPU type.
    """
    if not pool_id:
        return

    # Get available compute options
    compute_options = get_compute_options(
        gpu_type=GPUType(yaml_config.compute.gpu_type),
        host=yaml_config.workspace.host if yaml_config.workspace else None,
    )

    # Filter to pool-based options
    pool_options = [opt for opt in compute_options if "reserved_pool" in opt]
    available_pool_ids = [opt["reserved_pool"]["id"] for opt in pool_options]

    # Validate pool ID is available
    if pool_id not in available_pool_ids:
        if not available_pool_ids:
            raise YamlValidationError(
                f"GPU pool ID '{pool_id}' is invalid: "
                f"No reserved GPU pools are available for GPU type '{yaml_config.compute.gpu_type}'. "
                f"Either remove pool configuration to use on-demand compute, or contact your workspace admin."
            )
        else:
            raise YamlValidationError(
                f"GPU pool ID '{pool_id}' is not available "
                f"for GPU type '{yaml_config.compute.gpu_type}'. "
                f"Available pool IDs: {', '.join(available_pool_ids)}"
            )


def _resolve_gpu_pool_name(yaml_config: YamlConfig) -> Optional[str]:
    """Resolve gpu_pool_name to pool ID by calling API.

    Args:
        yaml_config: Validated YAML configuration.

    Returns:
        str: Resolved pool ID, or existing pool ID if gpu_pool_name not set, or None if neither set.

    Raises:
        YamlValidationError: If pool name not found or multiple matches.
    """
    # If no pool name specified, return existing pool ID
    if not yaml_config.compute.gpu_pool_name:
        return yaml_config.compute.gpu_node_pool_id

    # Get available compute options for this GPU type
    compute_options = get_compute_options(
        gpu_type=GPUType(yaml_config.compute.gpu_type),
        host=yaml_config.workspace.host if yaml_config.workspace else None,
    )

    # Filter to pool-based options
    pool_options = [opt for opt in compute_options if "reserved_pool" in opt]

    # Find pool by name (case-sensitive exact match)
    target_name = yaml_config.compute.gpu_pool_name
    matching_pools = [opt for opt in pool_options if opt["reserved_pool"]["name"] == target_name]

    if not matching_pools:
        available_names = [opt["reserved_pool"]["name"] for opt in pool_options]
        if not available_names:
            raise YamlValidationError(
                f"compute.gpu_pool_name '{target_name}' not found: "
                f"No reserved GPU pools available for GPU type '{yaml_config.compute.gpu_type}'. "
                f"Either remove 'gpu_pool_name' to use on-demand compute, or contact your workspace admin."
            )
        else:
            raise YamlValidationError(
                f"compute.gpu_pool_name '{target_name}' not found for GPU type '{yaml_config.compute.gpu_type}'. "
                f"Available pool names: {', '.join(available_names)}"
            )

    if len(matching_pools) > 1:
        # This shouldn't happen in practice, but handle it
        pool_ids = [opt["reserved_pool"]["id"] for opt in matching_pools]
        raise YamlValidationError(
            f"compute.gpu_pool_name '{target_name}' matches multiple pools: {pool_ids}. "
            f"Please use gpu_node_pool_id instead to specify the exact pool."
        )

    resolved_id = matching_pools[0]["reserved_pool"]["id"]
    print_info(f"Resolved pool name '{target_name}' to pool ID: {resolved_id}")
    return resolved_id


def _convert_to_run_config(
    yaml_config: YamlConfig,
    code_source: InternalCodeSource,
    script_path: Path,
    script_type: ScriptType,
    req_path: Optional[Union[Path, str]],
    runtime_version: Optional[str],
    raw_dict: Dict[str, Any],
    resolved_pool_id: Optional[str] = None,
) -> RunConfig:
    """Convert validated YamlConfig to RunConfig.

    Args:
        resolved_pool_id: Resolved GPU pool ID (may be from gpu_pool_name or gpu_node_pool_id).
    """
    return RunConfig(
        experiment_name=yaml_config.experiment_name,
        requirements_txt=req_path.resolve() if req_path and isinstance(req_path, Path) else req_path,
        script=script_path.resolve() if script_path else None,
        script_type=script_type,
        gpus=yaml_config.compute.gpus,
        gpu_type=yaml_config.compute.gpu_type,
        gpu_node_pool_id=resolved_pool_id,
        env_variables=yaml_config.environment.env_variables or {},
        env_variables_secrets=yaml_config.environment.env_variables_secrets or {},
        max_retries=yaml_config.max_retries,
        timeout_seconds=(yaml_config.timeout_minutes * 60) if yaml_config.timeout_minutes else 0,
        workspace_host=yaml_config.workspace.host if yaml_config.workspace else None,
        parameters=yaml_config.parameters,
        idempotency_token=yaml_config.idempotency_token,
        docker_image_url=yaml_config.environment.docker_image.url if yaml_config.environment.docker_image else None,
        runtime_version=runtime_version,
        run_name=yaml_config.run_name,
        code_source=code_source,
        raw_dict=raw_dict,
        no_interpolation=yaml_config.no_interpolation,
        experiment_directory=yaml_config.experiment_directory,
        grant_permissions=yaml_config.grant_permissions,
        budget_policy_id=yaml_config.budget_policy_id,
    )


def _validate_docker_image_script_compatibility(yaml_config: YamlConfig) -> None:
    """Validate that docker_image is only used with bash_script.

    When using custom docker images, only bash_script is supported.
    Inline commands are not compatible with the sandbox CLI workflow.

    Args:
        yaml_config: Validated YAML configuration.

    Raises:
        YamlValidationError: If docker_image is used with command.
    """
    # Check if docker_image is specified
    if yaml_config.environment and yaml_config.environment.docker_image:
        # Check if inline command is used
        if yaml_config.command:
            raise YamlValidationError(
                "Inline 'command' field is not supported when using custom docker images.\n"
                "\n"
                "When 'environment.docker_image' is specified, please use 'bash_script' instead.\n"
                "\n"
                "Example:\n"
                "  environment:\n"
                "    docker_image:\n"
                "      url: pytorch/pytorch:2.0.0\n"
                "  bash_script: scripts/run.sh  # Use bash_script instead of command\n"
                "\n"
                "Create a bash script file with your command:\n"
                "  #!/bin/bash\n"
                "  python train.py --epochs 10\n"
            )


def _validate_yaml_dict(d: Dict[str, Any], yaml_path: Path) -> RunConfig:
    """Validate YAML configuration dictionary and return a RunConfig.

    This orchestrates the validation process:
    1. Structure/type validation (with Pydantic)
    2. File system validation (script, requirements, repo paths)
    3. GPU pool validation
    4. Conversion to RunConfig

    Args:
        d: Dictionary parsed from YAML file.
        yaml_path: Path to the YAML file (used for resolving relative paths).

    Returns:
        RunConfig: Validated configuration object.

    Raises:
        YamlValidationError: If YAML validation fails with user-friendly error messages.
        FileNotFoundError: If required files are not found.
        PathValidationError: If paths are not valid files or directories.
    """
    # Validate structure and types with Pydantic
    # This catches: unknown fields, type errors, GPU count validation, field formats
    yaml_config = _validate_yaml_structure(d, yaml_path)

    yaml_dir = yaml_path.parent

    # Validate docker_image compatibility with script type (before file validation)
    # This ensures clear error messages for invalid combinations before checking file existence
    _validate_docker_image_script_compatibility(yaml_config)

    # Validate file system resources
    script_path, script_type = _validate_script_file(yaml_config, yaml_dir)
    req_path, runtime_version = _validate_requirements_file(yaml_config, yaml_dir)

    # Validate and convert code_source
    code_source = _validate_and_convert_code_source(yaml_config, yaml_dir)

    # Resolve pool name to ID if gpu_pool_name is specified
    resolved_pool_id = _resolve_gpu_pool_name(yaml_config)

    # Validate GPU pool availability
    _validate_gpu_node_pool_id(yaml_config, resolved_pool_id)

    # Convert to RunConfig
    return _convert_to_run_config(
        yaml_config=yaml_config,
        code_source=code_source,
        script_path=script_path,
        script_type=script_type,
        req_path=req_path,
        runtime_version=runtime_version,
        raw_dict=d,
        resolved_pool_id=resolved_pool_id,
    )


def _load_and_validate_yaml(yaml_path: Path, no_interpolation: Optional[bool] = None) -> Tuple[RunConfig, DictConfig]:
    """Load and validate a YAML configuration file.

    Args:
        yaml_path: Path to the YAML configuration file.
        no_interpolation: Whether to resolve the parameters using OmegaConf.

    Returns:
        Tuple of (RunConfig, DictConfig): Validated configuration object and OmegaConf data.

    Raises:
        YamlValidationError: If YAML is invalid or missing required fields.
    """
    data = _load_with_bases(yaml_path)
    if not isinstance(data, DictConfig):
        raise YamlValidationError("Top-level YAML must be a mapping/dict")
    # Cli will override the YAML-level no_interpolation field if provided.
    if no_interpolation is None:
        if hasattr(data, "no_interpolation"):
            no_interpolation = data.no_interpolation
        else:
            no_interpolation = False
    yaml_dict = OmegaConf.to_container(data, resolve=not no_interpolation)
    return _validate_yaml_dict(yaml_dict, yaml_path), data


# ---------------- Parsers ----------------


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the CLI argument parser.

    Returns:
        argparse.ArgumentParser: Configured parser with subcommands.
    """
    epilog = """Run 'sgcli <command> --help' for more information on a specific command. \n\n"""
    epilog += """YAML Configuration Help:
  sgcli -h config                    - Overview of YAML configuration
  sgcli -h config.experiment_name    - Help for experiment_name field
  sgcli -h config.environment        - Help for environment field
  sgcli -h config.compute            - Help for compute field
  sgcli -h config.code_source        - Help for code_source field
  sgcli -h config.parameters         - Help for parameters field

"""
    epilog += """Examples:
  sgcli run --file ./training.yaml
  sgcli run --file ./training.yaml --override compute.gpus=32 timeout_minutes=120
  sgcli get status 388840544681214
  sgcli cancel 388840544681214
  sgcli get logs 388840544681214
  sgcli get logs 388840544681214 --node 2
  sgcli get logs 388840544681214 --node 1 --local-rank 3
  sgcli get runs --limit 10
    """
    parser = argparse.ArgumentParser(
        prog="sgcli",
        description="Databricks Skyrun CLI for Serverless GPU jobs",
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("-v", "--verbose", action="count", default=0, help="Increase verbosity.")
    parser.add_argument("--version", action="version", version=f"sgcli {__version__}")

    subs = parser.add_subparsers(dest="command", required=True)

    # run
    run_p = subs.add_parser("run", help="Submit a job run from a YAML spec.")
    run_p.add_argument(
        "-f",
        "--file",
        dest="file",
        required=True,
        type=lambda s: _require_file_exists(Path(s)),
        help="Path to the YAML spec (e.g., training.yaml).",
    )
    run_p.add_argument("--watch", action="store_true", help="Monitor job and stream logs until completion.")
    run_p.add_argument(
        "--override",
        metavar="KEY=VALUE",
        nargs="+",
        help="Override YAML parameters using dotted paths (e.g., compute.gpus=32 timeout_minutes=120).",
    )
    run_p.add_argument(
        "--run-system-checks", action="store_true", help="Run node system check script before training starts."
    )
    run_p.add_argument("--dry-run", action="store_true", help="Prepare workload but skip submitting job to Jobs API.")
    run_p.add_argument(
        "-p",
        "--profile",
        type=str,
        help="Databricks profile to use (from ~/.databrickscfg). Note: Workspace must be set in YAML.",
    )
    run_p.add_argument(
        "--no-interpolation",
        type=bool,
        default=None,
        help="Resolve YAML variable interpolations (${var} syntax). Disable if your workflow handles interpolation separately (default: disabled).",
    )

    run_p.add_argument(
        "--skip-image-upload",
        action="store_true",
        help="Skip waiting for docker image registration to complete.",
    )

    run_p.set_defaults(func=handle_run)

    # cancel
    cancel_p = subs.add_parser("cancel", help="Cancel a specific run.")
    cancel_p.add_argument("run_id", type=_parse_run_id, help="Run ID to cancel.")
    cancel_p.add_argument(
        "-p",
        "--profile",
        type=str,
        help="Databricks profile to use (from ~/.databrickscfg).",
    )
    cancel_p.set_defaults(func=handle_cancel)

    # get
    get_p = subs.add_parser("get", help="Get resources (runs, etc.).")
    get_subs = get_p.add_subparsers(dest="resource", required=True)

    # get runs
    get_runs_p = get_subs.add_parser("runs", help="List submitted runs.")
    get_runs_p.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Maximum number of runs to return (default: 20).",
    )
    get_runs_p.add_argument(
        "--all",
        action="store_true",
        help="Show all runs including completed ones (default: active only).",
    )
    get_runs_p.add_argument(
        "--experiment",
        type=str,
        help="Filter by experiment name (supports regex patterns).",
    )
    get_runs_p.add_argument(
        "-p",
        "--profile",
        type=str,
        help="Databricks profile to use (from ~/.databrickscfg).",
    )
    get_runs_p.add_argument(
        "--host",
        type=str,
        help="Databricks workspace hostname (e.g., https://example.databricks.com).",
    )
    get_runs_p.set_defaults(func=handle_get_runs)

    # status
    status_p = get_subs.add_parser("status", help="Show the status of a specific run.")
    status_p.add_argument("run_id", type=_parse_run_id, help="Run ID to describe.")
    status_p.add_argument("--watch", action="store_true", help="Poll until terminal state.")
    status_p.add_argument(
        "-p",
        "--profile",
        type=str,
        help="Databricks profile to use (from ~/.databrickscfg).",
    )
    status_p.set_defaults(func=handle_status)

    # logs
    logs_p = get_subs.add_parser("logs", help="Stream or view logs from a run.")
    logs_p.add_argument("run_id", type=_parse_run_id, help="Run ID to get logs from.")
    logs_p.add_argument(
        "--node",
        type=int,
        default=None,
        help="Fetch logs from specific node (0 to num_nodes-1). If not specified, fetches from node 0.",
    )
    logs_p.add_argument(
        "--local_rank",
        "--local-rank",
        type=int,
        default=None,
        dest="local_rank",
        choices=range(MAX_GPU_PER_NODE),
        help=f"Fetch logs from specific local rank on the node (0-{MAX_GPU_PER_NODE-1}). If not specified, fetches from local rank 0.",
    )
    logs_p.add_argument(
        "--lines",
        type=int,
        default=None,
        help="Print only the last N lines (useful for completed runs with large logs).",
    )
    logs_p.add_argument(
        "--review",
        action="store_true",
        help="Download and analyze logs from all nodes, filtering for errors and traces.",
    )
    logs_p.add_argument(
        "--download-only",
        "--download_only",
        type=str,
        default=None,
        dest="download_only",
        help="Download logs to specified directory. Creates directory if it doesn't exist.",
    )
    logs_p.add_argument(
        "-p",
        "--profile",
        type=str,
        help="Databricks profile to use (from ~/.databrickscfg).",
    )
    logs_p.set_defaults(func=handle_logs)

    # pools
    pools_p = get_subs.add_parser("pools", help="Show available GPU pools.")
    pools_p.add_argument(
        "-p",
        "--profile",
        type=str,
        help="Databricks profile to use (from ~/.databrickscfg).",
    )
    pools_p.add_argument(
        "--host",
        type=str,
        help="Databricks workspace hostname (e.g., https://example.databricks.com).",
    )
    pools_p.set_defaults(func=handle_pool_info)

    # changelog (hidden command)
    changelog_p = subs.add_parser("changelog", help=argparse.SUPPRESS)
    changelog_p.set_defaults(func=handle_changelog)

    # register
    register_p = subs.add_parser("register", help="Register resources (images, etc.).")
    register_subs = register_p.add_subparsers(dest="resource", required=True)

    # register image
    register_image_p = register_subs.add_parser(
        "image", help="Register a docker image and optionally credentials for use with sgcli run."
    )
    register_image_p.add_argument(
        "docker_image_url",
        type=str,
        help="Docker image URL (e.g., pytorch/pytorch:2.0.0, myregistry.io/myimage:v1).",
    )
    register_image_p.add_argument(
        "--tag-policy",
        choices=["auto", "latest"],
        default="auto",
        help=(
            "Image resolution policy for images with tags. "
            "'auto' (default): Use cached image if AVAILABLE, else register and wait. "
            "'latest': Always check source registry for SHA updates; re-register if changed."
        ),
    )
    register_image_p.add_argument(
        "--scope",
        type=str,
        help="Databricks secret scope for registry credentials (for private images).",
    )
    register_image_p.add_argument(
        "--key",
        type=str,
        help="Databricks secret key for registry credentials (for private images).",
    )
    register_image_p.add_argument(
        "--timeout-minutes",
        type=int,
        default=60,
        help="Timeout in minutes to wait for image to become available (default: 60).",
    )
    register_image_p.add_argument(
        "-p",
        "--profile",
        type=str,
        help="Databricks profile to use (from ~/.databrickscfg).",
    )
    register_image_p.add_argument(
        "--interactive-authenticate",
        action="store_true",
        default=False,
        help="Interactively create a Databricks secret for private registry credentials.",
    )
    register_image_p.set_defaults(func=handle_register)
    return parser


# ---------------- Handlers ----------------


def _check_image_registration_for_run(
    docker_image_url: str,
    workspace_host: Optional[str] = None,
) -> None:
    """Verify Docker image is registered before run."""

    client = ImageClient(workspace_host=workspace_host)
    existing = client.get_image(docker_image_url)

    if existing is None:
        raise RuntimeError(
            f"Image not registered: {docker_image_url}\n\n"
            f"Please register the image first:\n"
            f"  sgcli register image {docker_image_url}\n"
            f"or:\n"
            f"  sgcli register image {docker_image_url} --interactive-authenticate\n"
            f"or:\n"
            f"  sgcli register image {docker_image_url} --scope <scope> --key <key>\n"
        )

    if existing.status == ImageStatus.FAILED:
        error_msg = existing.status_message or "Unknown error"
        raise RuntimeError(
            f"Image registration previously failed: {error_msg}\n\n"
            f"Please re-register:\n"
            f"  sgcli register image {docker_image_url} --scope <scope> --key <key>\n"
        )


def handle_run(args: argparse.Namespace) -> int:
    """Handle the 'run' command to submit a training workload.

    Args:
        args: Parsed command-line arguments containing:
            - file: Path to YAML configuration
            - override: Optional list of KEY=VALUE overrides
            - verbose: Verbosity level
            - watch: Whether to monitor and stream logs until completion

    Returns:
        int: Exit code (0=success, 1=runtime error, 2=validation error).
    """
    yaml_path: Path = args.file

    # Load and validate YAML with OmegaConf (supports composition via _bases_)
    try:
        cfg, yaml_data = _load_and_validate_yaml(yaml_path, no_interpolation=args.no_interpolation)
    except (YamlValidationError, FileNotFoundError, PathValidationError) as e:
        print_error(f"  {e}")
        return 2
    except KeyError as e:
        print_error(f"  Missing or invalid field: {e}")
        print_error("  Check your YAML configuration structure.")
        return 2
    except Exception as e:
        print_error(f"Failed to load YAML file '{yaml_path.name}': {type(e).__name__}: {e}")
        return 2

    no_interpolation = (
        args.no_interpolation
        if args.no_interpolation is not None
        else cfg.no_interpolation
        if cfg.no_interpolation is not None
        else False
    )

    # Apply CLI overrides if provided
    if args.override:
        try:
            overrides = _parse_overrides(args.override)
            # Convert DictConfig to dict for override application
            yaml_dict = OmegaConf.to_container(yaml_data, resolve=not no_interpolation)
            yaml_dict = _apply_overrides_to_yaml_dict(yaml_dict, overrides)
            # Convert back to DictConfig
            yaml_data = OmegaConf.create(yaml_dict)

            # Re-validate with overrides applied
            cfg = _validate_yaml_dict(yaml_dict, yaml_path)
        except (YamlValidationError, SystemExit) as e:
            print_error(f"Failed to apply overrides: {e}")
            return 2

    if hasattr(args, "profile") and args.profile and cfg.workspace_host:
        print_error("--profile flag cannot be provided when 'workspace' is set in the YAML configuration.")
        print_error("Remove --profile flag from your command.")
        return 2

    log.debug("YAML path: %s", yaml_path)
    print_info(f"Submitting experiment: {cfg.experiment_name}")
    log.debug("Compute: gpus=%s gpu_type=%s", cfg.gpus, cfg.gpu_type)
    log.debug("Requirements: %s", cfg.requirements_txt)
    log.debug("Script: %s", cfg.script)
    if cfg.code_source.type == "snapshot":
        log.debug("Code source: snapshot from %s", cfg.code_source.snapshot.repo_path)
    if cfg.env_variables:
        log.debug("Env Vars: %d set", len(cfg.env_variables))

    # Create Jobs API client and submit workload
    try:
        # Configure workspace authentication if workspace.host is specified
        if cfg.workspace_host:
            _configure_workspace_auth(cfg.workspace_host)

        client = JobsApiClient(workspace_host=cfg.workspace_host)
        gpu_type = GPUType(cfg.gpu_type)

        if args.skip_image_upload:
            print_warning("Skipping docker image upload wait because --skip-image-upload flag is set")
        else:
            if cfg.docker_image_url:
                _check_image_registration_for_run(
                    docker_image_url=cfg.docker_image_url,
                    workspace_host=cfg.workspace_host,
                )
            maybe_wait_for_docker_image_cache(
                raw_dict=cfg.raw_dict,
                workspace_host=cfg.workspace_host,
            )

        # Create workspace directory for launch artifacts
        func_dir = get_cli_launch_dir(cfg.experiment_name)
        log.debug("Using workspace directory: %s", func_dir)

        # Upload YAML config file to workspace
        # Always upload the final merged/overridden YAML (with OmegaConf composition and CLI overrides applied)
        yaml_config_dest = os.path.join(func_dir, "training_config.yaml")
        log.debug("Uploading training config YAML to workspace: %s", yaml_config_dest)

        try:
            with create_temp_yaml_file(yaml_data, no_interpolation) as temp_yaml_path:
                yaml_config_path = upload_file_to_workspace(temp_yaml_path, yaml_config_dest)
            log.debug(f"Successfully uploaded training config to: {yaml_config_path}")
        except Exception as e:
            raise RuntimeError(f"Failed to upload training config to {yaml_config_dest} with Error {e}") from e

        # Upload requirements.yaml to the func_dir remotely in users' Workspace (if provided).
        # Requirements.yaml is ALWAYS local and uploaded from user's machine (no git workflow distinction)
        if cfg.requirements_txt:
            req_filename = Path(cfg.requirements_txt).name
            dest = os.path.join(func_dir, req_filename)

            log.debug(f"Uploading requirements.yaml to workspace: {dest}")
            try:
                upload_file_to_workspace(cfg.requirements_txt, dest)
                log.debug(f"Successfully uploaded requirements.yaml to workspace: {dest}")
            except Exception as e:
                raise RuntimeError(f"Failed to upload requirements.yaml to {dest} with Error {e}") from e
        else:
            log.debug("No requirements.yaml specified, skipping upload")

        # Upload hyperparameters YAML if provided
        parameters_yaml_path = None
        if cfg.parameters:
            print_info("Uploading hyperparameters YAML...")
            try:
                parameters_yaml_path = upload_parameters_as_yaml(cfg.parameters, func_dir)
                log.debug(f"Successfully uploaded hyperparameters to: {parameters_yaml_path}")
            except Exception as e:
                raise RuntimeError(f"Failed to upload hyperparameters with Error {e}") from e
        else:
            log.debug("No parameters specified, skipping hyperparameters upload")

        # Upload system check script if --run-system-checks flag is set
        sanity_check_script_path = None
        if args.run_system_checks:
            print_info("Uploading node sanity check script...")
            try:
                # Get path to node_sanity_check.sh from cli directory
                cli_dir = Path(__file__).parent
                sanity_check_source = cli_dir / "node_sanity_check.sh"

                if not sanity_check_source.exists():
                    raise RuntimeError(f"node_sanity_check.sh not found at {sanity_check_source}")

                sanity_check_dest = os.path.join(func_dir, "node_sanity_check.sh")
                sanity_check_script_path = upload_file_to_workspace(str(sanity_check_source), sanity_check_dest)
                log.debug(f"Successfully uploaded sanity check script to: {sanity_check_script_path}")
            except Exception as e:
                raise RuntimeError(f"Failed to upload sanity check script with Error {e}") from e
        else:
            log.debug("Sanity check not requested, skipping script upload")

        # Upload mlflow system metrics script
        mlflow_system_metrics_script_path = None
        log.debug("Uploading MLflow system metrics monitoring script...")
        try:
            # Get path to mlflow_system_metrics.py from cli directory
            cli_dir = Path(__file__).parent
            mlflow_metrics_source = cli_dir / "mlflow_system_metrics.py"

            if not mlflow_metrics_source.exists():
                raise RuntimeError(f"mlflow_system_metrics.py not found at {mlflow_metrics_source}")

            mlflow_metrics_dest = os.path.join(func_dir, "mlflow_system_metrics.py")
            mlflow_system_metrics_script_path = upload_file_to_workspace(
                str(mlflow_metrics_source), mlflow_metrics_dest
            )
            log.debug(f"Successfully uploaded MLflow metrics script to: {mlflow_system_metrics_script_path}")
        except Exception as e:
            raise RuntimeError(f"Failed to upload MLflow metrics script with Error {e}") from e

        # TODO: This should be a separate function for clarity
        # Handle tarball - create from local_repo_path and upload to Volume or workspace
        tar_workspace_path = None
        if cfg.code_source.type == "snapshot":
            snapshot = cfg.code_source.snapshot
            assert snapshot is not None

            # Detect if this is a git repository
            is_git_repo = is_git_repository(snapshot.repo_path)

            # Check for uncommitted changes
            if is_git_repo:
                if has_uncommitted_changes(snapshot.repo_path):
                    # uncommited changes raise an error UNLESS:
                    # 1. allow_uncommitted is true OR
                    # 2. use_remote_head is true OR
                    # 3. git_commit/git_branch is specified OR
                    # 4. include_paths is specified and changes are outside those paths
                    should_allow = (
                        snapshot.allow_uncommitted
                        or snapshot.use_remote_head
                        or snapshot.git_commit is not None
                        or snapshot.git_branch is not None
                    )

                    # If include_paths specified, check if changes are outside those paths
                    if not should_allow and snapshot.include_paths:
                        has_changes_in_paths, _ = has_uncommitted_changes_in_paths(
                            snapshot.repo_path, snapshot.include_paths
                        )
                        if not has_changes_in_paths:
                            # Changes are outside include_paths - allow it
                            should_allow = True
                            log.debug(
                                f"Uncommitted changes detected outside include_paths {snapshot.include_paths}, changes will not affect snapshot"
                            )

                    if not should_allow:
                        raise ValueError(
                            f"Repository at {snapshot.repo_path} has uncommitted changes. "
                            f"Either commit your changes, or set allow_uncommitted: true in your YAML config."
                        )

            # Determine git reference and type for cloning
            git_ref = None
            ref_type = None
            git_sha_for_cache = None

            # Check if uncommitted changes should prevent caching
            has_uncommitted = has_uncommitted_changes(snapshot.repo_path)
            skip_caching = False

            if has_uncommitted:
                # If include_paths specified, check if changes are in those paths
                if snapshot.include_paths:
                    has_changes_in_paths, _ = has_uncommitted_changes_in_paths(
                        snapshot.repo_path, snapshot.include_paths
                    )
                    if has_changes_in_paths:
                        # Changes in include_paths - can't cache
                        skip_caching = True
                        print_info(
                            f"Repository {snapshot.repo_path} has uncommitted changes in include_paths. "
                            f"Snapshot will not be cached."
                        )
                    else:
                        # Changes outside include_paths - can still cache
                        print_info(
                            f"Repository {snapshot.repo_path} has uncommitted changes outside include_paths. "
                            f"Snapshot will use SHA-based caching."
                        )
                else:
                    # No include_paths - changes affect entire snapshot, can't cache
                    skip_caching = True
                    print_info(f"Repository {snapshot.repo_path} has uncommitted changes. Snapshot will not be cached.")

            if not skip_caching and is_git_repo and snapshot.git_commit is not None:
                # Use specific commit
                git_ref = snapshot.git_commit
                ref_type = "commit"
                git_sha_for_cache = snapshot.git_commit
                print_info(f"Using specified commit: {snapshot.git_commit}")

                # Check if commit exists locally when using git archive mode
                if snapshot.include_paths:
                    import subprocess

                    log.debug(f"Checking if commit {git_sha_for_cache[:8]} exists locally")
                    check_result = subprocess.run(
                        ["git", "-C", str(snapshot.repo_path), "cat-file", "-e", git_sha_for_cache],
                        capture_output=True,
                        text=True,
                        timeout=60,
                    )

                    if check_result.returncode != 0:
                        # Commit not found locally, fetch it
                        print_info(
                            f"Commit {git_sha_for_cache[:8]} not found locally, "
                            f"fetching from remote with partial clone"
                        )
                        # Determine remote name
                        remote_name = snapshot.remote_alias or detect_remote_name(
                            snapshot.repo_path, snapshot.git_branch
                        )

                        # filter=blob:none enables partial clone, fetches commit objects but skips file contents initially
                        # that way we only fetch the specific file objects we care about.
                        try:
                            subprocess.run(
                                [
                                    "git",
                                    "-C",
                                    str(snapshot.repo_path),
                                    "fetch",
                                    "--depth=1",
                                    "--filter=blob:none",
                                    remote_name,
                                    git_sha_for_cache,
                                ],
                                capture_output=True,
                                text=True,
                                check=True,
                                timeout=300,
                            )
                            log.debug(f"Successfully fetched commit {git_sha_for_cache[:8]}")
                        except subprocess.CalledProcessError as e:
                            error_msg = e.stderr.strip() if e.stderr else str(e)
                            raise RuntimeError(
                                f"Failed to fetch commit '{git_sha_for_cache}' from remote. "
                                f"Ensure the commit exists and you have access. Error: {error_msg}"
                            ) from e
                        except subprocess.TimeoutExpired as e:
                            raise RuntimeError(
                                f"Fetching commit '{git_sha_for_cache}' timed out. "
                                f"This may indicate network issues."
                            ) from e
                    else:
                        log.debug(f"Commit {git_sha_for_cache[:8]} already exists locally")

            elif not skip_caching and is_git_repo and snapshot.git_branch is not None:
                # Use specific branch
                git_branch = snapshot.git_branch

                if snapshot.use_remote_head:
                    # Fetch and use remote HEAD of the branch
                    print_info(f"Fetching remote HEAD of branch: {git_branch}")

                    # Determine remote name
                    remote_name = snapshot.remote_alias or detect_remote_name(snapshot.repo_path, git_branch)

                    # Fetch from remote - this function:
                    # - Queries remote with git ls-remote
                    # - Checks if commit exists locally
                    # - Fetches with partial clone if needed
                    git_sha_for_cache = fetch_branch_sha(snapshot.repo_path, git_branch, remote_name=remote_name)
                    print_info(f"Using remote HEAD of branch {git_branch}: {git_sha_for_cache[:8]}")
                else:
                    # Use local HEAD of the branch (no fetch)
                    print_info(f"Using local HEAD of branch: {git_branch}")
                    import subprocess

                    try:
                        result = subprocess.run(
                            ["git", "-C", str(snapshot.repo_path), "rev-parse", git_branch],
                            capture_output=True,
                            text=True,
                            check=True,
                            timeout=5,
                        )
                        git_sha_for_cache = result.stdout.strip()
                        print_info(f"Resolved to local commit: {git_sha_for_cache[:8]}")
                    except subprocess.CalledProcessError as e:
                        error_msg = e.stderr.strip() if e.stderr else str(e)
                        raise RuntimeError(
                            f"Failed to resolve local branch '{git_branch}'. "
                            f"Ensure the branch exists locally. Error: {error_msg}"
                        ) from e
                    except subprocess.TimeoutExpired as e:
                        raise RuntimeError(f"Git operation timed out for branch '{git_branch}'") from e

                git_ref = git_branch
                ref_type = "branch"

            elif not skip_caching and is_git_repo:
                # Use current HEAD (existing behavior)
                git_sha_for_cache = get_git_sha(snapshot.repo_path)
                if not git_sha_for_cache:
                    print_error("Could not determine git SHA. Tarball will be uploaded without caching.")
                git_ref = "HEAD"
                ref_type = "head"
                print_info("Using current HEAD")
            elif not is_git_repo:
                # Non-git path - no caching
                print_info("Non-git directory detected, will create plain tarball without version caching")
                git_sha_for_cache = None

            # Determine upload destination: Volume if remote_volume is specified, otherwise workspace
            use_volume = snapshot.remote_volume is not None

            # Create tarball from local directory and upload
            temp_tarball_path = None
            try:
                directory_name = snapshot.repo_path.name

                # Build the remote path based on destination
                if use_volume:
                    # Upload to Volume
                    remote_base = snapshot.remote_volume.rstrip("/")
                else:
                    # Upload to workspace - get user workspace directory for tarball storage
                    user_email = get_current_user_email()
                    remote_base = f"/Users/{user_email}/.serverless_gpu/repo_snapshots/{directory_name}"

                # For branches, we need to resolve SHA first to check cache
                if ref_type == "branch" and not git_sha_for_cache:
                    print_info(f"Resolving branch {git_ref} to commit SHA...")
                    git_sha_for_cache = fetch_branch_sha(snapshot.repo_path, git_ref)
                    print_info(f"Branch {git_ref} resolved to commit {git_sha_for_cache[:8]}")

                # Check cache if we have a SHA
                if git_sha_for_cache:
                    tarball_filename = f"{directory_name}_{git_sha_for_cache[:8]}.tar.gz"
                    tar_workspace_path = f"{remote_base}/{tarball_filename}"

                    # Check if tarball with this SHA already exists
                    file_exists = (
                        check_volume_file_exists(tar_workspace_path)
                        if use_volume
                        else check_workspace_file_exists(tar_workspace_path)
                    )

                    if file_exists:
                        log.debug(f"Tarball for SHA {git_sha_for_cache[:8]} already exists at {tar_workspace_path}")
                        print_success(f"✓ Using cached snapshot (SHA: {git_sha_for_cache[:8]})")
                    else:
                        # Create new snapshot
                        print_info("Snapshot not in cache, creating snapshot from repository")

                        # Validate paths exist at commit (only if include_paths specified)
                        if snapshot.include_paths:
                            log.debug(f"Creating git archive snapshot with include_paths: {snapshot.include_paths}")
                            validate_include_paths_exist(snapshot.repo_path, git_sha_for_cache, snapshot.include_paths)
                        else:
                            log.debug("Creating git archive snapshot (entire repository)")

                        # Create tarball with git archive
                        with tempfile.NamedTemporaryFile(mode="wb", suffix=".tar.gz", delete=False) as tmp_tar:
                            temp_tarball_path = tmp_tar.name

                        create_git_archive_snapshot(
                            repo_path=snapshot.repo_path,
                            commit_sha=git_sha_for_cache,
                            include_paths=snapshot.include_paths,
                            output_tarball=temp_tarball_path,
                            directory_name=directory_name,
                        )

                        tarball_size = os.path.getsize(temp_tarball_path)
                        size_mb = tarball_size / (1024 * 1024)
                        log.debug(f"Created tarball: {tarball_filename} ({size_mb:.2f} MB)")

                        # Upload to Volume or workspace based on configuration
                        if use_volume:
                            tar_workspace_path = upload_file_to_volume(temp_tarball_path, tar_workspace_path)
                            log.debug(f"Uploaded tarball to volume: {tar_workspace_path}")
                        else:
                            tar_workspace_path = upload_file_to_workspace(temp_tarball_path, tar_workspace_path)
                            log.debug(f"Uploaded tarball to workspace: {tar_workspace_path}")
                else:
                    # No git SHA available, upload without caching
                    log.debug("No git SHA available, uploading snapshot without caching")
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    tarball_filename = f"{directory_name}_{timestamp}.tar.gz"
                    tar_workspace_path = f"{remote_base}/{tarball_filename}"

                    # Create tarball - use git archive for git repos, plain tarball for non-git
                    with tempfile.NamedTemporaryFile(mode="wb", suffix=".tar.gz", delete=False) as tmp_tar:
                        temp_tarball_path = tmp_tar.name

                    if is_git_repo:
                        tarball_created = False

                        if has_uncommitted:
                            # Cannot use git archive with uncommitted changes - it only archives committed state
                            if snapshot.include_paths:
                                # Check if uncommitted changes are within the include_paths
                                has_changes_in_paths, changed_files = has_uncommitted_changes_in_paths(
                                    snapshot.repo_path, snapshot.include_paths
                                )

                                if has_changes_in_paths:
                                    # Uncommitted changes in the paths we're snapshotting
                                    # Use plain tarball with selective paths to capture uncommitted changes
                                    log.debug(
                                        f"Uncommitted changes detected in include_paths {snapshot.include_paths}. "
                                        f"Using plain tarball to capture changes (no caching). "
                                        f"Changed files: {', '.join(changed_files[:5])}"
                                        f"{'...' if len(changed_files) > 5 else ''}"
                                    )
                                    log.debug(f"Creating plain tarball with include_paths: {snapshot.include_paths}")
                                    create_plain_tarball(
                                        repo_path=snapshot.repo_path,
                                        output_tarball=temp_tarball_path,
                                        include_paths=snapshot.include_paths,
                                    )
                                    tarball_created = True
                                else:
                                    # Uncommitted changes exist but not in include_paths - safe to use git archive
                                    print_info(
                                        f"Uncommitted changes detected outside include_paths, proceeding with git archive "
                                        f"(changes outside {snapshot.include_paths} will not be included)"
                                    )

                            else:
                                # No include_paths specified but have uncommitted changes
                                # Use plain tarball to capture working directory including uncommitted changes
                                log.debug("Creating plain tarball to capture uncommitted changes (entire directory)")
                                create_plain_tarball(
                                    repo_path=snapshot.repo_path,
                                    output_tarball=temp_tarball_path,
                                )
                                tarball_created = True

                        # Use git archive if tarball not yet created
                        if not tarball_created:
                            # Get current commit SHA for git archive
                            current_sha = get_git_sha(snapshot.repo_path)
                            if current_sha is None:
                                raise RuntimeError("Failed to determine git commit SHA for repository")

                            # Validate paths exist at commit (only if include_paths specified)
                            if snapshot.include_paths:
                                log.debug(f"Creating git archive snapshot with include_paths: {snapshot.include_paths}")
                                validate_include_paths_exist(snapshot.repo_path, current_sha, snapshot.include_paths)
                            else:
                                log.debug("Creating git archive snapshot (entire repository)")

                            create_git_archive_snapshot(
                                repo_path=snapshot.repo_path,
                                commit_sha=current_sha,
                                include_paths=snapshot.include_paths,
                                output_tarball=temp_tarball_path,
                                directory_name=directory_name,
                            )
                    else:
                        # Non-git directory - use plain tarball
                        log.debug("Creating plain tarball (entire directory)")
                        create_plain_tarball(
                            repo_path=snapshot.repo_path,
                            output_tarball=temp_tarball_path,
                        )

                    tarball_size = os.path.getsize(temp_tarball_path)
                    size_mb = tarball_size / (1024 * 1024)
                    log.debug(f"Created tarball: {tarball_filename} ({size_mb:.2f} MB)")

                    # Upload to Volume or workspace based on configuration
                    if use_volume:
                        tar_workspace_path = upload_file_to_volume(temp_tarball_path, tar_workspace_path)
                        log.debug(f"Uploaded tarball to volume: {tar_workspace_path}")
                    else:
                        tar_workspace_path = upload_file_to_workspace(temp_tarball_path, tar_workspace_path)
                        log.debug(f"Uploaded tarball to workspace: {tar_workspace_path}")

            except Exception as e:
                raise RuntimeError(
                    f"Failed to create and upload tarball from {snapshot.repo_path} with Error {e}"
                ) from e
            finally:
                # Clean up temporary tarball
                if temp_tarball_path:
                    try:
                        os.unlink(temp_tarball_path)
                        log.debug(f"Cleaned up temporary tarball: {temp_tarball_path}")
                    except Exception as e:
                        print_warning(f"Failed to delete temporary tarball {temp_tarball_path}: {e}")

        if not cfg.raw_dict.get("command"):
            print_info(f"Uploading {cfg.script_type.value} script to workspace: {cfg.script}")
            workspace_zip_path, script_filename = upload_python_script_as_zip(str(cfg.script), func_dir)

        else:
            # Create temporary command file to upload to workspace
            tmp_cmd_path = None
            try:
                with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False) as tmp_cmd:
                    tmp_cmd.write(cfg.raw_dict["command"])
                    tmp_cmd_path = tmp_cmd.name

                log.debug("Uploading inline command script to workspace")
                workspace_zip_path, script_filename = upload_python_script_as_zip(tmp_cmd_path, func_dir)
            finally:
                # Clean up temp file
                if tmp_cmd_path:
                    try:
                        os.unlink(tmp_cmd_path)
                        log.debug(f"Cleaned up temporary command script: {tmp_cmd_path}")
                    except Exception as e:
                        log.debug(f"Failed to delete temp command file {tmp_cmd_path}: {e}")

        # Get requirements filename if provided (always local, uploaded above)
        requirements_filename = Path(cfg.requirements_txt).name if cfg.requirements_txt else None

        result = client.create_workload(
            gpus=cfg.gpus,
            gpus_per_node=cfg.gpus,
            workspace_zip_path=workspace_zip_path,
            script_filename=script_filename,
            func_dir=func_dir,
            experiment_name=cfg.experiment_name,
            timeout_seconds=cfg.timeout_seconds,
            param_to_args={},
            env_sync_timeout=DEFAULT_ENV_SYNC_TIMEOUT_SECONDS,
            gpu_type=gpu_type,
            yaml_config_path=yaml_config_path,
            max_retries=cfg.max_retries,
            script_type=cfg.script_type,
            tar_workspace_path=tar_workspace_path,
            env_variables=cfg.env_variables,
            env_variables_secrets=cfg.env_variables_secrets,
            requirements_filename=requirements_filename,
            parameters_yaml_path=parameters_yaml_path,
            sanity_check_script_path=sanity_check_script_path,
            mlflow_system_metrics_script_path=mlflow_system_metrics_script_path,
            docker_image_url=cfg.docker_image_url,
            runtime_version=cfg.runtime_version,
            gpu_node_pool_id=cfg.gpu_node_pool_id,
            idempotency_token=cfg.idempotency_token,
            run_name=cfg.run_name,
            experiment_directory=cfg.experiment_directory,
            grant_permissions=cfg.grant_permissions,
            budget_policy_id=cfg.budget_policy_id,
            dry_run=args.dry_run,
        )

        if args.dry_run:
            return 0

        # Extract run_id and run_url from result
        run_id = result.get("run_id")
        job_run_name = result.get("job_run_name")

        # Update MLflow run name
        _update_mlflow_run_name(client, str(run_id), job_run_name)

        # Stream logs only when --watch is specified
        if args.watch:
            print_info("Monitoring job and streaming logs...")
            success = monitor_and_stream_logs(run_id=str(run_id))
            return 0 if success else 1
        else:
            return 0

    except RuntimeError as e:
        if args.verbose > 0:
            raise
        print_error(str(e))
        return 1
    except Exception as e:
        print_error(f"Failed to submit workload: {e}")
        if args.verbose > 0:
            raise
        return 1


def handle_status(args: argparse.Namespace) -> int:
    """Handle the 'status' command to check workload status.

    Args:
        args: Parsed command-line arguments containing:
            - run_id: The run ID to query
            - verbose: Verbosity level
            - watch: Whether to poll until terminal state
            - profile: Optional Databricks profile to use

    Returns:
        int: Exit code (0=success, 1=error).
    """
    run_id: str = args.run_id

    # Log authentication context
    log_auth_context(verbose=args.verbose > 0)

    try:
        client = JobsApiClient()
        w = client._get_workspace_client()
        workspace_url = w.config.host.rstrip("/")
        workspace_id = w.get_workspace_id()
        status_info = client.get_workload_status(run_id)

        # Display YAML config if available
        yaml_path = status_info.get("yaml_parameters_file_path")
        if yaml_path:
            try:
                _fetch_and_display_yaml_config(yaml_path)
            except NotFound:
                print_error(f"YAML config file not found at {yaml_path}")
                if args.verbose > 0:
                    raise
            except PermissionDenied:
                print_error(f"Permission denied when accessing YAML config at {yaml_path}")
                if args.verbose > 0:
                    raise
            except UnicodeDecodeError:
                print_error(f"Failed to decode YAML config from {yaml_path}: invalid UTF-8 encoding")
                if args.verbose > 0:
                    raise
            except Exception as e:
                print_error(f"Failed to fetch YAML config from {yaml_path}: {e}")
                if args.verbose > 0:
                    raise

        # Check if this is a foreach sweep
        if status_info.get("task_type") == "for_each":
            # Display foreach sweep table
            _display_foreach_sweep_status(client, run_id, status_info, workspace_url, workspace_id)
        else:
            # Display normal single-task status
            tasks = status_info.get("tasks", [])
            attempt_number = tasks[-1].get("attempt_number", 0) if tasks else 0

            # Format and display status
            status_display = _format_status_box(
                run_id, status_info, attempt_number, workspace_url, workspace_id, client
            )
            print(status_display)

        # Show additional details in verbose mode
        if args.verbose > 0:
            log.debug("Full status: %s", status_info)

        return 0

    except Exception as e:
        # Check if it's a "not found" type error
        error_str = str(e).lower()
        if "not found" in error_str or "does not exist" in error_str or "resource_does_not_exist" in error_str:
            print_error(f"Run {run_id} not found. Please check the run ID and ensure you're using a Job Run ID.")
        else:
            print_error(f"Failed to get status for run {run_id}: {e}")
        if args.verbose > 0:
            raise
        return 1


def handle_cancel(args: argparse.Namespace) -> int:
    """Handle the 'cancel' command to terminate a workload.

    Args:
        args: Parsed command-line arguments containing:
            - run_id: The run ID to cancel
            - verbose: Verbosity level
            - profile: Optional Databricks profile to use

    Returns:
        int: Exit code (0=success, 1=error).
    """
    run_id: str = args.run_id

    # Log authentication context
    log_auth_context(verbose=args.verbose > 0)

    try:
        client = JobsApiClient()
        success = client.terminate_workload(run_id, reason="Canceled by user via CLI")

        if success:
            print_success(f"Successfully requested cancellation for run {run_id}")
            return 0
        else:
            print_error(f"Failed to request cancellation for run {run_id}")
            return 1

    except Exception as e:
        print_error(f"Failed to request cancellation for run {run_id}: {e}")
        if args.verbose > 0:
            raise
        return 1


def _validate_and_get_node_and_local_rank(node: Optional[int], local_rank: Optional[int]) -> tuple[int, int, int]:
    """Validate node and local_rank parameters and return validated values and exit code.

    Args:
        node: Optional node number to validate
        local_rank: Optional local rank number to validate

    Returns:
        Tuple of (validated_node, validated_local_rank, exit_code).
        If validation succeeds, exit_code is 0.
        If validation fails, exit_code is 1 and validated values should be ignored.
    """
    # sys.maxsize is a placeholder! If
    # TODO: Validate max number of nodes and actual gpu per node.
    if node is not None:
        if node < 0:
            print_error("Node must be non-negative (>= 0)")
            return 0, 0, 1
    else:
        # Default to node 0 if not specified
        node = 0

    # Validate local_rank if specified
    if local_rank is not None:
        if local_rank < 0:
            print_error("Local rank must be non-negative (>= 0)")
            return 0, 0, 1
        if local_rank > MAX_GPU_PER_NODE - 1:
            print_error(f"Local rank must be less than num GPUs per node zero indexed: {MAX_GPU_PER_NODE - 1}")
            return 0, 0, 1
    else:
        # Default to local_rank 0 if not specified
        local_rank = 0

    return node, local_rank, 0


def handle_logs(args: argparse.Namespace) -> int:
    """Handle the 'logs' command to stream or view logs from a run.

    If the run is active (PENDING/RUNNING), streams logs continuously until completion.
    If the run has completed (terminal state), prints all logs at once.
    If --review is specified, downloads logs from all nodes and filters for errors.
    If --download-only is specified, downloads logs to a directory without analyzing.

    Args:
        args: Parsed command-line arguments containing:
            - run_id: The run ID to get logs from
            - node: Optional node number to fetch logs from (0 to num_nodes-1)
            - local_rank: Optional local rank on the node (0 to gpus_per_node-1)
            - lines: Optional number of lines to print (only for completed runs).
                In review mode, this is the number of lines from the end of each log to analyze (default: 200).
            - review: Whether to download and analyze logs from all nodes
            - download_only: Optional directory path to download logs
            - verbose: Verbosity level

    Returns:
        int: Exit code (0=success, 1=error).
    """
    run_id: str = args.run_id
    node: Optional[int] = args.node
    local_rank: Optional[int] = args.local_rank
    num_lines: Optional[int] = getattr(args, "lines", None)
    review: bool = getattr(args, "review", False)
    download_only: Optional[str] = getattr(args, "download_only", None)
    lines: int = getattr(args, "lines", 200)

    # Log authentication context
    log_auth_context(verbose=args.verbose > 0)

    try:
        # Handle download-only mode: download logs to specified directory
        if download_only:
            client = JobsApiClient()

            # Get compute configuration to determine number of nodes
            print_info("Fetching compute configuration...")
            compute_config = client.get_compute_config(run_id)
            num_nodes = compute_config["num_nodes"]
            num_gpus = compute_config["num_gpus"]
            gpus_per_node = compute_config["gpus_per_node"]

            print_info(
                f"Run configuration: {num_gpus} GPUs across {num_nodes} nodes, " f"{gpus_per_node} GPUs per node"
            )

            # Create download directory if it doesn't exist
            download_path = Path(download_only).resolve()
            download_path.mkdir(parents=True, exist_ok=True)
            print_info(f"Downloading logs to: {download_path}")
            print_info(f"Downloading logs from all {num_nodes} nodes...")

            # Download logs from all nodes using multithreaded download
            node_logs = download_all_node_logs(run_id, num_nodes, str(download_path))

            if not node_logs:
                print_error("No logs were successfully downloaded from any node")
                return 1

            # Report success and location
            print_info(f"Successfully downloaded logs from {len(node_logs)} out of {num_nodes} nodes")
            print_info(f"Log files saved to: {download_path}")
            print_info("Downloaded files:")
            for node_id, log_path in sorted(node_logs.items()):
                print_info(f"  Node {node_id}: {log_path}")

            return 0

        # Handle review mode: download and analyze logs from all nodes
        if review:
            client = JobsApiClient()

            # Get compute configuration to determine number of nodes
            print_info("Fetching compute configuration...")
            compute_config = client.get_compute_config(run_id)
            num_nodes = compute_config["num_nodes"]
            num_gpus = compute_config["num_gpus"]
            gpus_per_node = compute_config["gpus_per_node"]

            print_info(f"Run configuration: {num_gpus} GPUs across {num_nodes} nodes, {gpus_per_node} GPUs per node")
            print_info(f"Downloading logs from all {num_nodes} nodes...")

            # Download logs from all nodes
            tmpdir = tempfile.mkdtemp()
            try:
                node_logs = download_all_node_logs(run_id, num_nodes, tmpdir)

                if not node_logs:
                    print_error("No logs were successfully downloaded from any node")
                    return 1

                # Display with error filtering
                display_debug_logs(node_logs, last_n_lines=lines)

                return 0
            finally:
                shutil.rmtree(tmpdir, ignore_errors=True)

        # Standard mode: validate node and local_rank parameters
        node, local_rank, exit_code = _validate_and_get_node_and_local_rank(node, local_rank)
        if exit_code != 0:
            return exit_code

        # Get the run status to determine if we should stream or print
        client = JobsApiClient()
        status_info = client.get_workload_status(run_id)
        state = status_info.get("state", {})
        lifecycle_state = state.get("life_cycle_state", "UNKNOWN")
        result_state = state.get("result_state", "")

        # Check if run is in terminal state
        is_terminal = lifecycle_state in TERMINAL_STATES or result_state in TERMINAL_RESULT_STATES

        if is_terminal:
            # Run has completed - print all logs at once
            log.debug(
                f"Run is in terminal state ({result_state or lifecycle_state}), "
                f"printing all logs from node {node}, local rank {local_rank}"
            )
            success = print_all_logs(run_id, node=node, local_rank=local_rank, num_lines=num_lines)
            return 0 if success else 1
        else:
            # Run is active - stream logs continuously
            log.debug(f"Run is active ({lifecycle_state}), streaming logs from node {node}, local rank {local_rank}")
            success = monitor_and_stream_logs(run_id, node=node, local_rank=local_rank)
            return 0 if success else 1

    except Exception as e:
        # Check if it's a "not found" type error
        error_str = str(e).lower()
        if "not found" in error_str or "does not exist" in error_str or "resource_does_not_exist" in error_str:
            print_error(f"Run {run_id} not found. Please check the run ID and ensure you're using a Job Run ID.")
        else:
            print_error(f"Failed to get logs for run {run_id}: {e}")
        if args.verbose > 0:
            raise
        return 1


# ---------------- Utilities ----------------


# ---------------- Main ----------------


def handle_get_runs(args: argparse.Namespace) -> int:
    """Handle the 'get runs' command to list submitted runs.

    Args:
        args: Parsed command-line arguments containing:
            - limit: Maximum number of runs to return
            - all: Whether to show all runs (active + completed)
            - experiment: Filter by experiment name (supports regex)
            - profile: Databricks profile to use
            - host: Databricks workspace hostname
            - verbose: Verbosity level

    Returns:
        int: Exit code (0=success, 1=error).
    """
    # Save original environment variables to restore later
    original_host = os.environ.get("DATABRICKS_HOST")
    original_profile = os.environ.get("DATABRICKS_CONFIG_PROFILE")

    try:
        import re

        host = None

        # If profile is specified, find the corresponding host
        if args.profile:
            host = find_host_for_profile(args.profile)
            if not host:
                raise RuntimeError(f"Could not find host for profile '{args.profile}' in databrickscfg")
            log.debug(f"Found host '{host}' for profile '{args.profile}'")

        # If host is specified directly, use it (overrides profile)
        if args.host:
            host = args.host
            if not host.startswith("http://") and not host.startswith("https://"):
                host = f"https://{host}"
            log.debug(f"Using host: {host}")

        if host:
            _configure_workspace_auth(host)

        # Log authentication context
        log_auth_context(verbose=args.verbose > 0)

        client = JobsApiClient(workspace_host=host)
        w = client._get_workspace_client()
        workspace_url = w.config.host.rstrip("/")
        workspace_id = w.get_workspace_id()

        # Get current user
        current_user = w.current_user.me().user_name

        active_only = not args.all
        experiment_filter = args.experiment

        # Compile regex pattern if experiment filter is provided
        experiment_pattern = None
        if experiment_filter:
            try:
                experiment_pattern = re.compile(experiment_filter)
            except re.error as e:
                print_error(f"Invalid regex pattern for experiment filter: {e}")
                return 1

        print_info(f"Fetching up to {args.limit} runs...")

        # Fetch runs with pagination
        max_iterations = 100
        all_runs = []
        next_page_token = None

        for _ in range(max_iterations):
            # Filter by SUBMIT_RUN at the API level.
            # ASSUMPTION: all sgcli workloads are headless so we intentionally exclude JOB_RUN
            response = client.list_workloads(
                active_only=active_only,
                expand_tasks=True,
                page_token=next_page_token,
                run_type="SUBMIT_RUN",
            )

            page_runs = response.get("runs", [])
            next_page_token = response.get("next_page_token")

            if not page_runs:
                break

            # Filter by current user
            page_runs = [r for r in page_runs if r.get("creator_user_name") == current_user]

            # Filter by AIR workload
            page_runs = [r for r in page_runs if _is_air_workload(r)]

            # Filter by experiment name using regex if specified
            if experiment_pattern:
                page_runs = [r for r in page_runs if experiment_pattern.search(r.get("run_name", ""))]

            # Enhance foreach runs with task IDs after filtering
            for run in page_runs:
                client.enhance_run_with_task_info(run)

            all_runs.extend(page_runs)

            # Stop if we have enough runs
            if len(all_runs) >= args.limit:
                all_runs = all_runs[: args.limit]
                break

            if not next_page_token:
                break

        if not all_runs:
            print_info("No runs found.")
            return 0

        # Check if any sweeps are present
        has_sweeps = any(run.get("is_foreach_sweep") for run in all_runs)

        # Display active filters
        console = Console()
        filter_parts = []
        filter_parts.append(f"Status: {'All runs' if not active_only else 'Active runs only'}")
        filter_parts.append(f"User: {current_user}")
        filter_parts.append("Workload type: AIR jobs only")
        if experiment_filter:
            filter_parts.append(f"Experiment filter: {experiment_filter}")
        filter_parts.append(f"Limit: {args.limit}")

        console.print(f"[bold]Active Filters:[/bold] {' | '.join(filter_parts)}\n")

        # Display runs in a table
        display_runs_table(all_runs, client, workspace_url, has_sweeps, workspace_id)
        return 0

    except Exception as e:
        print_error(f"Failed to list runs: {e}")
        if args.verbose > 0:
            raise
        return 1
    finally:
        # Restore original environment variables
        if original_host is not None:
            os.environ["DATABRICKS_HOST"] = original_host
        elif "DATABRICKS_HOST" in os.environ:
            del os.environ["DATABRICKS_HOST"]

        if original_profile is not None:
            os.environ["DATABRICKS_CONFIG_PROFILE"] = original_profile
        elif "DATABRICKS_CONFIG_PROFILE" in os.environ:
            del os.environ["DATABRICKS_CONFIG_PROFILE"]


def handle_pool_info(args: argparse.Namespace) -> int:
    """Handle the 'get pool_info' command to display GPU pool information.

    Args:
        args: Parsed command-line arguments containing:
            - profile: Databricks profile to use (handled centrally by main function)
            - host: Databricks workspace hostname
            - verbose: Verbosity level

    Returns:
        int: Exit code (0=success, 1=error).
    """
    try:
        from cli.compute import GPUType
        from cli.cli_display import display_pool_info_table

        host = None

        # If profile is specified, find the corresponding host
        # (profile env var is already set by main function via _set_profile_env)
        if args.profile:
            host = find_host_for_profile(args.profile)
            if not host:
                raise RuntimeError(f"Could not find host for profile '{args.profile}' in databrickscfg")
            log.debug(f"Found host '{host}' for profile '{args.profile}'")

        # If host is specified directly, use it (overrides profile)
        if args.host:
            host = args.host
            if not host.startswith("http://") and not host.startswith("https://"):
                host = f"https://{host}"
            log.debug(f"Using host: {host}")
            # Configure auth for explicit host (not needed for profile since main already set it)
            _configure_workspace_auth(host)

        # Log authentication context
        log_auth_context(verbose=args.verbose > 0)

        # Get workspace client to construct URLs
        w = get_workspace_client(host)
        workspace_url = w.config.host.rstrip("/")
        workspace_id = w.get_workspace_id()

        print_info("Fetching GPU pool information...")

        # Collect all pools across GPU types
        all_pools = []

        for gpu_type in GPUType:
            try:
                compute_options = get_compute_options(gpu_type, host)
                # Filter for reserved pools
                pool_options = [opt for opt in compute_options if "reserved_pool" in opt]
                all_pools.extend(pool_options)
            except Exception as e:
                log.debug(f"Failed to fetch pools for GPU type {gpu_type.value}: {e}")
                # Continue to next GPU type

        # Display results
        display_pool_info_table(all_pools, workspace_url, workspace_id)
        return 0

    except Exception as e:
        print_error(f"Failed to fetch pool information: {e}")
        if args.verbose > 0:
            raise
        return 1


def handle_changelog(args: argparse.Namespace) -> int:
    """Handle the 'changelog' command to print the CLI changelog.

    This is a hidden command that prints the changelog content from the package.

    Args:
        args: Parsed command-line arguments.

    Returns:
        int: Exit code (0=success, 1=error).
    """
    try:
        changelog = get_changelog()
        print(changelog)
        return 0
    except Exception as e:
        print_error(f"Failed to retrieve changelog: {e}")
        if args.verbose > 0:
            print_exception(e, show_locals=False)
        return 1


def handle_register(args: argparse.Namespace) -> int:
    """Handle the 'register' command to register a Docker image.

    Credential resolution:
    1. If --scope/--key provided -> use directly.
    2. If --interactive-authenticate provided -> interactive prompt, then register.
    3. If neither -> assume public, fail with helpful message on auth error.
    """
    docker_image_url = args.docker_image_url
    tag_policy = parse_image_policy(args.tag_policy)
    scope = args.scope
    key = args.key
    interactive_authenticate = args.interactive_authenticate
    timeout_minutes = args.timeout_minutes

    if (scope and not key) or (key and not scope):
        print_error("Both --scope and --key must be provided together.")
        return 1

    if interactive_authenticate and (scope or key):
        print_error("--interactive-authenticate cannot be used with --scope/--key.")
        return 1

    try:
        host = None
        if args.profile:
            host = find_host_for_profile(args.profile)
            if not host:
                raise RuntimeError(f"Could not find host for profile '{args.profile}' in databrickscfg")
            log.debug(f"Found host '{host}' for profile '{args.profile}'")
            _configure_workspace_auth(host)

        log_auth_context(verbose=args.verbose > 0)

        # --interactive-authenticate: interactive credential setup
        if interactive_authenticate:
            print_info("Running interactive credential setup...")
            scope, key = setup_docker_credentials_interactive(workspace_host=host)

        # No credentials: check existing registration before attempting
        if not scope:
            client = ImageClient(workspace_host=host)
            existing = client.get_image(docker_image_url)

            if existing is not None:
                if existing.status == ImageStatus.AVAILABLE:
                    sha = existing.manifest_sha256[:16] + "..." if existing.manifest_sha256 else "unknown"
                    print_info(f"Image already registered and available: {sha}")
                    print("\nTo use this image in your training config:")
                    print("  environment:")
                    print("    docker_image:")
                    print(f"      url: {docker_image_url}")
                    return 0

                elif existing.status in (ImageStatus.PENDING, ImageStatus.IMPORTING):
                    print_info(f"Image upload in progress ({existing.status.value}), waiting...")
                    client.wait_for_image_ready(
                        docker_image_url=docker_image_url,
                        timeout_seconds=timeout_minutes * 60,
                        verbose=(args.verbose >= 1),
                    )
                    print_info("Image ready")
                    print("\nTo use this image in your training config:")
                    print("  environment:")
                    print("    docker_image:")
                    print(f"      url: {docker_image_url}")
                    return 0

                elif existing.status == ImageStatus.FAILED:
                    print_warning(f"Previous registration failed: {existing.status_message or 'Unknown'}")

        # --- Proceed with registration ---
        print_info(f"Registering image: {docker_image_url}")
        print_info(f"Tag policy: {tag_policy.value}")
        if scope:
            print_info(f"Using credentials: {scope}/{key}")

        handler = ImagePolicyHandler(
            workspace_host=host,
            credentials_scope=scope,
            credentials_key=key,
        )

        try:
            result = handler.resolve_image(
                docker_image_url=docker_image_url,
                tag_policy=tag_policy,
                wait_for_ready=True,
                timeout_seconds=timeout_minutes * 60,
                verbose=(args.verbose >= 1),
            )
        except Exception as e:
            err = str(e).lower()
            if any(kw in err for kw in ("401", "403", "unauthorized", "authentication", "access denied")):
                raise RuntimeError(
                    f"Image '{docker_image_url}' was not found and/or requires credentials to access.\n"
                    f"Please first ensure the image URL is correct.\n\n"
                    f"If the image requires authentication, use --scope and --key:\n"
                    f"  sgcli register image {docker_image_url} --scope <scope> --key <key>\n\n"
                    f"Or use --interactive-authenticate for interactive credential setup:\n"
                    f"  sgcli register image {docker_image_url} --interactive-authenticate\n"
                ) from e
            raise

        sha_display = result.manifest_sha256[:16] + "..." if result.manifest_sha256 else "unknown"
        if result.image_updated:
            print_info(f"Image registered: {sha_display}")
        else:
            print_info(f"Using cached image: {sha_display}")

        print("\nTo use this image in your training config:")
        print("  environment:")
        print("    docker_image:")
        print(f"      url: {docker_image_url}")
        if scope:
            print("\nTo reuse these credentials:")
            print(f"  sgcli register image {docker_image_url} --scope {scope} --key {key}")

        return 0

    except Exception as e:
        print_error(f"Failed to register image: {e}")
        if args.verbose > 0:
            raise
        return 1


def main(argv: Optional[list[str]] = None) -> int:
    # Handle custom YAML help before argparse processes arguments
    argv = argv if argv is not None else sys.argv[1:]
    if len(argv) >= 2 and argv[0] == "-h" and argv[1].startswith("config"):
        yaml_help_topic = argv[1]
        display_yaml_help(yaml_help_topic)
        return 0

    parser = create_parser()
    args = parser.parse_args(argv)

    configure_logging(args.verbose)

    # Centralized profile management: temporarily set profile if specified
    original_profile = _set_profile_env(getattr(args, "profile", None))

    try:
        return args.func(args)
    except KeyboardInterrupt:
        logging.getLogger("sgcli").error("Interrupted.")
        return 1
    except SystemExit as e:
        raise e
    except Exception as e:
        # In verbose mode, show colored traceback; otherwise log cleanly.
        if getattr(args, "verbose", 0) > 0:
            print_exception(e, show_locals=False)
            return 1
        logging.getLogger("sgcli").error("Error: %s", e)
        return 1
    finally:
        # Restore original profile to prevent mutation of terminal session
        _restore_profile_env(original_profile)


if __name__ == "__main__":
    sys.exit(main())
