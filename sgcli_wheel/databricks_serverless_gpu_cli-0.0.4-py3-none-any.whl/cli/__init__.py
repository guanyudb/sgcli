"""Databricks Serverless GPU CLI package."""

__version__ = "0.0.4"
__git_sha__ = "5e88555601a03cfcf67da75372606afa26d78885"
