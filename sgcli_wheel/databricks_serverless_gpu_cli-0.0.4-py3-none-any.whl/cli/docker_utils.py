"""Docker image utilities for SGCLI."""

import logging
from typing import Any, Dict, Optional

from cli.image_registration import ImageClient, ImageStatus

log = logging.getLogger(__name__)


def _get_docker_image_url_from_yaml(raw_dict: Dict[str, Any]) -> Optional[str]:
    """Extract docker_image.url from the raw YAML dict if present."""
    environment = raw_dict.get("environment", {})
    if not isinstance(environment, dict):
        return None
    docker_image = environment.get("docker_image", {})
    if not isinstance(docker_image, dict):
        return None
    url = docker_image.get("url")
    if url and isinstance(url, str):
        return url.strip() or None
    return None


def maybe_wait_for_docker_image_cache(
    raw_dict: Dict[str, Any],
    workspace_host: Optional[str],
    timeout_seconds: int = 3600,
) -> None:
    """Check if docker image from YAML config is registered and wait if needed.

    - If not registered: raise error (must register first)
    - If PENDING/IMPORTING: wait for AVAILABLE before continuing
    - If AVAILABLE: log and continue
    - If FAILED: raise error (must fix and re-register)

    Args:
        raw_dict: Raw YAML configuration dictionary.
        workspace_host: Optional workspace host URL.
        timeout_seconds: Timeout for waiting for image to become available.

    Raises:
        RuntimeError: If image is not registered or registration failed.
        TimeoutError: If waiting for image times out.
    """
    docker_image_url = _get_docker_image_url_from_yaml(raw_dict)
    if not docker_image_url:
        return  # No docker image specified

    log.info(f"Docker image: {docker_image_url}")

    client = ImageClient(workspace_host=workspace_host)
    registration = client.get_image(docker_image_url)

    if registration is None:
        raise RuntimeError(
            f"Docker image not registered: {docker_image_url}\n"
            f"Register the image first: sgcli image register {docker_image_url}"
        )

    if registration.status == ImageStatus.AVAILABLE:
        sha_display = registration.manifest_sha256[:16] + "..." if registration.manifest_sha256 else "unknown"
        log.info(f"Using cached image: {sha_display}")
        return

    if registration.status == ImageStatus.PENDING or registration.status == ImageStatus.IMPORTING:
        log.info(f"Docker image registration in progress: {registration.status.value}")
        log.info("Waiting for image to become available before submitting job...")
        final_reg = client.wait_for_image_ready(
            docker_image_url=docker_image_url,
            timeout_seconds=timeout_seconds,
            verbose=False,
        )
        sha_display = final_reg.manifest_sha256[:16] + "..." if final_reg.manifest_sha256 else "unknown"
        log.info(f"Image ready: {sha_display}")
        return

    if registration.status == ImageStatus.FAILED:
        raise RuntimeError(
            f"Docker image registration failed: {registration.status_message or 'Unknown error'}\n"
            f"Fix the issue and re-register: sgcli image register {docker_image_url}"
        )
