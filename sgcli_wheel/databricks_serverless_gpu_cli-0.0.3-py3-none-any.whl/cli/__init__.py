"""Databricks Serverless GPU CLI package."""

__version__ = "0.0.3"
