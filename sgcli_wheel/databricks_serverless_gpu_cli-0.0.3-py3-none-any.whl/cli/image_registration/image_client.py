"""Image Registration API client for SGCLI."""

import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any, Optional, List

from cli.utils import get_workspace_client
from databricks.sdk import WorkspaceClient

log = logging.getLogger(__name__)


class ImageStatus(Enum):
    """Status of an image registration."""

    PENDING = "PENDING"
    IMPORTING = "IMPORTING"
    AVAILABLE = "AVAILABLE"
    FAILED = "FAILED"


@dataclass
class ImageRegistration:
    """Represents a registered image with its status and metadata."""

    docker_image_url: str
    status: ImageStatus
    status_message: Optional[str] = None

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "ImageRegistration":
        """Create an ImageRegistration from API response data."""
        status_str = data.get("state", "PENDING")
        try:
            status = ImageStatus(status_str)
        except ValueError:
            status = ImageStatus.PENDING
        return cls(
            docker_image_url=data.get("docker_image_url", ""),
            status=status,
            status_message=data.get("status_message"),
        )


def normalize_docker_image_url(image_url: str) -> str:
    """Normalize a Docker image URL for consistent hashing.

    Args:
        image_url: Docker image URL (e.g., "pytorch/pytorch:2.0.0")

    Returns:
        Normalized URL with docker.io prefix and tag
    """
    url = image_url.strip()
    if not url.startswith("docker.io/"):
        url = f"docker.io/{url}"
    if ":" not in url.split("/")[-1]:
        url = f"{url}:latest"
    return url


class ImageClient:
    """Client for AI Compute Manager Image Service."""

    API_PATH = "/api/2.0/ai-compute-manager/images"

    def __init__(self, workspace_host: Optional[str] = None):
        """Initialize the ImageClient."""
        self.workspace_host = workspace_host
        self._workspace_client: Optional[WorkspaceClient] = None

    def _get_workspace_client(self) -> WorkspaceClient:
        """Get or create a WorkspaceClient instance."""
        if self._workspace_client is None:
            self._workspace_client = get_workspace_client(workspace_host=self.workspace_host)
        return self._workspace_client

    def _api_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Make an API request to AICM Image Service."""
        w = self._get_workspace_client()
        path = f"{self.API_PATH}{endpoint}"

        try:
            response = w.api_client.do(method, path, body=data, query=params)
            return response if response else {}
        except Exception as e:
            error_msg = str(e)
            raise RuntimeError(f"Image API request failed: {error_msg}") from e

    def create_image(
        self,
        docker_image_url: str,
        credentials_scope: Optional[str] = None,
        credentials_key: Optional[str] = None,
    ) -> ImageRegistration:
        """Register a new Docker image.

        Args:
            docker_image_url: Full Docker image URL
            credentials_scope: Databricks secret scope for registry credentials
            credentials_key: Databricks secret key for registry credentials

        Returns:
            ImageRegistration with the created image details
        """
        normalized_url = normalize_docker_image_url(docker_image_url)
        data: Dict[str, Any] = {"docker_image_url": normalized_url}

        if credentials_scope and credentials_key:
            data["credentials_scope"] = credentials_scope
            data["credentials_key"] = credentials_key

        log.debug(f"Registering image: {normalized_url}")
        response = self._api_request(method="POST", endpoint="", data=data)
        image_data = response.get("image", response)
        return ImageRegistration.from_api_response(image_data)

    def get_image(self, docker_image_url: str) -> Optional[ImageRegistration]:
        """Get an image registration by URL using :get endpoint.

        Args:
            docker_image_url: Docker image URL

        Returns:
            ImageRegistration if found, None otherwise
        """
        normalized_url = normalize_docker_image_url(docker_image_url)
        params = {"docker_image_url": normalized_url}

        try:
            response = self._api_request(method="GET", endpoint=":get", params=params)
            return ImageRegistration.from_api_response(response)
        except RuntimeError as e:
            error_str = str(e).lower()
            if "not_found" in error_str or "not registered" in error_str:
                return None
            raise

    def list_images(self) -> List[ImageRegistration]:
        """List all registered images for the current user.

        Returns:
            List of ImageRegistration objects
        """
        response = self._api_request(method="GET", endpoint="")
        images = response.get("images", [])
        return [ImageRegistration.from_api_response(img) for img in images]

    def delete_image(self, docker_image_url: str) -> None:
        """Delete an image registration.

        Args:
            docker_image_url: Docker image URL to delete
        """
        normalized_url = normalize_docker_image_url(docker_image_url)
        params = {"docker_image_url": normalized_url}
        self._api_request(method="DELETE", endpoint=":delete", params=params)

    def wait_for_image_ready(
        self,
        docker_image_url: str,
        timeout_seconds: int = 900,
        poll_interval: int = 5,
        verbose: bool = False,
    ) -> ImageRegistration:
        """Wait for an image to become AVAILABLE.

        Args:
            docker_image_url: Docker image URL
            timeout_seconds: Maximum time to wait (default: 10 minutes)
            poll_interval: Time between polls in seconds
            verbose: Arg to determine the logging when waiting for image status

        Returns:
            ImageRegistration when status is AVAILABLE

        Raises:
            TimeoutError: If image doesn't become ready within timeout
            RuntimeError: If image upload fails
        """
        start_time = time.time()
        last_verbose_log = 0

        def finish_progress():
            if not verbose:
                print()

        while True:
            elapsed = time.time() - start_time

            if elapsed > timeout_seconds:
                finish_progress()
                raise TimeoutError(f"Image did not become AVAILABLE within {timeout_seconds} seconds.")

            registration = self.get_image(docker_image_url)

            if registration is None:
                finish_progress()
                raise RuntimeError(f"Image registration not found: {docker_image_url}")

            if registration.status == ImageStatus.AVAILABLE:
                finish_progress()
                return registration

            if registration.status == ImageStatus.FAILED:
                finish_progress()
                error_msg = registration.status_message or "Unknown error"
                raise RuntimeError(f"Image upload failed: {error_msg}")

            elapsed_int = int(elapsed)
            status = registration.status.value

            if verbose:
                if elapsed - last_verbose_log >= 15:
                    log.info(f"Still waiting... status={status} ({elapsed_int}s elapsed)")
                    last_verbose_log = elapsed
            else:
                print(f"\r[INFO] Waiting for image... status={status} ({elapsed_int}s elapsed)   ", end="", flush=True)

            time.sleep(poll_interval)
