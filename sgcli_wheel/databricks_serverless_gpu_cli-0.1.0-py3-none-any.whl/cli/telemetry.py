"""Telemetry for sgcli - sends usage data to Databricks Logfood via /telemetry-ext.

workspace_id, pseudo_user_id, account_id, and inferred_timestamp_millis are
populated server-side by Logfood from the authenticated request context, so
the client only needs to send the event payload and a valid Bearer token.

Disable telemetry by setting SGCLI_DISABLE_TELEMETRY to any truthy value
(e.g. "1", "true", "yes").
"""

import json
import logging
import os
import platform
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Optional

import requests

from cli import __version__

log = logging.getLogger("sgcli")

DISABLE_TELEMETRY_ENV_VAR = "SGCLI_DISABLE_TELEMETRY"
_HTTP_TIMEOUT_SECS = 3.0
_UPLOAD_WAIT_SECS = 3.0
_TRUTHY = {"1", "true", "yes", "on"}


@dataclass
class SgcliRunEvent:
    """Configuration and outcome captured on every `sgcli run` invocation."""

    gpu_type: Optional[str] = None
    num_gpus: Optional[int] = None
    num_nodes: Optional[int] = None
    has_docker_image: bool = False
    has_code_snapshot: bool = False
    has_requirements: bool = False
    has_parameters: bool = False
    max_retries: int = 0
    has_timeout: bool = False
    submitted_successfully: Optional[bool] = None
    submit_latency_ms: Optional[int] = None
    code_source_uses_git: Optional[bool] = None
    via_flag: Optional[str] = None


def _is_telemetry_disabled() -> bool:
    val = os.environ.get(DISABLE_TELEMETRY_ENV_VAR, "").lower().strip()
    return val in _TRUTHY


def _fetch_databricks_token(workspace_host: str) -> Optional[str]:
    """Shell out to `databricks auth token` to get the current token (PAT or OAuth).

    After a successful create_workload call, the CLI's token cache is warm so
    this is typically near-instant. Returns None on any failure; never raises.
    """
    try:
        result = subprocess.run(
            ["databricks", "auth", "token", workspace_host.rstrip("/")],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return json.loads(result.stdout.strip()).get("access_token")
        log.debug("telemetry: databricks auth token exited %d", result.returncode)
    except Exception as e:
        log.debug("telemetry: could not fetch token: %s", e)
    return None


def _build_proto_log_json(
    command: str,
    exit_code: int,
    execution_time_ms: int,
    run_event: Optional[SgcliRunEvent] = None,
) -> str:
    """Build a JSON-encoded FrontendLog matching the SgcliLog proto schema.

    Field names use snake_case matching the proto field names, consistent with
    how the Databricks CLI and the server-side DatabricksObjectMapper expect them.
    """
    exec_ctx: dict = {
        "cmd_exec_id": str(uuid.uuid4()),
        "version": __version__,
        "command": command,
        "operating_system": platform.system().lower(),
        "execution_time_ms": execution_time_ms,
        "exit_code": exit_code,
    }

    sgcli_log: dict = {"execution_context": exec_ctx}

    if run_event is not None:
        ev: dict = {
            "has_docker_image": run_event.has_docker_image,
            "has_code_snapshot": run_event.has_code_snapshot,
            "has_requirements": run_event.has_requirements,
            "has_parameters": run_event.has_parameters,
            "max_retries": run_event.max_retries,
            "has_timeout": run_event.has_timeout,
        }
        if run_event.gpu_type is not None:
            ev["gpu_type"] = run_event.gpu_type
        if run_event.num_gpus is not None:
            ev["num_gpus"] = run_event.num_gpus
        if run_event.num_nodes is not None:
            ev["num_nodes"] = run_event.num_nodes
        if run_event.submitted_successfully is not None:
            ev["submitted_successfully"] = run_event.submitted_successfully
        if run_event.submit_latency_ms is not None:
            ev["submit_latency_ms"] = run_event.submit_latency_ms
        if run_event.code_source_uses_git is not None:
            ev["code_source_uses_git"] = run_event.code_source_uses_git
        if run_event.via_flag is not None:
            ev["via_flag"] = run_event.via_flag
        sgcli_log["run_event"] = ev

    frontend_log = {
        "frontend_log_event_id": str(uuid.uuid4()),
        "entry": {"sgcli_log": sgcli_log},
    }
    return json.dumps(frontend_log)


def _do_upload(
    workspace_host: str,
    proto_log_json: str,
) -> None:
    """Fetch token, then POST to /telemetry-ext. Never raises.

    Token fetching is done here (inside the background thread) so the caller
    is never blocked by a subprocess or network call.

    NOTE: items must be an empty array — the /telemetry-ext API returns 500
    otherwise. This appears to be a server-side quirk worth following up on.
    """
    try:
        token = _fetch_databricks_token(workspace_host)
        if not token:
            log.debug("telemetry: no auth token available, skipping upload")
            return

        body = {
            "uploadTime": int(time.time() * 1000),
            "items": [],
            "protoLogs": [proto_log_json],
        }
        url = f"{workspace_host.rstrip('/')}/telemetry-ext"
        response = requests.post(
            url,
            json=body,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            timeout=_HTTP_TIMEOUT_SECS,
        )
        response.raise_for_status()
        try:
            resp_body = response.json()
            raise Exception("test")
            log.debug("telemetry: upload response: %s", resp_body)
        except Exception:
            pass
        log.debug("telemetry: upload succeeded (%d)", response.status_code)
    except Exception as e:
        log.debug("telemetry: upload failed: %s", e)


def send_run_telemetry(
    workspace_host: Optional[str],
    command: str,
    exit_code: int,
    execution_time_ms: int,
    run_event: Optional[SgcliRunEvent] = None,
) -> None:
    """Upload telemetry, waiting up to _UPLOAD_WAIT_SECS. Never raises.

    Token is fetched inside the background thread via `databricks auth token`,
    which works for both PAT and OAuth users.

    Falls back to DATABRICKS_HOST env var if workspace_host is None.
    Respects SGCLI_DISABLE_TELEMETRY env var.
    """
    if _is_telemetry_disabled():
        return

    effective_host = workspace_host or os.environ.get("DATABRICKS_HOST")
    if not effective_host:
        return

    try:
        proto_log_json = _build_proto_log_json(
            command=command,
            exit_code=exit_code,
            execution_time_ms=execution_time_ms,
            run_event=run_event,
        )
        t = threading.Thread(
            target=_do_upload,
            args=(effective_host, proto_log_json),
            daemon=True,
        )
        t.start()
        t.join(timeout=_UPLOAD_WAIT_SECS)
    except Exception as e:
        log.debug("telemetry: failed to upload telemetry: %s", e)
