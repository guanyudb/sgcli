"""GPU compute type definitions and utilities.

This module defines the available GPU types for serverless compute and provides
utilities for working with GPU configurations and resource allocation.
"""

from enum import Enum
from typing import Optional


class GPUType(Enum):
    """Enumeration of available GPU types for serverless compute.

    Legacy values (H100, A10) route through the MAPI path. HardwareAcceleratorType
    enum names (GPU_*) route through the ai-training service — genai-mapi's forwarding
    gate matches gpu_type.startsWith("GPU_") on the wire.

    The GPU_* members MUST be typed canonically in yaml (case-sensitive). The
    server-side scalapb `fromName` lookup is case-sensitive, so any casing drift
    would silently break routing.
    """

    H100 = "h100_80gb"
    A10 = "a10"
    GPU_1xA10 = "GPU_1xA10"
    GPU_8xH100 = "GPU_8xH100"
    GPU_1xH100 = "GPU_1xH100"

    @classmethod
    def values(cls):
        return [gpu_type.value for gpu_type in cls]

    @classmethod
    def _missing_(cls, value: str):
        """Case-insensitive matching for LEGACY forms only (a10/h100_80gb, plus
        the a10g alias and enum-name spellings like "H100").

        GPU_* forms must match exactly — we don't canonicalize casing here because
        the server's fromName is case-sensitive and any silent normalization would
        mask bugs where the user's yaml has the wrong casing.
        """
        if not isinstance(value, str):
            return super()._missing_(value)
        if value.startswith("GPU_") or value.lower().startswith("gpu_"):
            # Explicitly reject non-canonical GPU_* casings instead of falling through
            # to a generic "not a valid GPUType" error.
            return super()._missing_(value)
        v = value.lower()
        if v == "a10g":
            return cls.A10
        for member in (cls.A10, cls.H100):
            if member.value.lower() == v or member.name.lower() == v:
                return member
        return super()._missing_(value)


class DisplayGpuType(Enum):
    """GPU type to Display mapping"""

    a10 = "A10"
    h100_80gb = "8xH100"


_GPUS_PER_NODE = {
    GPUType.A10: 1,
    GPUType.H100: 8,
    GPUType.GPU_1xA10: 1,
    GPUType.GPU_8xH100: 8,
    GPUType.GPU_1xH100: 1,
}


def get_gpus_per_node(gpu_type: GPUType) -> int:
    """Per-node GPU count for a given GPU type.

    For HardwareAcceleratorType enum forms the count is the partition count (e.g.
    GPU_1xH100 -> 1), which differs from the nominal hardware per-node count (8
    for a bare H100 machine).
    """
    if gpu_type not in _GPUS_PER_NODE:
        raise ValueError(f"Invalid GPU type: {gpu_type}")
    return _GPUS_PER_NODE[gpu_type]


def routes_to_training_service(gpu_type_str: Optional[str]) -> bool:
    """True when the yaml gpu_type routes to the ai-training service.

    genai-mapi's forwarding gate matches `startsWith("GPU_")` case-sensitively on
    the wire. yaml validation (GPUType(...)) has already rejected any non-canonical
    casing by the time this is called on cfg.gpu_type.
    """
    return gpu_type_str is not None and gpu_type_str.startswith("GPU_")
