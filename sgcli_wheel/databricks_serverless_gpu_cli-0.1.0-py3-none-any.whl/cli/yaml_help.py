"""YAML configuration help documentation for sgcli.

This module provides detailed help text for YAML configuration fields.
Use with: sgcli -h config or sgcli -h config.<field>
"""

from typing import Dict
from cli.compute import GPUType, get_gpus_per_node


def get_yaml_help_topics() -> Dict[str, str]:
    """Get all available YAML help topics.

    Returns:
        Dict mapping topic names to their help text.
    """
    return {
        "config": _get_config_overview(),
        "config.experiment_name": _get_experiment_name_help(),
        "config.run_name": _get_run_name_help(),
        "config.environment": _get_environment_help(),
        "config.compute": _get_compute_help(),
        "config.code_source": _get_code_source_help(),
        "config.max_retries": _get_max_retries_help(),
        "config.command": _get_command_help(),
        "config.parameters": _get_parameters_help(),
        "config.budget_policy_id": _get_budget_policy_id_help(),
        "config.priority": _get_priority_help(),
        "config.permissions": _get_permissions_help(),
        "config.timeout_minutes": _get_timeout_minutes_help(),
    }


def _get_config_overview() -> str:
    """Overview of YAML configuration structure."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                      SGCLI YAML CONFIGURATION HELP                         ║
╚════════════════════════════════════════════════════════════════════════════╝

The sgcli tool uses YAML files to configure distributed training workloads.
Below are the main configuration fields:

REQUIRED FIELDS:
  experiment_name    MLflow Experiment Name. Repeated submissions with same name will be in the same experiment
  environment        Python dependencies and environment variables
  compute            GPU resources (type, count)
  command            Bash command to execute on the training cluster

RECOMMENDED FIELDS:
  code_source        Upload local code to the cluster. Not needed if code already lives in Databricks (e.g., Workspace files)

OPTIONAL FIELDS:
  run_name           Name for individual MLflow run
  env_variables      Plain environment variables (key-value pairs)
  env_variables_secrets  Secret references from Databricks Secrets (scope/key format)
  max_retries        Number of retry attempts on failure (default: 0)
  parameters         Key-value parameters passed to your script under HYPERPARAMETERS_PATH environment variable
  timeout_minutes    Maximum run duration in minutes before the job is stopped
  budget_policy_id   Serverless budget policy UUID to assign to this workload
  priority           Scheduling priority (0-999) for pool workloads
  permissions        Grant permissions on submitted job and MLflow experiment

DETAILED HELP:
  Use 'sgcli -h config.<field>' for detailed information about specific fields:

    sgcli -h config.experiment_name   - Naming conventions and constraints
    sgcli -h config.run_name          - Individual run naming
    sgcli -h config.environment       - Dependencies and variables
    sgcli -h config.compute           - GPU configuration options
    sgcli -h config.code_source       - Code deployment strategies
    sgcli -h config.max_retries       - Retry behavior
    sgcli -h config.command           - Command execution options
    sgcli -h config.parameters        - Passing parameters to scripts
    sgcli -h config.budget_policy_id  - Budget policy assignment
    sgcli -h config.priority          - Scheduling priority
    sgcli -h config.permissions       - Job and experiment permissions
    sgcli -h config.timeout_minutes   - Job timeout configuration

"""


def _get_experiment_name_help() -> str:
    """Help text for experiment_name field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                         experiment_name FIELD                              ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Name used to group related runs in MLflow. This becomes part of the
  Databricks Jobs API task key, so it has specific character restrictions.

TYPE: string (required)

CONSTRAINTS:
  • Only alphanumeric characters, hyphens (-), and underscores (_) allowed
  • No periods, spaces, or other special characters

MLFLOW INTEGRATION:
  The experiment_name is used to create or select an MLflow experiment.
  All runs with the same experiment_name will be grouped together in
  the MLflow UI.

"""


def _get_run_name_help() -> str:
    """Help text for run_name field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                            run_name FIELD                                  ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Optional name for individual MLflow run. Like experiment_name, this is used in
  Databricks Jobs API task keys.

TYPE: string (optional)

CONSTRAINTS:
  • Only alphanumeric characters, hyphens (-), and underscores (_) allowed
  • No periods, spaces, or other special characters

USE CASES:
  • Hyperparameter tracking: 'lr_0001_batch_32'
  • Version control: 'baseline_v3'
  • Replica tracking: 'sweep_001_replica_2'
  • Descriptive names: 'warmup-phase'

MLFLOW INTEGRATION:
  The run_name appears in MLflow UI as the run's display name, making it
  easier to identify specific runs within an experiment.

YAML EXAMPLE:
  experiment_name: gpt2-finetuning
  run_name: lr_0001_warmup_1000
  environment:
    ...

"""


def _get_environment_help() -> str:
    """Help text for environment field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          environment FIELD                                 ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Configure Python dependencies and custom Docker images for your training
  environment. Use the top-level 'env_variables' and 'env_variables_secrets'
  fields to set environment variables (compatible with docker_image too).

TYPE: object (required)

SUB-FIELDS:
  dependencies              Python packages (requirements.txt style)
  docker_image              Custom Docker image configuration (mutually exclusive with dependencies)

TOP-LEVEL FIELDS (set alongside environment, not inside it):
  env_variables             Plain environment variables (key-value pairs)
  env_variables_secrets     Secret references from Databricks Secrets

═══════════════════════════════════════════════════════════════════════════

1. DEPENDENCIES (Python packages)

   Format: Path to requirements YAML file (modeled after Databricks workspace
           base environment)

   Requirements file structure:
     version: '4'  # Optional: defaults to '4' (version 3 deprecated)
     dependencies:
       - --index-url https://pypi.org/simple
       - -r "/Workspace/Shared/requirements.txt"
       - my-library==6.1
       - /Workspace/Shared/Path/To/simplejson-3.19.3-py3-none-any.whl
       - torch==2.1.0
       - transformers==4.35.0

   Examples:
     environment:
       dependencies: requirements.yaml

     # requirements.yaml content:
     version: '4'
     dependencies:
       - torch==2.1.0
       - transformers>=4.35.0
       - numpy>=1.20.0

     # With environment variables for paths:
     version: '4'
     dependencies:
       - -r $HOME/verl/requirements.txt
       - torch==2.0.0

   Tips:
     • Use --index-url to specify PyPI index
     • Use -r to reference other requirements.txt files
     • Supports direct package specifications (e.g., my-library==6.1)
     • Supports wheel files with absolute paths
     • Environment variables like $HOME are expanded at runtime
     • See: https://docs.databricks.com/aws/en/admin/workspace-settings/base-environment

═══════════════════════════════════════════════════════════════════════════

2. ENV_VARIABLES (Plain environment variables)

   Format: Key-value dictionary

   Examples:
     env_variables:
       NCCL_DEBUG: INFO
       TORCH_DISTRIBUTED_DEBUG: DETAIL

     # Configuration flags
     env_variables:
       TOKENIZERS_PARALLELISM: "false"
       OMP_NUM_THREADS: "8"

     # Runtime variable interpolation — $VARNAME is expanded by the shell on
     # each node when the launch script runs. Example you can use $NODE_RANK to
     # set a specific name of the node.
     env_variables:
       NODENAME: "node_$NODE_RANK" # Becomes node_1 on node 1
       LOG_DIR: "/logs/$NODE_RANK" # Becomes /logs/1 on node 1

   Tips:
     • Quote numeric strings to avoid YAML interpretation
     • Use for non-sensitive configuration
     • Visible in logs and job metadata
     • $VARNAME references are expanded at runtime

═══════════════════════════════════════════════════════════════════════════

3. ENV_VARIABLES_SECRETS (Secret references)

   Format: Key-value dictionary mapping env var names to secret references
   Secret format: 'scope/key'

   Examples:
     env_variables_secrets:
       HUGGING_FACE_TOKEN: my_scope/hf_token
       WANDB_API_KEY: my_scope/wandb_key
       AWS_ACCESS_KEY_ID: aws_scope/access_key

   Prerequisites:
     1. Create secret scope: databricks secrets create-scope my_scope
     2. Add secret: databricks secrets put my_scope hf_token

   Tips:
     • Use for API keys, tokens, credentials
     • Format must be 'scope/key' (no spaces)
     • Secrets are never logged or displayed
     • Both scope and key must be non-empty

═══════════════════════════════════════════════════════════════════════════

4. DOCKER_IMAGE (Custom container)

  [THIS FEATURE IS NOT YET RELEASED]

   IMPORTANT: docker_image is mutually exclusive with dependencies.
   You cannot use docker_image with dependencies.
   Use the top-level env_variables and env_variables_secrets fields alongside
   docker_image to set environment variables.

   Format: Object with url, credentials_scope, credentials_key

   Supported registries:
     - Docker Hub (implicit):  org/repo:tag
     - Docker Hub (explicit):  docker.io/org/repo:tag
     - GitLab registry:        registry.gitlab.com/org/repo:tag

   Examples:
     # Docker Hub image
     environment:
       docker_image:
         url: myorg/training-image:v1.2

     # GitLab container registry
     environment:
       docker_image:
         url: registry.gitlab.com/mygroup/myproject:latest

     # Private registry with credentials
     environment:
       docker_image:
         url: gcr.io/myproject/training:latest
         credentials_scope: docker_scope
         credentials_key: gcr_credentials

   Use cases:
     • Complex dependencies that are hard to install
     • Pre-built environments with system packages
     • Reproducible environments across teams
     • Custom CUDA/cuDNN versions

═══════════════════════════════════════════════════════════════════════════

COMPLETE EXAMPLES:

  # Standard Python environment with secrets
  environment:
    dependencies: requirements.yaml
  env_variables:
    NCCL_DEBUG: INFO
    WANDB_PROJECT: gpt2-finetuning
  env_variables_secrets:
    WANDB_API_KEY: my_scope/wandb_key
    HUGGING_FACE_TOKEN: my_scope/hf_token

  # Custom container image with environment variables
  environment:
    docker_image:
      url: myorg/pytorch-training:2.1-cuda12        # Docker Hub
      # url: registry.gitlab.com/mygroup/myimage:v1  # or GitLab registry
  env_variables:
    NCCL_DEBUG: INFO
  env_variables_secrets:
    HF_TOKEN: my_scope/hf_token

  # Minimal environment (no dependencies)
  environment: {}

"""


def _get_compute_help() -> str:
    """Help text for compute field."""
    # Get available GPU types dynamically
    gpu_types = []
    for gpu in GPUType:
        gpus_per_node = get_gpus_per_node(gpu)
        gpu_types.append(f"  • {gpu.value:15s} - {gpus_per_node} GPUs per node")

    gpu_types_str = "\n".join(gpu_types)

    return f"""
╔════════════════════════════════════════════════════════════════════════════╗
║                            compute FIELD                                   ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Specify GPU resources for your training workload. GPU counts must match
  the hardware topology (multiples of GPUs per node).

TYPE: object (required)

REQUIRED SUB-FIELDS:
  gpus         Number of GPUs (must be positive, multiple of GPUs per node)
  gpu_type     Type of GPU to use

OPTIONAL SUB-FIELDS:
  gpu_node_pool_id    Databricks node pool ID (mutually exclusive with gpu_pool_name)
  gpu_pool_name       Human-readable pool name (mutually exclusive with gpu_node_pool_id)

═══════════════════════════════════════════════════════════════════════════

SUPPORTED GPU TYPES:

{gpu_types_str}

═══════════════════════════════════════════════════════════════════════════

GPU COUNT REQUIREMENTS:

  GPU counts must be multiples of GPUs per node for proper hardware utilization.

  Examples:
    ✓ Valid:
      gpu_type: h100  # 8 GPUs per node
        gpus: 8            # 1 node
        gpus: 16           # 2 nodes
        gpus: 64           # 8 nodes

      gpu_type: a10        # 4 GPUs per node
        gpus: 4            # 1 node
        gpus: 8            # 2 nodes
        gpus: 12           # 3 nodes

    ✗ Invalid:
      gpu_type: h100
        gpus: 12           # Not a multiple of 8

      gpu_type: a10
        gpus: 7            # Not a multiple of 4

═══════════════════════════════════════════════════════════════════════════

COMPLETE EXAMPLES:

  # Single-node H100 training
  compute:
    gpus: 8
    gpu_type: h100

  # Development/debugging with fewer GPUs
  compute:
    gpus: 4
    gpu_type: a10

  # Large-scale training
  compute:
    gpus: 128
    gpu_type: h100

"""


def _get_code_source_help() -> str:
    """Help text for code_source field (snapshot only)."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          code_source FIELD                                 ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Configure how your code is deployed to the training cluster. The snapshot type
  creates a compressed snapshot of your local directory or git repository, which is
  then extracted on all worker nodes before execution.

  A directory is detected as a git repository if it contains a .git entry (directory
  or file for worktrees/submodules). Non-git directories are archived as plain tarballs
  and cannot use git-specific fields (git_branch, git_commit, allow_uncommitted,
  remote_alias, use_remote_head).

  .gitignore is respected in all cases: git repos honor it via git archive; plain
  tarballs apply .gitignore patterns as tar --exclude rules (negation patterns and
  mid-path ** are not supported).

STRUCTURE:

  code_source:
    type: snapshot              # Deployment strategy
    snapshot:                   # Snapshot configuration
      repo_path: <path>         # Local directory to package
      ... other options ...

═══════════════════════════════════════════════════════════════════════════

`snapshot` TYPE - Package local directory or git repository

  Required field:
    repo_path           Path to local directory containing your code

  Optional fields:
    remote_volume       Upload to Unity Catalog volume (/Volumes/...) rather than Workspace
    git_commit          Use a specific git commit SHA (mutually exclusive with git_branch)
    git_branch          Use committed HEAD of a specific branch; uncommitted local changes are ignored (mutually exclusive with git_commit)
    allow_uncommitted   Include uncommitted working-directory changes in snapshot (default: false; incompatible with git_branch, git_commit, use_remote_head)
    include_paths       List of specific relative paths to include (cannot be empty list, no '..' traversal)
    use_remote_head     Fetch and use remote HEAD of the branch instead of local HEAD (requires git_branch)
    remote_alias        Git remote name to fetch from when use_remote_head is true (default: auto-detected)

code_source on remote compute

The last folder name in `repo_path` becomes the code source folder under
`/databricks/code_source/`. The `CODE_SOURCE_PATH` environment variable is set
to the full path of that folder.
Example: if `repo_path` is `/path/to/repo`, the code is extracted to
`/databricks/code_source/repo`, and `CODE_SOURCE_PATH=/databricks/code_source/repo`.
To access user code, run `cd $CODE_SOURCE_PATH`.
═══════════════════════════════════════════════════════════════════════════

BASIC EXAMPLES:

  # Simple snapshot of current directory
  code_source:
    type: snapshot
    snapshot:
      repo_path: /home/username/my_repository

  # Snapshot specific subdirectory
  code_source:
    type: snapshot
    snapshot:
      repo_path: /home/username/my_repository/training

  # Use local HEAD of main branch (no remote fetch).
  code_source:
    type: snapshot
    snapshot:
      repo_path: /home/username/my_repository
      git_branch: main

  # Fetch and use the remote HEAD of a branch (e.g. a colleague's latest changes).
  code_source:
    type: snapshot
    snapshot:
      repo_path: /home/username/my_repository
      git_branch: feature/new-model
      use_remote_head: true

  # Use a specific remote when multiple remotes exist.
  code_source:
    type: snapshot
    snapshot:
      repo_path: /home/username/my_repository
      git_branch: main
      use_remote_head: true
      remote_alias: upstream  # Fetch from 'upstream' instead of auto-detected remote

  # Include uncommitted working-directory changes (cannot be combined with git_branch/git_commit).
  code_source:
    type: snapshot
    snapshot:
      repo_path: /home/username/my_repository
      allow_uncommitted: true

═══════════════════════════════════════════════════════════════════════════

SELECTIVE SNAPSHOTS (include_paths):

  Package only specific files/directories if using a large monorepo.

  Requirements:
    • Works with both git repositories and non-git directories
    • Paths must be relative (no leading /)
    • No parent directory traversal (..)
    • Cannot be empty list

  Examples:

    # Include only training code and configs
    code_source:
      type: snapshot
      snapshot:
        repo_path: /home/username/my_repository
        include_paths:
          - src
          - configs

═══════════════════════════════════════════════════════════════════════════

UNCOMMITTED CHANGES — BEHAVIOR REFERENCE

  git_branch  git_commit  use_remote_head  allow_uncommitted  Uncommitted  Behavior
  ----------  ----------  ---------------  -----------------  -----------  --------
  not set     not set     false            false              none         Uses current checked-out HEAD; cached
  not set     not set     false            false              present      ERROR — commit changes or set allow_uncommitted: true
  not set     not set     false            true               any          Uses working directory including uncommitted changes; not cached
  set         not set     false            false              none         Uses local HEAD of branch; cached
  set         not set     false            false              present      ERROR — commit changes first, or pin with git_commit: <sha>
  set         not set     true             false              none         Uses remote HEAD of branch; cached
  set         not set     true             false              present      Uses remote HEAD of branch; uncommitted changes ignored; cached
  not set     set         false            false              none         Uses specified commit; cached
  not set     set         false            false              present      Uses specified commit; uncommitted changes ignored; cached
  set         set         (any)            (any)              any          INVALID — git_branch and git_commit are mutually exclusive
  set         not set     (any)            true               any          INVALID — allow_uncommitted cannot be combined with git_branch
  not set     set         (any)            true               any          INVALID — allow_uncommitted cannot be combined with git_commit
  not set     not set     true             (any)              any          INVALID — use_remote_head requires git_branch

  Note: when include_paths is set without git_branch/git_commit, uncommitted changes
  only trigger the error (or allow_uncommitted fallback) if they overlap with the
  included paths. Changes outside include_paths are always ignored.

═══════════════════════════════════════════════════════════════════════════

"""


def _get_max_retries_help() -> str:
    """Help text for max_retries field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          max_retries FIELD                                 ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Number of times to automatically retry the job if it fails. Useful for
  handling transient failures.

TYPE: integer (optional)

CONSTRAINTS:
  • Must be >= 0
  • Default: 0 (no retries)

VALUES:
  0  - No retries (fail immediately on error)
  1  - Retry once (2 total attempts)
  2  - Retry twice (3 total attempts)
  3+ - Multiple retries

═══════════════════════════════════════════════════════════════════════════

"""


def _get_command_help() -> str:
    """Help text for command field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                            command FIELD                                   ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Multi-line bash command to execute on the training cluster. 
  This is the recommended way to execute your script.

TYPE: string (multi-line, optional but one script field required)

CONSTRAINTS:
  • Cannot be empty
  • Maximum 500 lines
  • Executed as bash script on each worker node

═══════════════════════════════════════════════════════════════════════════

ERROR HANDLING:

  Scripts run with `set -euo pipefail` by default:
    -e           exit immediately on any command failure
    -u           treat unset variables as errors
    -o pipefail  fail the pipeline if any stage fails

  To disable strict mode for a section or the whole script, prepend:
    set +e +u +o pipefail

  Fail fast on any error:
    command: |
      python preprocess.py
      python train.py         # never runs if preprocess fails

  Ignore errors for a specific command:
    command: |
      set +e
      optional_cleanup_step   # failures tolerated
      set -e
      python train.py

  NOTE: The same strict-mode wrapping applies to bash_script.

═══════════════════════════════════════════════════════════════════════════

EXAMPLES:

  # Simple Python training script
  experiment_name: simple-training
  compute:
    gpus: 8
    gpu_type: h100
  code_source:
    type: snapshot
    snapshot:
      repo_path: /home/username/my-repo
  command: |
    cd $CODE_SOURCE_PATH
    python train.py --epochs 10 --batch-size 32

ADVANCED EXAMPLES:

  # Distributed training with torchrun
  experiment_name: distributed-training
  compute:
    gpus: 64
    gpu_type: h100
  code_source:
    type: snapshot
    snapshot:
      repo_path: /home/username/my-repo
  command: |
    cd $CODE_SOURCE_PATH
    torchrun \\
      --nproc_per_node=8 \\
      --nnodes=$NUM_NODES \\
      --node_rank=$NODE_RANK \\
      --master_addr=$MASTER_ADDR \\
      --master_port=$MASTER_PORT \\
      train.py --epochs 100

═══════════════════════════════════════════════════════════════════════════

ENVIRONMENT VARIABLES:

  The following environment variables are automatically available on each node:

  Code source:
  • CODE_SOURCE_PATH   - Absolute path to the extracted code_source directory
                          on the remote node (e.g. /databricks/code_source/my-repo).
                          Use `cd $CODE_SOURCE_PATH` to enter your repo.

  Distributed training:
  • MASTER_ADDR       - Address of the master node
  • MASTER_PORT       - Port for distributed coordination
  • NUM_NODES         - Total number of nodes
  • NODE_RANK         - Rank of current node (0 to NUM_NODES-1)
  • LOCAL_RANK        - Local GPU rank on current node
  • RANK              - Global GPU rank across all nodes (NODE_RANK * gpus_per_node + LOCAL_RANK)
  • WORLD_SIZE        - Total number of GPUs across all nodes
  • LOCAL_WORLD_SIZE  - Number of GPUs on this node

  Other:
  • MLFLOW_RUN_ID               - MLflow run ID for the current job (use this to
                                   log metrics/artifacts to the right run)
  • HYPERPARAMETERS_PATH        - Path to YAML file containing parameters: values
                                   (only set when parameters: is defined in config)

  Example usage:
    command: |
      cd $CODE_SOURCE_PATH
      echo "Node $NODE_RANK of $NUM_NODES"
      echo "Master: $MASTER_ADDR:$MASTER_PORT"
      echo "MLflow run: $MLFLOW_RUN_ID"
      torchrun --nnodes=$NUM_NODES --node_rank=$NODE_RANK ...

═══════════════════════════════════════════════════════════════════════════
"""


def _get_parameters_help() -> str:
    """Help text for parameters field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          parameters FIELD                                  ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Key-value pairs passed to your training script. Parameters are saved as a
  YAML file and made available through the TRAINING_PARAMS environment variable.

TYPE: dictionary (optional)

FORMAT:
  parameters:
    key1: value1
    key2: value2
    nested:
      key3: value3

VALUE TYPES SUPPORTED:
  • Strings (quoted or unquoted)
  • Numbers (integers and floats)
  • Booleans (true/false)
  • Lists/arrays
  • Nested dictionaries

═══════════════════════════════════════════════════════════════════════════

HOW IT WORKS:

  1. Parameters are saved to a YAML file on the cluster
  2. Path is exposed via $HYPERPARAMETERS_PATH environment variable
  3. Your script loads the YAML file to access parameters

  In your Python script:
    import yaml
    import os

    # Load parameters
    params_path = os.environ['HYPERPARAMETERS_PATH']
    with open(params_path) as f:
        params = yaml.safe_load(f)

    # Access parameters
    learning_rate = params['learning_rate']
    batch_size = params['batch_size']

═══════════════════════════════════════════════════════════════════════════

BASIC EXAMPLES:

  # Mixed types
  parameters:
    learning_rate: 0.001
    warmup_steps: 1000
    use_amp: true
    gradient_accumulation: 4
    output_dir: /dbfs/models/run_001

  # With lists
  parameters:
    layer_sizes: [512, 256, 128]
    dropout_rates: [0.1, 0.2, 0.3]
    metrics: ["accuracy", "f1", "precision"]

═══════════════════════════════════════════════════════════════════════════

NESTED PARAMETERS:

  # Organized configuration
  parameters:
    model:
      name: llama3
      size: 8b
      dtype: bfloat16

    training:
      learning_rate: 0.0001
      batch_size: 32
      epochs: 50
      warmup_ratio: 0.1

    optimization:
      optimizer: adamw
      weight_decay: 0.01
      lr_scheduler: cosine

    data:
      dataset: wikitext
      max_length: 2048
      num_workers: 4

  Access in Python:
    model_name = params['model']['name']
    lr = params['training']['learning_rate']
    optimizer = params['optimization']['optimizer']

"""


def _get_budget_policy_id_help() -> str:
    """Help text for budget_policy_id field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                        budget_policy_id FIELD                              ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Assign a serverless budget policy to this workload. The run-as user must
  have access to the specified policy.

TYPE: string (optional)

FORMAT:
  Lowercase UUID: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

CONSTRAINTS:
  • Must be a valid lowercase UUID
  • The run-as user must have access to the policy
  • Policy UUID can be found in Databricks admin settings under
    Compute > Budget policies

═══════════════════════════════════════════════════════════════════════════

EXAMPLE:

  budget_policy_id: "a1b2c3d4-e5f6-7890-abcd-ef1234567890"

"""


def _get_priority_help() -> str:
    """Help text for priority field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                           priority FIELD                                   ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Set the scheduling priority for pool workloads. Higher priority workloads
  are scheduled before lower priority ones within the same GPU pool.
  Priority maps to virtual reservation tiers in the AI Scheduler.

  NOTE: Requires a GPU pool (gpu_node_pool_id or gpu_pool_name).
  Priority is not supported for on-demand (non-pool) workloads.

TYPE: integer (optional)

CONSTRAINTS:
  • Must be between 0 and 999 (inclusive)
  • Requires gpu_node_pool_id or gpu_pool_name to be set
  • Default: not set (server default applies)

PRIORITY RANGES:
    0 -  99    Best-effort (lowest priority)
  100 - 199    Normal
  200 - 299    Critical
  300 - 999    System (reserved for internal use)

═══════════════════════════════════════════════════════════════════════════

EXAMPLE:

  # Normal priority pool workload
  compute:
    gpus: 8
    gpu_type: h100_80gb
    gpu_pool_name: "my-reserved-pool"
  priority: 150

  # Best-effort pool workload
  compute:
    gpus: 8
    gpu_type: h100_80gb
    gpu_node_pool_id: "abc123"
  priority: 50

"""


def _get_permissions_help() -> str:
    """Help text for permissions field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                          permissions FIELD                                 ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Grant permissions on the submitted job and its MLflow experiment to users,
  groups, or service principals. Uses the DABs-compatible format.

  Permissions are applied after job submission. The owner's permissions are
  always preserved.

TYPE: list of permission entries (optional)

ENTRY FORMAT:
  Each entry must specify exactly one principal and a permission level:

  Principal (choose exactly one):
    user_name                 Email address of a Databricks user
    group_name                Name of a Databricks group
    service_principal_name    Name of a service principal

  Level (required):
    level                     Permission level to grant

═══════════════════════════════════════════════════════════════════════════

PERMISSION LEVELS:

  CAN_VIEW          Read-only access
  CAN_MANAGE_RUN    Can trigger and manage job runs
  CAN_MANAGE        Full management permissions
  IS_OWNER          Owner permissions (typically not needed)

═══════════════════════════════════════════════════════════════════════════

EXAMPLES:

  # Grant view access to a group
  permissions:
    - group_name: data-engineering
      level: CAN_VIEW

  # Multiple grants
  permissions:
    - group_name: data-engineering
      level: CAN_VIEW
    - user_name: alice@example.com
      level: CAN_MANAGE
    - service_principal_name: my-etl-sp
      level: CAN_MANAGE_RUN

"""


def _get_timeout_minutes_help() -> str:
    """Help text for timeout_minutes field."""
    return """
╔════════════════════════════════════════════════════════════════════════════╗
║                        timeout_minutes FIELD                               ║
╚════════════════════════════════════════════════════════════════════════════╝

DESCRIPTION:
  Maximum duration in minutes before the job is automatically stopped.
  If not set, the job runs until completion or failure.

TYPE: integer (optional)

CONSTRAINTS:
  • Must be >= 1
  • Default: no timeout

EXAMPLE:

  timeout_minutes: 90

"""


def display_yaml_help(topic: str) -> None:
    """Display help for a specific YAML topic.

    Args:
        topic: Help topic (e.g., 'config', 'config.compute')
    """
    topics = get_yaml_help_topics()

    if topic not in topics:
        # Try to suggest similar topics
        available = list(topics.keys())
        suggestions = [t for t in available if topic in t or t in topic]

        print(f"Unknown help topic: '{topic}'")
        print("\nAvailable topics:")
        for t in sorted(available):
            print(f"  sgcli -h {t}")

        if suggestions:
            print("\nDid you mean:")
            for s in suggestions[:3]:
                print(f"  sgcli -h {s}")
        return

    print(topics[topic])
