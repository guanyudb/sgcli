# Start of CLI Changelog

Version 0.1.0
[internal] Add hidden --via flag and git-aware code_source telemetry signals (via_flag, code_source_uses_git).
sgcli register image: when --scope/--key and --interactive-authenticate are absent, auto-discover credentials from ~/.docker/config.json (including credHelpers/credsStore) and store them in the per-user Databricks scope, so a single docker login means subsequent registrations need no flags
[CNXT-2084] Always emit MLflow system-metrics sidecar and run-name update in the launch script, including for custom docker images, so multi-node jobs report per-node metrics.
CODE_SOURCE_PATH now points to the extracted code_source directory (e.g. /databricks/code_source/<dir_name>). Use `cd $CODE_SOURCE_PATH` instead of `cd $CODE_SOURCE/<dir>`.
Forward `credentials-for-read` response headers to the pre-signed URL fetch in `mlflow_rest_client.download_artifact`. Fixes log/artifact downloads on Azure-backed workspaces where SAS URIs require headers like `x-ms-version` to authenticate.
Declare `pydantic` and `packaging` as wheel dependencies (previously relied on transitive resolution in pre-existing venvs; required for `uv tool install` to produce a working sgcli).
Replace mlflow Python SDK with a direct Databricks MLflow REST client; drop the mlflow wheel dependency.
Drop unused wheel deps (cloudpickle, psutil, pynvml); delete vestigial cli/requirements.txt.
Emit HardwareAcceleratorType enum names (e.g. GPU_1xA10, GPU_8xH100) for on-demand workloads so genai-mapi forwards to the ai-training service. Pool workloads continue to use the legacy gpu_type strings and stay on the MAPI path.
Pass user env_variables through gen_ai_compute_task.env_vars.
sgcli register image --interactive-authenticate: validate Databricks workspace auth before prompting for the Docker username/PAT, so unauthenticated users get a clear error immediately instead of typing creds and then hitting 401
Fix `sgcli --json run --watch` returning immediately with `status=PENDING` instead of blocking until terminal. The JSON path now emits a `SUBMITTED` event with run_id, streams `STATUS`/`LOG`/`ALERT` JSONL events through the watch, then emits a final success envelope whose `status` reflects the actual terminal state (`SUCCESS`/`FAILED`/`TIMEDOUT`/`CANCELED`).
[Bug-Fix] [ES-1857723] Fix broken `$HOME/<repo>` symlink for macOS users whose snapshot repos have extended attributes; pass tar directory name from Python instead of parsing tarball contents, and exclude AppleDouble (`._*`) files from snapshot tarballs
[Bug-fix] sgcli monitor: surface every loss key and match the real per-GPU keys for auto-detected gpu_utilization / gpu_memory.
[Bug-Fix] Resolve relative repo_path in YAML config relative to the YAML file's directory, not the current working directory
[CNXT-2024] Fix: create default secret scope with open permissions; surface clear error when workspace scope quota is exceeded
Fix `register image --tag-policy latest` ignoring the policy when no --scope/--key were passed
Pass tar_workspace_path and requirements_yaml_path through gen_ai_compute_task so the server-side entry script can extract the workspace tarball and install pip dependencies.
Remove `no_interpolation` field and `--no-interpolation` flag; OmegaConf variable interpolation is now disabled unconditionally. Literal `${VAR}` strings in YAML are preserved as-is. Bash `$VAR` shell expansion at runtime on the worker node is unaffected.
Security fix: default Docker credential scope is now per-Databricks-user (docker-credentials-<user>) and creator-only, preventing cross-user PAT reads
Add DABs-compatible 'permissions' field; deprecate 'grant_permissions' with backward compatibility.
Remove embedded agent_skills; use the "sgcli" Claude Code plugin instead
Route workloads through the ai-training service when new enum type is specified.
Fix --watch and get logs hanging on quick timeout/error, show logs when job ends before reaching RUNNING, and wrap user scripts with set -euo pipefail by default.
[CNXT-2030] Normalize short-form Docker Hub image names (e.g. ubuntu:latest -> docker.io/library/ubuntu:latest)

Version 0.0.7
Fix several small bugs: Fix override bug which would silently drop second override. Protect command field from variable interpolation so bash ${VAR} work.
[Bug-fix] Fix hyperlinks in status table, show MLflow run name, suppress download bar spam, and improve error message when pool validation fails
[BugFix] Fixes a bug where run submission could exit without setting the MLflow run name
Add glob-style batch cancellation: sgcli cancel --match 'pattern' [-y]
[CNXT-1853] Add priority field for pool workload scheduling
[CNXT-1939] Create versioned composite snapshot key
Introduce CODE_SOURCE_PATH environment variable so users can locate the uploaded code.
get client telemetry working with sgcli
[Bug-Fix] Fix symlink failure when extracting git archive snapshots
Add --retry flag to `get logs` to view logs from a specific retry attempt
Update 'get runs' to show all runs by default; add --active, --all-users, and --user flags
Honor .gitignore when snapshotting non-git directories, preventing venv and other ignored files from being uploaded
[CNXT-1638] Fix --json mode to suppress human-readable output and add some caching to remove redundant auth calls
Improve CLI startup performance by ~3.5x via lazy imports of heavy dependencies (databricks-sdk, mlflow)
[Bug-Fix] Ensure MLflow sidecar cleanup runs on any exit (including failures) via EXIT trap to prevent GPU hang
[Bug-Fix] Fix stalled jobs caused by MLflow system metrics sidecar not terminating after user code completes
Decrease the timeout for MLflow api call to update the MLflow run name
Suppress noisy Apple extended-header warnings during tarball extraction
Support git worktrees and allow include_paths for non-git directories

Version 0.0.6
[CNXT-1924] Make sgcli more agent friendly. Introduce --json and monitor command
[UX] Make -p, and -v flags global flags that work before or after the subcommand
[CNXT-1891] Support runtime variable interpolation in env_variables
[Bug-Fix] Fix sandbox script for DCS to not assume any package installs
[Bug-Fix] Fix use of 'remote_head'
[Deprecation] Removed no-image-upload flag
[CNXT-1638] Support v5 client and deprecate v3
[CNXT-1887] Add email support through --email flag 
[CNXT-1877] Add client telemetry for SGCLI
[Deprecation] Removed no-image-upload flag

Version 0.0.5
[Bug-fix] Remove print_error from env_secrets
[CNXT-1859] Remove python script from sgcli
[Bug-fix] Fix uncommitted snapshot code path directories
[Bug-fix] Fix call to experiment creation.
[CNXT-1778] Add color for sgcli
[CNXT-1844] Remove git clone from cli src
[CNXT-1727] Fix bug in setting permissions in config 
[CNXT-1832] Improve perofrmance of `sgcli get runs` command
[CNXT-1784] Provide yaml pointers from sgcli tool
[CNXT-1638] Add dry run command
[CNXT-1828] Add budget policy attribution field

Version 0.0.4
[CNXT-1817] Fix uncommitted changes not being captured in snapshot. Also allows include_paths when changes are outside those paths.
[CNXT-1809] Update log syntax and allow for dowloading to a specified directory
[CNXT-1806] Add support for automatic permission granting after job submission with `grant_permissions` field.
[CNXT-1638] Make logs from dependency installation unbuffered

Version 0.0.3
[CNXT-1727] Allow uncommitted changes and simplify git UX.
[CNXT-1759] Add support non git folders.
[CNXT-1713]Add support for variable interpretation in local and remote.
[Bug-fix] Fix hardcoded email from databricks.com to actual user email.

Version 0.0.2
[CNXT-1727] Support for subfolders in snapshot via git archive. This is a major update to speed up snapshot especially in large repos.
[CNXT-1716] Remove unique suffix from job run names. Experiment corresponds exactly to Job Run name.

Version 0.0.1
[CNXT-1727] Add changelog command.
[CNXT-1706] Fix get runs hyperlinks and add get status hyperlinks.
[CNXT-1713] Add experiment_name validation and reduce log level.
[CNXT-1624] Validate fields and gpu num during workload submission.
[CNXT-1538] Add Streaming Logs capability.
