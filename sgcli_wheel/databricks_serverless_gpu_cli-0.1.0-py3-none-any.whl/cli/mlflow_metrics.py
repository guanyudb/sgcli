"""MLflow metric-reading utilities for sgcli.

Shared by `monitor` (streaming METRIC events) and future `get metrics` (one-shot history).
"""

import logging
from typing import Dict, List, Optional, Tuple

from databricks.sdk import WorkspaceClient

from cli import mlflow_rest_client

log = logging.getLogger(__name__)


def _resolve_default_keys_from_available(available_keys: List[str]) -> List[str]:
    """Resolve the auto-detected default metric keys from a run's available keys.

    Pure function — no I/O. Returns [] if nothing matches.

    Loss: every key containing 'loss', with canonical 'train/loss' and 'loss' first
    if present, others alphabetised. Multi-stage runs (stage1/loss, stage2/loss, ...)
    surface every stage instead of only the first.

    GPU util / memory: one representative per-GPU key per metric type. Matches
    MLflow SystemMetricsMonitor's actual shape `system/node_<N>/gpu_<I>_<suffix>`
    (and the legacy flat `system/gpu_<suffix>` form), and picks the lex-smallest
    hit so an N-GPU node emits one sample instead of N near-identical lines.
    """
    result: List[str] = []

    loss_keys = [k for k in available_keys if "loss" in k]
    if loss_keys:
        if "train/loss" in loss_keys:
            result.append("train/loss")
        if "loss" in loss_keys:
            result.append("loss")
        result.extend(sorted(k for k in loss_keys if k not in result))

    for suffix in ("_utilization_percentage", "_memory_usage_percentage"):
        gpu_match = sorted(k for k in available_keys if "gpu_" in k and k.endswith(suffix))
        if gpu_match:
            result.append(gpu_match[0])

    return result


def resolve_default_metric_keys(w: WorkspaceClient, mlflow_run_id: str) -> List[str]:
    """Auto-detect loss, gpu_utilization, gpu_memory keys from the run's available metrics.

    Scans the run's metrics for patterns:
      - loss:        every key containing 'loss', with 'train/loss' and 'loss' preferred
                     first if present
      - gpu_util:    smallest match for `*gpu_*_utilization_percentage` (one representative
                     across the per-GPU keys MLflow emits)
      - gpu_memory:  smallest match for `*gpu_*_memory_usage_percentage`

    Returns a list of matched keys. Returns [] if none found yet (e.g., training hasn't
    started logging yet) — caller should retry on the next poll interval.
    """
    try:
        run = mlflow_rest_client.get_run(w, mlflow_run_id)
        available_keys = list(mlflow_rest_client.metrics_as_dict(run).keys())
    except Exception as e:
        log.debug(f"Failed to get run metrics for key discovery: {e}")
        return []

    return _resolve_default_keys_from_available(available_keys)


def resolve_and_fetch_metrics(
    w: WorkspaceClient,
    mlflow_run_id: str,
    extra_keys: Optional[List[str]],
    no_default_metrics: bool,
    previously_resolved: List[str],
) -> Tuple[List[str], Dict[str, float]]:
    """Resolve default metric keys and fetch latest values in a single get_run() call.

    Accumulates resolved default keys across calls — the returned list is a superset of
    previously_resolved, growing as new metric types appear. GPU metrics often start
    logging several minutes after training loss, so re-resolving each interval is required
    to pick them up without waiting for a full restart.

    Args:
        w: WorkspaceClient used for REST calls.
        mlflow_run_id: The MLflow run ID to query.
        extra_keys: Additional user-specified metric keys beyond auto-detected defaults.
        no_default_metrics: When True, skip auto-detection; only use extra_keys.
        previously_resolved: Default keys found in prior intervals. Grows monotonically —
            keys are added as they appear but never removed.

    Returns:
        (updated_resolved_keys, metrics_dict):
          - updated_resolved_keys: superset of previously_resolved with any newly
            discovered default keys merged in.
          - metrics_dict: {key: latest_value} for all keys present in the run.
            Empty if all requested keys are missing or on API error.
    """
    try:
        run = mlflow_rest_client.get_run(w, mlflow_run_id)
    except Exception as e:
        log.debug(f"Failed to fetch run {mlflow_run_id} for metrics: {e}")
        return previously_resolved, {}

    all_metrics = mlflow_rest_client.metrics_as_dict(run)
    available_keys = list(all_metrics.keys())

    # Accumulate default keys: merge previously found with any newly discovered.
    # GPU metrics often appear later than loss, so we keep re-resolving each interval.
    updated_resolved = previously_resolved
    if not no_default_metrics:
        newly_discovered = _resolve_default_keys_from_available(available_keys)
        if newly_discovered:
            merged = list(dict.fromkeys(previously_resolved + newly_discovered))
            updated_resolved = merged

    # Build final key list: updated defaults + user-specified extras (deduplicated)
    all_keys = list(dict.fromkeys(updated_resolved + list(extra_keys or [])))

    metrics = {k: all_metrics[k] for k in all_keys if k in all_metrics}
    return updated_resolved, metrics


def fetch_latest_metrics(
    w: WorkspaceClient,
    mlflow_run_id: str,
    keys: List[str],
) -> Dict[str, float]:
    """Return {key: latest_value} for all requested keys present in the run.

    Uses a single get_run() API call. Missing keys are silently skipped
    (metrics may not be logged yet).
    """
    if not keys:
        return {}
    try:
        run = mlflow_rest_client.get_run(w, mlflow_run_id)
        all_metrics = mlflow_rest_client.metrics_as_dict(run)
    except Exception as e:
        log.debug(f"Failed to fetch metrics for run {mlflow_run_id}: {e}")
        return {}
    return {k: all_metrics[k] for k in keys if k in all_metrics}


def fetch_metric_history(
    w: WorkspaceClient,
    mlflow_run_id: str,
    keys: List[str],
    last_n: int,
) -> Dict[str, List[Dict]]:
    """Return {key: [{step, value, ts}]} for the last_n steps of each key.

    Used by `get metrics` one-shot command. Makes one API call per key.
    Entries are sorted by step ascending.

    Args:
        w: WorkspaceClient used for REST calls.
        mlflow_run_id: The MLflow run ID to query.
        keys: Metric keys to fetch history for.
        last_n: Number of most-recent steps to return. Use 0 as a sentinel to
            return the full history for each key.
    """
    result: Dict[str, List[Dict]] = {}
    for key in keys:
        try:
            history = mlflow_rest_client.get_metric_history(w, mlflow_run_id, key)
            sorted_history = sorted(history, key=lambda m: m.get("step", 0))
            tail = sorted_history[-last_n:] if last_n > 0 else sorted_history
            result[key] = [{"step": m.get("step"), "value": m.get("value"), "ts": m.get("timestamp")} for m in tail]
        except Exception as e:
            log.debug(f"Failed to fetch metric history for key '{key}': {e}")
    return result
