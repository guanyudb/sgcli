"""Simple Python SDK for sgcli operations.

Provides clean Python functions for job submission, status, logs, and cancellation
without needing to shell out to subprocess. Designed for use in integration tests.

Uses --json mode internally so all handler output is structured JSON, which is
parsed directly instead of monkey-patching internals or capturing raw stdout.

Usage:
    from cli.sdk import do_run, get_status, get_logs, do_cancel

    # Submit job
    result = do_run("path/to/config.yaml")
    run_id = result["run_id"]

    # Check status
    status = get_status(run_id)

    # Get logs
    logs = get_logs(run_id, node=0, local_rank=0)

    # Cancel job
    do_cancel(run_id)
"""

import argparse
import io
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


from cli import cli_entrypoint


def _setup_auth(workspace_host: Optional[str] = None, profile: Optional[str] = None):
    """Setup authentication environment variables.

    Args:
        workspace_host: Optional workspace URL to configure
        profile: Optional Databricks profile name
    """
    if workspace_host:
        os.environ["DATABRICKS_HOST"] = workspace_host

    if profile:
        os.environ["DATABRICKS_CONFIG_PROFILE"] = profile


def _run_handler(handler, args: argparse.Namespace) -> Dict[str, Any]:
    """Run a CLI handler with json=True and parse the JSON envelope from stdout.

    Args:
        handler: CLI handler function (e.g. cli_entrypoint.handle_run)
        args: argparse.Namespace with json=True

    Returns:
        Parsed data dict from the JSON success envelope

    Raises:
        RuntimeError: If handler returns non-zero or emits an error envelope
        ValueError: For validation errors (exit code 2)
    """
    captured = io.StringIO()
    old_stdout = sys.stdout
    try:
        sys.stdout = captured
        exit_code = handler(args)
    finally:
        sys.stdout = old_stdout

    output = captured.getvalue().strip()

    if not output:
        if exit_code == 2:
            raise ValueError("YAML validation failed")
        if exit_code != 0:
            raise RuntimeError(f"Handler failed with exit code {exit_code} (no output)")
        return {}

    envelope = json.loads(output)

    if "error" in envelope:
        err = envelope["error"]
        msg = err.get("message", "Unknown error")
        code = err.get("code", "UNKNOWN")
        if code == "INVALID_REQUEST" or exit_code == 2:
            raise ValueError(msg)
        raise RuntimeError(msg)

    return envelope.get("data", {})


def do_run(
    yaml_path: str,
    overrides: Optional[List[str]] = None,
    workspace_host: Optional[str] = None,
    profile: Optional[str] = None,
    watch: bool = False,
    verbose: int = 0,
) -> Dict[str, str]:
    """Submit a training job from YAML config.

    Args:
        yaml_path: Path to YAML configuration file
        overrides: Optional list of config overrides in KEY=VALUE format
        workspace_host: Optional workspace URL
        profile: Optional Databricks profile name
        watch: If True, stream logs until completion
        verbose: Verbosity level (0=normal, 1=verbose, 2=debug)

    Returns:
        Dictionary with run_id, status, and dashboard_url

    Raises:
        ValueError: If YAML validation fails
        RuntimeError: If job submission fails
    """
    if workspace_host or profile:
        _setup_auth(workspace_host=workspace_host, profile=profile)

    args = argparse.Namespace(
        file=Path(yaml_path),
        override=overrides or [],
        profile=profile,
        watch=watch,
        verbose=verbose,
        run_system_checks=False,
        dry_run=False,
        email=None,
        image_policy="auto",
        image_timeout=900,
        json=True,
    )

    return _run_handler(cli_entrypoint.handle_run, args)


def get_status(
    run_id: str,
    workspace_host: Optional[str] = None,
    profile: Optional[str] = None,
) -> Dict:
    """Get current status of a job.

    Args:
        run_id: Job run ID
        workspace_host: Optional workspace URL
        profile: Optional Databricks profile name

    Returns:
        Dictionary with run_id, status, lifecycle_state, result_state,
        started_at, duration_seconds, attempt_number, experiment_name,
        dashboard_url, mlflow_url.

    Raises:
        ValueError: If run not found
        RuntimeError: If status retrieval fails
    """
    if workspace_host or profile:
        _setup_auth(workspace_host=workspace_host, profile=profile)

    args = argparse.Namespace(
        run_id=run_id,
        verbose=0,
        watch=False,
        profile=profile,
        json=True,
    )

    return _run_handler(cli_entrypoint.handle_status, args)


def get_logs(
    run_id: str,
    node: int = 0,
    local_rank: int = 0,
    workspace_host: Optional[str] = None,
    profile: Optional[str] = None,
) -> Optional[str]:
    """Get logs from a completed or running job.

    Args:
        run_id: Job run ID
        node: Node number (default: 0)
        local_rank: Local rank on node (default: 0)
        workspace_host: Optional workspace URL
        profile: Optional Databricks profile name

    Returns:
        Log contents as string, or None if not available

    Raises:
        RuntimeError: If log retrieval fails
    """
    if workspace_host or profile:
        _setup_auth(workspace_host=workspace_host, profile=profile)

    args = argparse.Namespace(
        run_id=run_id,
        node=node,
        local_rank=local_rank,
        lines=None,
        debug=False,
        verbose=0,
        profile=profile,
        json=False,
    )

    # handle_logs has no json mode — capture raw stdout
    captured = io.StringIO()
    old_stdout = sys.stdout
    try:
        sys.stdout = captured
        exit_code = cli_entrypoint.handle_logs(args)
    except Exception as e:
        raise RuntimeError(f"Failed to get logs: {e}") from e
    finally:
        sys.stdout = old_stdout

    if exit_code != 0:
        return None

    return captured.getvalue()


def do_cancel(
    run_id: str,
    workspace_host: Optional[str] = None,
    profile: Optional[str] = None,
) -> bool:
    """Cancel a running job.

    Args:
        run_id: Job run ID
        workspace_host: Optional workspace URL
        profile: Optional Databricks profile name

    Returns:
        True if cancellation accepted, False otherwise
    """
    if workspace_host or profile:
        _setup_auth(workspace_host=workspace_host, profile=profile)

    args = argparse.Namespace(
        run_id=run_id,
        verbose=0,
        profile=profile,
        json=True,
    )

    try:
        data = _run_handler(cli_entrypoint.handle_cancel, args)
        return data.get("cancel_requested", False)
    except Exception:
        return False
