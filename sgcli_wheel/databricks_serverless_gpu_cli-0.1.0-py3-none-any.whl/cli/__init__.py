"""Databricks Serverless GPU CLI package."""

# NOTE: version and git sha are determined at release time; the versions listed here are placeholders
__version__ = "0.1.0"
__git_sha__ = "575ea72a044aed8afd67fdc009e31391edc8c126"
