"""Thin REST client for the Databricks-hosted MLflow API.

- `get_run` — run info + current metric snapshot (GET /api/2.0/mlflow/runs/get)
- `get_metric_history` — full history for a metric key
  (GET /api/2.0/mlflow/metrics/get-history)
- `list_artifacts` — artifact listing under a prefix, with pagination
  (GET /api/2.0/mlflow/artifacts/list)
- `download_artifact` — two-step credential-vending download that mirrors what
  the mlflow SDK does for Databricks-backed runs
  (GET /api/2.0/mlflow/artifacts/credentials-for-read → pre-signed URL fetch)

Auth is handled entirely by the caller's `WorkspaceClient`, which already
resolves `DATABRICKS_CONFIG_PROFILE` → `~/.databrickscfg` → host/token.
"""

import logging
import os
import tempfile
from typing import Any, Dict, List, Optional

import requests
from databricks.sdk import WorkspaceClient

log = logging.getLogger(__name__)

# Chunk size for streaming artifact bytes to disk via requests.iter_content.
# 8 KiB matches the `requests` library default — large enough to amortize
# syscall overhead, small enough to keep per-chunk memory negligible.
_DOWNLOAD_CHUNK_BYTES = 8192


def get_run(w: WorkspaceClient, run_id: str) -> Dict[str, Any]:
    """Fetch a run via GET /api/2.0/mlflow/runs/get."""
    response = w.api_client.do("GET", "/api/2.0/mlflow/runs/get", query={"run_id": run_id})
    return response.get("run") or {}


def metrics_as_dict(run: Dict[str, Any]) -> Dict[str, float]:
    """Flatten a run's `data.metrics` list into a {key: latest_value} dict.

    The MLflow `runs/get` REST response returns a list of metric entries; the
    SDK used to pre-flatten them into a dict. Callers that previously did
    `run.data.metrics[key]` should go through this helper instead.
    """
    return {m["key"]: m["value"] for m in run.get("data", {}).get("metrics", []) if "key" in m}


def get_metric_history(w: WorkspaceClient, run_id: str, metric_key: str) -> List[Dict[str, Any]]:
    """Fetch full history for a metric via GET /api/2.0/mlflow/metrics/get-history.

    Pages through `next_page_token` until exhausted and returns a flat list
    of `{"key", "value", "step", "timestamp"}` dicts. Order is backend-defined;
    callers that need sorted output should sort by step themselves.
    """
    out: List[Dict[str, Any]] = []
    page_token: Optional[str] = None
    while True:
        query: Dict[str, Any] = {"run_id": run_id, "metric_key": metric_key}
        if page_token:
            query["page_token"] = page_token
        response = w.api_client.do("GET", "/api/2.0/mlflow/metrics/get-history", query=query)
        out.extend(response.get("metrics") or [])
        page_token = response.get("next_page_token")
        if not page_token:
            return out


def list_artifacts(w: WorkspaceClient, run_id: str, path: Optional[str] = None) -> List[Dict[str, Any]]:
    """List artifacts under a prefix via GET /api/2.0/mlflow/artifacts/list.

    Pages through `next_page_token` and returns a flat list of
    `{"path": str, "is_dir": bool, "file_size": int}` entries.
    """
    out: List[Dict[str, Any]] = []
    page_token: Optional[str] = None
    while True:
        query: Dict[str, Any] = {"run_id": run_id}
        if path:
            query["path"] = path
        if page_token:
            query["page_token"] = page_token
        response = w.api_client.do("GET", "/api/2.0/mlflow/artifacts/list", query=query)
        out.extend(response.get("files") or [])
        page_token = response.get("next_page_token")
        if not page_token:
            return out


def download_artifact(w: WorkspaceClient, run_id: str, artifact_path: str, dst_path: str) -> Optional[str]:
    """Download a single run artifact to `dst_path/artifact_path`.

    Uses the credential-vending flow that the mlflow SDK uses internally for
    Databricks-backed runs:
      1. `credentials-for-read` returns a pre-signed URL (S3/Azure/GCP) or an
         equivalent token for the underlying storage backend.
      2. We stream the pre-signed URL directly into the destination file.

    This avoids the size ceiling that applies to the proxied
    `/api/2.0/mlflow/get-artifact` endpoint — log files can easily exceed it.

    Returns the absolute local file path on success, or None on any failure.
    """
    # Defense-in-depth: reject absolute or traversal paths so a malformed or
    # malicious artifact_path can't escape dst_path. MLflow-tracked artifacts
    # should never contain these, but the check is cheap.
    if os.path.isabs(artifact_path) or ".." in artifact_path.replace("\\", "/").split("/"):
        log.debug("Refusing artifact path with traversal or absolute path: %s", artifact_path)
        return None

    try:
        response = w.api_client.do(
            "GET",
            "/api/2.0/mlflow/artifacts/credentials-for-read",
            # `path` is a repeated string field in the proto — keep the list
            # wrapper so the SDK serializes `path=...&path=...`. Passing a
            # scalar would send one `path=` param that some intermediaries
            # handle inconsistently.
            query={"run_id": run_id, "path": [artifact_path]},
        )
        infos = response.get("credential_infos") or []
        if not infos:
            log.debug("No credential_infos returned for %s", artifact_path)
            return None
        info = infos[0]
        signed_uri = info.get("signed_uri")
        if not signed_uri:
            log.debug("No signed_uri in credential info for %s", artifact_path)
            return None
        # ArtifactCredentialInfo.headers carries backend-required request
        # headers — empty for AWS read-side pre-signed URLs, populated for
        # Azure SAS URIs (e.g. `x-ms-version`) and some GCS responses.
        signed_headers = {h["name"]: h["value"] for h in info.get("headers") or []}

        local_file_path = os.path.join(dst_path, artifact_path)
        parent = os.path.dirname(local_file_path) or "."
        os.makedirs(parent, exist_ok=True)
        # Stream to a tempfile in the same directory, then atomic-rename on
        # success. Prevents a partial file from being left behind if the
        # download fails mid-stream (network drop, disk full, interrupt).
        fd, tmp_path = tempfile.mkstemp(dir=parent, prefix=".sgcli-download-")
        try:
            # timeout=(connect, read) — per-chunk read timeout, not a total cap.
            with (
                os.fdopen(fd, "wb") as f,
                requests.get(signed_uri, stream=True, timeout=(10, 60), headers=signed_headers) as r,
            ):
                r.raise_for_status()
                for chunk in r.iter_content(chunk_size=_DOWNLOAD_CHUNK_BYTES):
                    f.write(chunk)
            os.replace(tmp_path, local_file_path)
        except BaseException:
            # Clean up the tempfile on any failure, including KeyboardInterrupt.
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
        return local_file_path
    except Exception as e:
        log.debug("Failed to download artifact from %s: %s", artifact_path, e)
        return None
