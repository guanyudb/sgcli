# sgcli Agent Skills

Operational playbook for agents using `sgcli` to submit, monitor, triage, and resubmit Serverless GPU jobs.

---

## Setup

### Finding and Exposing sgcli

`sgcli` is installed inside a venv. The system prompt should specify the path. If not:

```bash
find / -name sgcli -type f 2>/dev/null | head -5
```

If nothing is found, ask the user. **On first use, symlink it onto PATH so every subsequent call starts with bare `sgcli`** — this lets users grant blanket auto-approval (e.g. `Bash(sgcli*)`).

```bash
ln -sf /path/to/venv/bin/sgcli /usr/local/bin/sgcli
```

**Do NOT source/activate the venv before each call.** Always invoke `sgcli` directly if possible.

### Workspace and Authentication

**Always ask the user which workspace to use before submitting anything.**

```bash
cat ~/.databrickscfg   # list available profiles and their workspace URLs
```

Show the user the profiles, ask which to use, then pass `-p <profile>` to every command.

If `error.kind == "AUTH"`, ask the user to run `databricks auth login --host <workspace-url>`.

---

## Global Flags and JSON Output

Always use `--json` for programmatic calls. `--json`, `-p`, and `-v` can appear **anywhere** — before or after the subcommand.

**Envelopes:**
- **Success:** `{"v": 1, "ts": "...", "data": {...}}`
- **Error:** `{"v": 1, "ts": "...", "error": {"code": "...", "kind": "...", "message": "...", "retryable": bool}}`

**Error kinds:** `NOT_FOUND` (bad run ID), `AUTH` (re-authenticate), `USER` (fix YAML/input), `CONFLICT` (use new `--idempotency-key`), `TRANSIENT` (retryable).

---

## 1. YAML Config

Run `sgcli -h config` or `sgcli -h config.<field>` for all fields and constraints.

### Minimal example

```yaml
experiment_name: my-training
compute:
  gpus: 8
  gpu_type: h100        # a10, a100, h100, h200
command: python train.py
```

### Full-featured example

```yaml
experiment_name: my-training
environment:
  dependencies: requirements.yaml     # resolves relative to this YAML file's location
  env_variables:
    BATCH_SIZE: "32"
  env_variables_secrets:
    HF_TOKEN: my-scope/hf_token       # Databricks secret scope/key
code_source:
  type: snapshot
  snapshot:
    repo_path: /home/user/my-repo      # repo appears as $HOME/my_repo in remote Nodes.  
    allow_uncommitted: true            # incompatible with git_branch/git_commit
compute:
  gpus: 16                             # multi-node: total must be a multiple of GPUs per node
  gpu_type: h100
bash_script: train.sh
max_retries: 1
```

`requirements.yaml` format: `version: "4"` with a `dependencies:` list of pip specifiers.

---

## 2. Submit

```bash
sgcli --json run -p <profile> --file train.yaml --idempotency-key <key>
```

Key flags: `--override KEY=VALUE` (override YAML fields), `--dry-run` (validate only).

Returns `data.run_id` — save it for all subsequent calls.

---

## 3. Monitor (Preferred)

`monitor` blocks until completion, streaming JSONL events. **Use this instead of polling `get status`.**

```bash
sgcli --json monitor <run_id> -p <profile> --errors-only
```

Key flags: `--errors-only` (suppress raw LOG events, surface only ERROR and ALERT), `--node N` / `--local-rank N`.

**Event types:**
| Type | When emitted |
|---|---|
| `STATUS` | Every lifecycle state change |
| `LOG` | Each log line (suppressed by `--errors-only`) |
| `ERROR` | Log line matching error/fatal keywords |
| `ALERT` | Log line matching a FATAL pattern (OOM, NCCL timeout, segfault, etc.) — **always emitted, act immediately** |
| `TERMINAL` | Job ends — contains `status`, `duration_seconds`, `errors_detected[]` |

**Exit codes:** `0` = SUCCESS, `1` = FAILED / CANCELED / error.

On `ALERT`: cancel the job and relaunch. Do not wait for `TERMINAL`.

Each entry in `TERMINAL.errors_detected[]` has: `line` (raw traceback block or matched line), `severity` (`fatal`|`warning`), `line_number`.

---

## 4. One-Shot Status Check

```bash
sgcli --json get status -p <profile> <run_id>
```

Terminal states: `SUCCESS`, `FAILED`, `CANCELED`, `TERMINATED`.

---

## 5. Deep-Dive Logs

```bash
sgcli get logs <run_id> -p <profile> --lines 200              # last N lines, node 0
sgcli get logs <run_id> -p <profile> --review                  # all nodes, filtered for tracebacks
sgcli get logs <run_id> -p <profile> --download-only ./logs/   # full download
```

---

## 6. Cancel

```bash
sgcli --json cancel <run_id> -p <profile>
```

Returns immediately. Poll `get status` until `CANCELED` — `cancel_requested: true` only means the request was accepted.

---

## 7. List Runs

```bash
sgcli --json get runs -p <profile> --limit 20 --all --experiment "llama.*finetune"
```

---

## 8. Triage and Resubmit

Start from `TERMINAL.errors_detected` — read each `line` to understand the failure. Common patterns and fixes:

- **OOM** (`CUDA out of memory`, `Out of memory: Kill`): reduce batch size or add GPUs
- **NCCL / collective timeout** (`Watchdog caught`, `NCCL WARN`): retry; often transient
- **CUDA error** (`CUDA runtime error`, illegal memory access): check driver/image compatibility
- **Store timeout** (`TCPStore timed out`): retry
- **Import error** (`ModuleNotFoundError`): fix `environment.dependencies`
- **Python exception**: read `line` for the exception type and location

If `errors_detected` is empty but status is `FAILED`, run `sgcli get logs <run_id> -p <profile> --review`.

Resubmit with a **new** `--idempotency-key`:

```bash
sgcli --json run -p <profile> --file train.yaml --override timeout_minutes=180 --idempotency-key retry-2
```

---

## On-Cluster Environment Variables

For the full list of environment variables available on each node (distributed training, MLflow, hyperparameters, etc.), run:

```bash
sgcli -h config.command
```

---

## Agent Tips

1. **Use static idempotency keys** — dynamic subexpressions like `$(uuidgen)` prevent auto-approval when `Bash(sgcli*)` is in the allow list.

2. **Run `monitor` as a background task** — start it immediately after submit so ALERT events surface fast. React to ALERT without waiting for TERMINAL.

3. **Fast failures (duration ≈ 0, no errors)** — the job never started training. Skip training logs; go straight to `sgcli get logs <run-id>` for environment setup issues.

4. **`environment.dependencies` path** resolves relative to the YAML file, not the repo root.

5. **code_source location on remote compute** The last folder name in repo_path will be the name of the code source folder under $HOME. 
Example: If `repo_path` is `/path/to/repo` then the location of code source on remote compute will be `$HOME/repo`
Therefore to access user code like `/path/to/repo/train.py` one must `cd $HOME/repo; python train.py` or use absolute path `python $HOME/repo/train.py`
