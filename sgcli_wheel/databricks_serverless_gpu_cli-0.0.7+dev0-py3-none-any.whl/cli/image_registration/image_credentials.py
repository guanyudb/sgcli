"""Interactive Docker registry credential management for SGCLI.

This module handles the interactive flow when a user runs `sgcli register image`
without providing --scope/--key for a private image. It:
  1. Prompts for Docker registry username and PAT/password
  2. Prompts for a Databricks secret scope name and key name
  3. Base64-encodes the credentials as "username:password"
  4. Creates the scope (if needed) and stores the secret
  5. Returns the (scope, key) pair for use in image registration

The backend expects the secret value to be base64("username:password").
"""

import base64
import getpass
import logging
from typing import Optional, Tuple

from cli.utils import get_workspace_client, retry

log = logging.getLogger(__name__)

# Default scope/key names used when creating secrets automatically
DEFAULT_SCOPE_NAME = "sgcli-docker-credentials"
MAX_API_RETRIES = 3


def _is_retryable_api_error(e: BaseException) -> bool:
    """Only retry transient errors. Permission/auth errors will never succeed on retry."""
    msg = str(e).lower()
    non_retryable = (
        "permission denied",
        "access denied",
        "forbidden",
        "unauthorized",
        "not authorized",
        "does not exist",
        "invalid",
        "bad request",
    )
    return not any(kw in msg for kw in non_retryable)


def encode_docker_credentials(username: str, password: str) -> str:
    """Base64-encode Docker credentials in the format expected by the backend.

    The backend decodes this as base64("username:password").

    Args:
        username: Docker registry username.
        password: Docker registry password or PAT.

    Returns:
        Base64-encoded string of "username:password".
    """
    raw = f"{username}:{password}"
    return base64.b64encode(raw.encode("utf-8")).decode("utf-8")


def _prompt_docker_credentials() -> Tuple[str, str]:
    """Prompt the user for Docker registry username and PAT/password.

    Returns:
        Tuple of (username, password/PAT).

    Raises:
        SystemExit: If user provides empty credentials.
    """
    print()
    username = input("Docker registry username: ").strip()
    if not username:
        raise SystemExit("Docker registry username cannot be empty.")

    password = getpass.getpass("Docker registry password/PAT: ").strip()
    if not password:
        raise SystemExit("Docker registry password/PAT cannot be empty.")

    return username, password


def _prompt_scope_and_key(docker_username: str) -> Tuple[str, str]:
    """Prompt the user for Databricks secret scope and key names.

    Provides defaults so users can just press Enter for a quick setup.

    Returns:
        Tuple of (scope_name, key_name).
    """
    default_key = f"dockerio-{docker_username}"

    print()
    print("Your Docker credentials will be stored as a Databricks Secret.")
    print("Learn more: https://docs.databricks.com/aws/en/security/secrets/")
    print()

    scope = input(f"Databricks secret scope name [{DEFAULT_SCOPE_NAME}]: ").strip()
    if not scope:
        scope = DEFAULT_SCOPE_NAME

    key = input(f"Databricks secret key name [{default_key}]: ").strip()
    if not key:
        key = default_key

    return scope, key


@retry(Exception, tries=MAX_API_RETRIES, retry_if=_is_retryable_api_error)
def _ensure_scope_exists(workspace_host: Optional[str], scope: str) -> None:
    """Create a Databricks secret scope if it doesn't already exist."""
    w = get_workspace_client(workspace_host=workspace_host)
    try:
        existing_scopes = w.secrets.list_scopes()
        for s in existing_scopes:
            if s.name == scope:
                log.debug(f"Secret scope '{scope}' already exists. Skipping creation.")
                return
    except Exception as e:
        log.debug(f"Could not list scopes (user may lack LIST permission): {e}")

    try:
        w.secrets.create_scope(scope=scope)
        log.info(f"Created Databricks secret scope: '{scope}'")
    except Exception as e:
        if "already exists" in str(e).lower():
            log.debug(f"Secret scope '{scope}' already exists. Skipping creation.")
            return
        raise


@retry(Exception, tries=MAX_API_RETRIES, retry_if=_is_retryable_api_error)
def _store_secret(workspace_host: Optional[str], scope: str, key: str, value: str) -> None:
    """Store a secret value in a Databricks secret scope."""
    w = get_workspace_client(workspace_host=workspace_host)
    w.secrets.put_secret(scope=scope, key=key, string_value=value)
    log.info(f"Stored Docker credentials in secret: {scope}/{key}")


def setup_docker_credentials_interactive(
    workspace_host: Optional[str] = None,
) -> Tuple[str, str]:
    """Run the full interactive credential setup flow.

    Called by `sgcli register image` when --scope/--key are not provided and the
    image requires credentials (private registry, no existing registration).

    Flow:
      1. Prompt for Docker username + PAT
      2. Prompt for Databricks secret scope + key (with defaults)
      3. Base64-encode as "username:password"
      4. Create scope if needed, store secret
      5. Return (scope, key) for use in registration API

    Args:
        workspace_host: Optional workspace host URL for WorkspaceClient.

    Returns:
        Tuple of (scope, key) pointing to the newly created secret.

    Raises:
        SystemExit: If user provides invalid input.
        RuntimeError: If secret creation fails.
    """
    print("\nNo --scope/--key provided. Setting up Docker registry credentials.")
    print("A new Databricks secret will be created to store your Docker credentials.\n")

    # Get Docker credentials from user
    username, password = _prompt_docker_credentials()
    scope, key = _prompt_scope_and_key(docker_username=username)

    # Encode credentials as base64("username:password")
    encoded = encode_docker_credentials(username, password)

    # Store in Databricks secrets
    print(f"\nCreating Databricks secret: {scope}/{key}")
    _ensure_scope_exists(workspace_host, scope)
    _store_secret(workspace_host, scope, key, encoded)

    print("Credentials stored successfully.\n")
    print("To reuse these credentials in future commands, pass:")
    print(f"  --scope {scope} --key {key}\n")

    return scope, key
