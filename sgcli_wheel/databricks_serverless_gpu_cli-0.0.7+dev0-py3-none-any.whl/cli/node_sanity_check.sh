#!/bin/bash

# ==============================================================================
# NODE SANITY CHECKER FOR DISTRIBUTED TRAINING
# ==============================================================================
# Usage: ./node_sanity_check.sh [MASTER_ADDR] [MASTER_PORT]
# Example: ./node_sanity_check.sh node-01 29500
#
# Exit codes:
#   0 = All critical checks passed
#   1 = Critical failure (training will not work)
# ==============================================================================

set -o pipefail

MASTER_ADDR=${1:-${MASTER_ADDR:-"localhost"}}
MASTER_PORT=${2:-${MASTER_PORT:-"29500"}}

# Track failures
CRITICAL_FAIL=0
WARNINGS=0

# ------------------------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------------------------
pass()  { echo "    [PASS] $1"; }
fail()  { echo "    [FAIL] $1"; CRITICAL_FAIL=1; }
warn()  { echo "    [WARN] $1"; ((WARNINGS++)); }
info()  { echo "    [INFO] $1"; }

# ==============================================================================
echo "========================================================"
echo "NODE SANITY CHECK FOR DISTRIBUTED TRAINING"
echo "========================================================"
echo "Hostname: $(hostname)"
echo "Time:     $(date)"
echo "Master:   $MASTER_ADDR:$MASTER_PORT"
echo "========================================================"

# ------------------------------------------------------------------------------
# 1. SYSTEM INFORMATION
# ------------------------------------------------------------------------------
echo -e "\n[1] SYSTEM INFORMATION"
info "Kernel: $(uname -r)"
info "OS: $(cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d'"' -f2 || echo 'Unknown')"
info "CPU: $(lscpu 2>/dev/null | grep 'Model name' | cut -d':' -f2 | xargs || echo 'Unknown')"
info "CPU Cores: $(nproc)"
info "Memory Total: $(free -h | awk '/^Mem:/{print $2}')"
info "Memory Available: $(free -h | awk '/^Mem:/{print $7}')"

# ------------------------------------------------------------------------------
# 2. GPU HARDWARE & DRIVERS
# ------------------------------------------------------------------------------
echo -e "\n[2] GPU HARDWARE & DRIVERS"

if command -v nvidia-smi &> /dev/null; then
    DRIVER_VER=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -n 1)
    GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader | head -n 1)
    GPU_COUNT=$(nvidia-smi --query-gpu=name --format=csv,noheader | wc -l)
    CUDA_VER=$(nvidia-smi | grep 'CUDA Version' | awk '{print $9}')
    
    pass "NVIDIA Driver: $DRIVER_VER"
    info "CUDA Version (driver): $CUDA_VER"
    info "GPU Model: $GPU_NAME"
    info "GPU Count: $GPU_COUNT"
    
    # GPU memory info
    echo "    [INFO] GPU Memory:"
    nvidia-smi --query-gpu=index,memory.total,memory.free --format=csv,noheader | while read line; do
        echo "           $line"
    done

    # NVLink status (critical for multi-GPU)
    if [[ $GPU_COUNT -gt 1 ]]; then
        NVLINK_STATUS=$(nvidia-smi nvlink --status 2>&1)
        if [[ $NVLINK_STATUS == *"active"* ]] || [[ $NVLINK_STATUS == *"Active"* ]]; then
            pass "NVLink is active"
        elif [[ $NVLINK_STATUS == *"error"* ]] || [[ $NVLINK_STATUS == *"not supported"* ]]; then
            info "NVLink not available (PCIe topology)"
        else
            warn "NVLink status unclear"
        fi
    fi
else
    fail "nvidia-smi not found! NVIDIA driver not installed?"
fi

# Check nvcc
if command -v nvcc &> /dev/null; then
    info "NVCC Version: $(nvcc --version | grep release | awk '{print $6}' | cut -d',' -f1)"
else
    warn "nvcc not found in PATH (okay if using container)"
fi

# ------------------------------------------------------------------------------
# 3. INFINIBAND / HIGH-SPEED INTERCONNECTS
# ------------------------------------------------------------------------------
echo -e "\n[3] HIGH-SPEED INTERCONNECTS"

IB_FOUND=0
if command -v ibstat &> /dev/null; then
    IB_STATE=$(ibstat 2>/dev/null | grep "State:" | head -n 1 | awk '{print $2}')
    if [[ "$IB_STATE" == "Active" ]]; then
        pass "InfiniBand link is Active"
        IB_FOUND=1
        # Show rate
        IB_RATE=$(ibstat 2>/dev/null | grep "Rate:" | head -n 1 | awk '{print $2}')
        info "InfiniBand Rate: ${IB_RATE:-unknown} Gb/s"
    elif [[ -n "$IB_STATE" ]]; then
        warn "InfiniBand link state: $IB_STATE (not Active)"
        IB_FOUND=1
    fi
elif command -v ibv_devinfo &> /dev/null; then
    if ibv_devinfo 2>/dev/null | grep -q "state:.*PORT_ACTIVE"; then
        pass "InfiniBand port is active (via ibv_devinfo)"
        IB_FOUND=1
    fi
fi

if [[ $IB_FOUND -eq 0 ]]; then
    if lspci 2>/dev/null | grep -qi "Mellanox"; then
        warn "Mellanox device found but ibstat/ibv_devinfo missing or link down"
    else
        info "No InfiniBand detected (using Ethernet)"
    fi
fi

# EFA check (AWS)
if lspci 2>/dev/null | grep -qi "Amazon.*Elastic Fabric"; then
    pass "AWS EFA device detected"
fi

# ------------------------------------------------------------------------------
# 4. NETWORK CONNECTIVITY
# ------------------------------------------------------------------------------
echo -e "\n[4] NETWORK CONNECTIVITY"

info "Local interfaces:"
ip -4 addr show 2>/dev/null | grep -E 'inet ' | awk '{print "           " $NF ": " $2}' || \
    ifconfig 2>/dev/null | grep -E 'inet ' | awk '{print "           " $1 ": " $2}'

# Test master connectivity
echo "    [TEST] Resolving $MASTER_ADDR..."
if ping -c 1 -W 2 "$MASTER_ADDR" &> /dev/null; then
    pass "Can ping $MASTER_ADDR"
else
    if [[ "$MASTER_ADDR" == "localhost" || "$MASTER_ADDR" == "127.0.0.1" ]]; then
        pass "Using localhost (single-node mode)"
    else
        fail "Cannot ping $MASTER_ADDR - check DNS or /etc/hosts"
    fi
fi

# Port reachability (skip for localhost or if we are the master)
if [[ "$MASTER_ADDR" != "localhost" && "$MASTER_ADDR" != "127.0.0.1" && "$MASTER_ADDR" != "$(hostname)" && "$MASTER_ADDR" != "$(hostname -f 2>/dev/null)" ]]; then
    echo "    [TEST] Checking port $MASTER_PORT on $MASTER_ADDR..."
    if command -v nc &> /dev/null; then
        if nc -z -w 5 "$MASTER_ADDR" "$MASTER_PORT" 2>/dev/null; then
            pass "Port $MASTER_PORT is reachable on $MASTER_ADDR"
        else
            warn "Port $MASTER_PORT not reachable (normal if training hasn't started)"
        fi
    elif command -v timeout &> /dev/null; then
        if timeout 5 bash -c "echo > /dev/tcp/$MASTER_ADDR/$MASTER_PORT" 2>/dev/null; then
            pass "Port $MASTER_PORT is reachable on $MASTER_ADDR"
        else
            warn "Port $MASTER_PORT not reachable (normal if training hasn't started)"
        fi
    else
        info "nc/netcat not found, skipping port check"
    fi
fi

# ------------------------------------------------------------------------------
# 5. PYTORCH & CUDA STACK
# ------------------------------------------------------------------------------
echo -e "\n[5] PYTORCH & CUDA STACK"

python3 - << 'PYTHON_CHECK'
import sys

def pass_check(msg): print(f"    [PASS] {msg}")
def fail_check(msg): print(f"    [FAIL] {msg}"); sys.exit(1)
def warn_check(msg): print(f"    [WARN] {msg}")
def info_check(msg): print(f"    [INFO] {msg}")

try:
    import torch
    info_check(f"PyTorch Version: {torch.__version__}")
except ImportError:
    fail_check("PyTorch not installed!")

try:
    # CUDA availability
    if not torch.cuda.is_available():
        fail_check("torch.cuda.is_available() = False")
    
    gpu_count = torch.cuda.device_count()
    pass_check(f"PyTorch sees {gpu_count} GPU(s)")
    
    # Per-GPU info
    for i in range(gpu_count):
        name = torch.cuda.get_device_name(i)
        cap = torch.cuda.get_device_capability(i)
        info_check(f"GPU {i}: {name} (sm_{cap[0]}{cap[1]})")
    
    # Compute capability check
    cap = torch.cuda.get_device_capability(0)
    if cap[0] >= 9:
        pass_check(f"Compute Capability {cap} (H100/Hopper class)")
    elif cap[0] >= 8:
        pass_check(f"Compute Capability {cap} (A100/Ampere class)")
    elif cap[0] >= 7:
        warn_check(f"Compute Capability {cap} (V100/Volta - older)")
    else:
        warn_check(f"Compute Capability {cap} (old GPU, may lack features)")
    
    # BF16 support - critical for modern training
    if torch.cuda.is_bf16_supported():
        pass_check("BF16 is supported")
    else:
        fail_check("BF16 NOT supported! Check PyTorch/CUDA version or disable bf16")
    
    # CUDA version from PyTorch
    info_check(f"PyTorch CUDA Version: {torch.version.cuda}")
    
    # cuDNN
    if torch.backends.cudnn.is_available():
        pass_check(f"cuDNN Version: {torch.backends.cudnn.version()}")
        info_check(f"cuDNN Enabled: {torch.backends.cudnn.enabled}")
    else:
        warn_check("cuDNN not available")
    
    # NCCL - required for distributed
    if torch.distributed.is_nccl_available():
        pass_check("NCCL backend available")
        try:
            nccl_ver = torch.cuda.nccl.version()
            info_check(f"NCCL Version: {nccl_ver}")
        except:
            pass
    else:
        fail_check("NCCL NOT available - distributed training will fail!")
    
    # Other backends
    info_check(f"Gloo available: {torch.distributed.is_gloo_available()}")
    
    # P2P GPU access test
    if gpu_count > 1:
        print("    [TEST] GPU P2P Access:")
        all_p2p = True
        for i in range(gpu_count):
            for j in range(gpu_count):
                if i != j:
                    can_access = torch.cuda.can_device_access_peer(i, j)
                    if not can_access:
                        all_p2p = False
                        print(f"           GPU {i} -> GPU {j}: NO P2P")
        if all_p2p:
            pass_check("All GPUs have P2P access")
        else:
            warn_check("Some GPU pairs lack P2P access (may be slower)")

except Exception as e:
    fail_check(f"PyTorch check crashed: {e}")
PYTHON_CHECK

PYTHON_EXIT=$?
if [[ $PYTHON_EXIT -ne 0 ]]; then
    CRITICAL_FAIL=1
fi

# ------------------------------------------------------------------------------
# 6. ENVIRONMENT VARIABLES
# ------------------------------------------------------------------------------
echo -e "\n[6] ENVIRONMENT VARIABLES"

# Distributed training vars
echo "    Distributed:"
echo "        MASTER_ADDR:        ${MASTER_ADDR}"
echo "        MASTER_PORT:        ${MASTER_PORT}"
echo "        WORLD_SIZE:         ${WORLD_SIZE:-[not set]}"
echo "        RANK:               ${RANK:-[not set]}"
echo "        LOCAL_RANK:         ${LOCAL_RANK:-[not set]}"

# CUDA vars
echo "    CUDA:"
echo "        CUDA_HOME:          ${CUDA_HOME:-[not set]}"
echo "        CUDA_VISIBLE_DEVICES: ${CUDA_VISIBLE_DEVICES:-[not set]}"

# NCCL vars
echo "    NCCL:"
echo "        NCCL_DEBUG:         ${NCCL_DEBUG:-[not set]}"
echo "        NCCL_SOCKET_IFNAME: ${NCCL_SOCKET_IFNAME:-[not set]}"
echo "        NCCL_IB_DISABLE:    ${NCCL_IB_DISABLE:-[not set]}"

# Perf vars
echo "    Performance:"
echo "        OMP_NUM_THREADS:    ${OMP_NUM_THREADS:-[not set]}"
echo "        LD_LIBRARY_PATH:    ${LD_LIBRARY_PATH:-[not set]}"

# ------------------------------------------------------------------------------
# 7. FILESYSTEM & STORAGE
# ------------------------------------------------------------------------------
echo -e "\n[8] FILESYSTEM"

info "Disk usage:"
df -h 2>/dev/null | grep -E '^/dev/' | awk '{print "           " $6 ": " $4 " free (" $5 " used)"}' | head -5

# Shared filesystem check
SHARED_FS=$(mount 2>/dev/null | grep -E 'nfs|lustre|gpfs|beegfs|cifs' | head -1)
if [[ -n "$SHARED_FS" ]]; then
    info "Shared filesystem detected"
else
    info "No shared filesystem detected"
fi

# ==============================================================================
# SUMMARY
# ==============================================================================
echo ""
echo "========================================================"
echo "SUMMARY"
echo "========================================================"

if [[ $CRITICAL_FAIL -eq 0 ]]; then
    echo "[✓] All critical checks PASSED"
    if [[ $WARNINGS -gt 0 ]]; then
        echo "[!] $WARNINGS warning(s) - review above"
    fi
    echo "========================================================"
    exit 0
else
    echo "[✗] CRITICAL FAILURES detected - training will NOT work"
    echo "    Review [FAIL] messages above"
    echo "========================================================"
    exit 1
fi
