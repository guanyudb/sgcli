"""Base client interface and types for workload management.
This module defines the abstract interface that all workload clients must implement,
ensuring consistent behavior across different backend APIs (Jobs API, CMv3, etc.).
It also defines the client type enumeration.
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, Any, Optional
from cli.compute import GPUType


class WorkloadClientType(Enum):
    """Enum for different workload client types."""

    JOBS_API = "Jobs API"
    AI_COMPUTE_MANAGER = "AI Compute Manager (CMv3)"

    def __str__(self) -> str:
        """Return the string representation of the client type."""
        return self.value


class WorkloadClient(ABC):
    """Abstract base class for workload management clients.
    This interface ensures that all workload clients (Jobs API, CMv3, etc.)
    provide the same core functionality with consistent method signatures.
    """

    @abstractmethod
    def create_workload(
        self,
        gpus: int,
        gpus_per_node: int,
        python_file: str,
        func_dir: str,
        experiment_name: str,
        timeout_seconds: int,
        param_to_args: dict,
        env_sync_timeout: int,
        gpu_type: GPUType,
        max_retries: int = 0,
    ) -> str:
        """Create a workload and return workload/run ID.
        Args:
            gpus: Number of GPUs required
            gpus_per_node: GPUs per node (for distributed workloads)
            python_file: Path to the Python script to execute
            func_dir: Directory containing the function
            experiment_name: Name of the function to execute
            timeout_seconds: Timeout for the workload
            param_to_args: Parameters to pass to the function
            env_sync_timeout: Environment synchronization timeout
            gpu_type: Type of GPU required
            max_retries: Maximum number of retries for failed tasks (default: 0)
        Returns:
            Workload/run ID as string
        Raises:
            Exception: If workload creation fails
        """
        pass

    @abstractmethod
    def get_workload_status(self, workload_id: str) -> Dict[str, Any]:
        """Get workload status and metadata.
        Args:
            workload_id: Unique workload identifier
        Returns:
            Dictionary containing workload status and metadata
        """
        pass

    @abstractmethod
    def terminate_workload(self, workload_id: str, reason: Optional[str] = None) -> bool:
        """Terminate a running workload.
        Args:
            workload_id: Unique workload identifier
            reason: Optional reason for termination
        Returns:
            True if termination was successful, False otherwise
        """
        pass

    @abstractmethod
    def list_workloads(self, **kwargs) -> Dict[str, Any]:
        """List workloads.
        Args:
            **kwargs: Client-specific parameters for listing (pagination, filters, etc.)
        Returns:
            Dictionary containing workloads and pagination info
        """
        pass

    @property
    @abstractmethod
    def client_type(self) -> WorkloadClientType:
        """Get the client type for logging and debugging.
        Returns:
            WorkloadClientType enum identifying the client type
        """
        pass
