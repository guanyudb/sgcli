"""Databricks Serverless GPU CLI package."""

# NOTE: version and git sha are determined at release time; the versions listed here are placeholders
__version__ = "0.0.7+dev0"
__git_sha__ = "e73b274496b09cd51993ee031e808a694a65af91"
