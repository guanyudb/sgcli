"""YAML configuration schema and validation using Pydantic.

This module defines the complete schema for training YAML configuration files,
including validation rules for all fields and nested structures.
"""

from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict
import re
from typing import Optional, Dict, Any, Literal, List
from enum import Enum

from cli.compute import GPUType, get_gpus_per_node
from databricks.sdk.service.iam import PermissionLevel

# Only allows alphanumeric characters, hyphens, dots, and underscores
REGEX_ALLOWED_CHARS = r"^[\w.-]+$"
# Regex for experiment_name/task_key: alphanumeric, hyphen, underscore only (no periods)
# This matches Databricks Jobs API requirements for task keys
REGEX_TASK_KEY_CHARS = r"^[\w-]+$"
# Regex for UUID v4: 8-4-4-4-12 lowercase hex characters separated by hyphens
REGEX_UUID = r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"


class PermissionGrantType(str, Enum):
    """Types of principals that can be granted permissions."""

    USER = "user"
    GROUP = "group"
    SERVICE_PRINCIPAL = "service_principal"


class PermissionGrant(BaseModel):
    """Configuration for granting permissions on a job."""

    model_config = ConfigDict(extra="forbid")

    type: PermissionGrantType = Field(description="Type of principal (user, group, or service_principal)")
    name: str = Field(description="Name of the user, group, or service principal")
    permission_level: PermissionLevel = Field(description="Permission level to grant")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate name is not empty."""
        if not v or not v.strip():
            raise ValueError("Permission grant name cannot be empty")
        return v.strip()


class WorkspaceConfig(BaseModel):
    """Workspace configuration for specifying Databricks workspace."""

    model_config = ConfigDict(extra="forbid")

    host: Optional[str] = None

    @field_validator("host")
    @classmethod
    def validate_host(cls, v: Optional[str]) -> Optional[str]:
        """Validate workspace host is not empty if provided."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("workspace.host cannot be empty")
        return v


class DockerImageConfig(BaseModel):
    """Docker image configuration for custom containers."""

    model_config = ConfigDict(extra="forbid")

    url: str = Field(description="Container image URL (e.g., 'org/repo:tag' or 'registry.gitlab.com/org/repo:tag')")

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Validate docker image URL is not empty."""
        v = v.strip()
        if not v:
            raise ValueError("docker_image.url cannot be empty")
        return v


class EnvironmentConfig(BaseModel):
    """Environment configuration for dependencies and variables."""

    model_config = ConfigDict(extra="forbid")

    dependencies: Optional[str] = None
    env_variables: Optional[Dict[str, str]] = None
    env_variables_secrets: Optional[Dict[str, str]] = None
    docker_image: Optional[DockerImageConfig] = None

    @field_validator("env_variables_secrets")
    @classmethod
    def validate_secrets(cls, v: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
        """Validate secret references are in 'scope/key' format."""
        if v is not None:
            for var_name, secret_ref in v.items():
                if "/" not in secret_ref or len(secret_ref.split("/")) != 2:
                    raise ValueError(
                        f"Invalid secret reference '{secret_ref}' for variable '{var_name}'. "
                        f"Expected format 'scope/key' (e.g., my_scope/hf_token)"
                    )
                parts = secret_ref.split("/")
                if not parts[0] or not parts[1]:
                    raise ValueError(
                        f"Invalid secret reference '{secret_ref}' for variable '{var_name}'. "
                        f"Scope and key cannot be empty"
                    )
        return v

    @model_validator(mode="after")
    def handle_docker_image(self) -> "EnvironmentConfig":
        """Validate that docker_image cannot coexist with other environment fields."""
        # Check docker_image conflicts with other fields
        if self.docker_image is not None:
            conflicting_fields = []
            if self.dependencies is not None:
                conflicting_fields.append("dependencies")
            if self.env_variables is not None:
                conflicting_fields.append("env_variables")
            if self.env_variables_secrets is not None:
                conflicting_fields.append("env_variables_secrets")

            if conflicting_fields:
                fields_str = ", ".join(conflicting_fields)
                raise ValueError(
                    f"When 'docker_image' is specified under 'environment', "
                    f"the following fields are not allowed: {fields_str}. "
                    f"Please remove these fields or remove 'docker_image'."
                )
        return self


class ComputeConfig(BaseModel):
    """Compute configuration for GPU resources."""

    model_config = ConfigDict(extra="forbid")

    gpus: int = Field(gt=0, description="Number of GPUs (must be positive)")
    gpu_type: str = Field(description="Type of GPU (e.g., 'h100_80gb', 'a10')")
    gpu_node_pool_id: Optional[str] = None
    gpu_pool_name: Optional[str] = None

    @field_validator("gpu_type")
    @classmethod
    def validate_gpu_type(cls, v: str) -> str:
        """Validate GPU type is recognized."""
        try:
            GPUType(v)
        except (ValueError, KeyError):
            valid_types = ", ".join([f"'{t.value}'" for t in GPUType])
            raise ValueError(f"Invalid gpu_type '{v}'. Must be one of: {valid_types}")
        return v

    @model_validator(mode="after")
    def validate_gpu_count(self) -> "ComputeConfig":
        """Validate GPU count matches hardware topology (multiples of GPUs per node)."""
        gpu_type_enum = GPUType(self.gpu_type)
        gpus_per_node = get_gpus_per_node(gpu_type_enum)

        if self.gpus % gpus_per_node != 0:
            raise ValueError(
                f"Invalid GPU count for {self.gpu_type}: {self.gpus}. "
                f"{self.gpu_type} requires multiples of {gpus_per_node} GPUs. "
            )
        return self

    @model_validator(mode="after")
    def validate_pool_fields(self) -> "ComputeConfig":
        """Validate that only one of gpu_node_pool_id or gpu_pool_name is specified."""
        if self.gpu_node_pool_id and self.gpu_pool_name:
            raise ValueError("Cannot specify both 'gpu_node_pool_id' and 'gpu_pool_name'. " "Please use only one.")
        return self


class SnapshotSourceConfig(BaseModel):
    """Snapshot workflow: tar local directory and upload."""

    model_config = ConfigDict(extra="forbid")

    repo_path: str = Field(description="Local directory to snapshot")
    remote_volume: Optional[str] = None
    git_commit: Optional[str] = None
    git_branch: Optional[str] = None
    include_paths: Optional[List[str]] = Field(
        default=None,
        description="List of relative paths to include in snapshot (uses git archive mode)",
    )
    allow_uncommitted: bool = False
    remote_alias: Optional[str] = None
    use_remote_head: bool = False

    @field_validator("repo_path")
    @classmethod
    def validate_path(cls, v: str) -> str:
        """Validate repo_path is not empty."""
        if not v or not v.strip():
            raise ValueError("repo_path cannot be empty")
        return v.strip()

    @field_validator("remote_volume")
    @classmethod
    def validate_volume(cls, v: Optional[str]) -> Optional[str]:
        """Validate volume path starts with /Volumes/."""
        if v is not None and not v.startswith("/Volumes/"):
            raise ValueError("remote_volume must start with '/Volumes/'")
        return v

    @field_validator("git_branch")
    @classmethod
    def validate_branch(cls, v: Optional[str]) -> Optional[str]:
        """Validate git branch name to prevent command injection.

        Only allows alphanumeric characters, hyphens, dots, slashes, and underscores.
        """
        if v is None:
            return v

        error_message = f"Invalid git_branch format '{v}'. \n"
        error_message += "Only alphanumeric characters, hyphens, dots, slashes, and underscores are allowed. "

        if not re.match(r"^[\w./-]+$", v):
            raise ValueError(error_message)
        return v

    @field_validator("include_paths")
    @classmethod
    def validate_include_paths(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        """Validate include_paths are relative, non-empty, no traversal."""
        if v is not None:
            if len(v) == 0:
                raise ValueError("include_paths cannot be empty list. Either omit or provide paths.")

            for path in v:
                # Must be non-empty
                if not path or not path.strip():
                    raise ValueError("include_paths entry cannot be empty")

                path = path.strip()

                # No absolute paths
                if path.startswith("/"):
                    raise ValueError(f"include_paths must be relative paths, got: {path}")

                # No parent traversal
                if ".." in path.split("/"):
                    raise ValueError(f"include_paths cannot contain '..' traversal, got: {path}")

            return [p.strip() for p in v]
        return v

    @model_validator(mode="after")
    def validate_branch_commit_exclusive(self) -> "SnapshotSourceConfig":
        """Validate that git_branch and git_commit are mutually exclusive."""
        if self.git_branch is not None and self.git_commit is not None:
            raise ValueError(
                "git_branch and git_commit are mutually exclusive fields in the configuration yaml of code_source. Specify only one of them."
            )
        return self

    @model_validator(mode="after")
    def validate_use_remote_head(self) -> "SnapshotSourceConfig":
        """Validate use_remote_head requirements."""
        if self.use_remote_head:
            if self.git_commit is not None:
                raise ValueError("use_remote_head cannot be used with git_commit")
            if self.git_branch is None:
                raise ValueError("use_remote_head requires git_branch to be specified")
        return self

    @model_validator(mode="after")
    def validate_uncomitted_and_others_exclusive(self) -> "SnapshotSourceConfig":
        """Validate allow_uncommitted, use_remote_head, and git_commit are mutually exclusive."""
        if self.allow_uncommitted and (
            self.use_remote_head or self.git_commit is not None or self.git_branch is not None
        ):
            raise ValueError(
                "allow_uncommitted cannot be used with use_remote_head, git_commit, or git_branch. It can only be used with repo_path alone."
            )
        return self


class CodeSourceConfig(BaseModel):
    """Discriminated union for code source configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["snapshot"] = Field(description="Code source type")
    snapshot: Optional[SnapshotSourceConfig] = None

    @model_validator(mode="after")
    def validate_type_matches_config(self) -> "CodeSourceConfig":
        """Enforce type matches which config is provided."""
        if self.type == "snapshot":
            if self.snapshot is None:
                raise ValueError("type='snapshot' requires snapshot configuration")
        return self


class YamlConfig(BaseModel):
    """Complete YAML configuration schema for training runs."""

    model_config = ConfigDict(extra="forbid")

    # Required fields
    experiment_name: str
    environment: EnvironmentConfig
    compute: ComputeConfig

    # Script fields
    bash_script: Optional[str] = None
    command: Optional[str] = None

    # Optional fields
    workspace: Optional[WorkspaceConfig] = None
    code_source: Optional[CodeSourceConfig] = None
    max_retries: int = Field(default=0, ge=0)
    timeout_minutes: Optional[int] = Field(default=None, ge=1)
    idempotency_token: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = Field(default=None)
    run_name: Optional[str] = None
    no_interpolation: Optional[bool] = None
    experiment_directory: Optional[str] = None
    grant_permissions: Optional[List[PermissionGrant]] = None
    budget_policy_id: Optional[str] = Field(default=None, description="Budget policy UUID to assign to this workload")

    @field_validator("experiment_name")
    @classmethod
    def validate_experiment_name(cls, v: str) -> str:
        """Validate experiment_name contains only characters allowed in Databricks task keys.

        The experiment_name is used to generate the task key in the Databricks Jobs API,
        which only allows alphanumeric characters, hyphens, and underscores.
        Periods and other special characters are not permitted.
        """
        if not v:
            raise ValueError("experiment_name cannot be empty")

        error_message = f"Invalid experiment_name '{v}'.\n"
        error_message += "Only alphanumeric characters, hyphens (-), and underscores (_) are allowed.\n"
        error_message += "The experiment_name is used to generate task keys in Databricks Jobs API.\n"
        error_message += "Example valid names: 'my-training-job', 'gpt2_finetuning', 'experiment_001'"

        return cls._validate_pattern(v, REGEX_TASK_KEY_CHARS, error_message)

    @field_validator("idempotency_token")
    @classmethod
    def validate_idempotency_token(cls, v: Optional[str]) -> Optional[str]:
        """Validate idempotency token is not empty and within length limits."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("idempotency_token cannot be empty")
            if len(v) > 64:
                raise ValueError("idempotency_token must be 64 characters or less")
        return v

    @field_validator("run_name")
    @classmethod
    def validate_mlflow_run_name(cls, v: Optional[str]) -> Optional[str]:
        """Validate MLflow run name contains only characters allowed in Databricks task keys.

        The run_name is used to generate the task key in the Databricks Jobs API,
        which only allows alphanumeric characters, hyphens, and underscores.
        Periods and other special characters are not permitted.
        """
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("run_name cannot be empty")

            error_message = f"Invalid run_name '{v}'.\n"
            error_message += "Only alphanumeric characters, hyphens (-), and underscores (_) are allowed.\n"
            error_message += "The run_name is used to generate task keys in Databricks Jobs API.\n"
            error_message += "Example valid names: 'experiment-001-baseline', 'run_final', 'test_run_v2'"

            cls._validate_pattern(v, REGEX_TASK_KEY_CHARS, error_message)
        return v

    @field_validator("experiment_directory")
    @classmethod
    def validate_experiment_directory(cls, v: Optional[str]) -> Optional[str]:
        """Validate experiment directory starts with /Workspace.

        The experiment_directory specifies where MLflow experiments are stored.
        It must be a valid workspace path starting with /Workspace.
        """
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("experiment_directory cannot be empty")
            if not v.startswith("/Workspace"):
                raise ValueError(
                    f"experiment_directory must start with '/Workspace', got: {v}\n"
                    f"Example: '/Workspace/shared/experiments' or '/Workspace/users/alice@example.com/my-experiments'"
                )
        return v

    @classmethod
    def _validate_pattern(cls, v: Optional[str], pattern: str, error_message: str) -> Optional[str]:
        """Validate string with a regex pattern.

        Only allows alphanumeric characters, hyphens, dots, slashes, and underscores.
        """
        if v is not None:
            if not re.match(pattern, v):
                raise ValueError(error_message)
        return v

    @field_validator("bash_script")
    @classmethod
    def validate_bash_script(cls, v: Optional[str]) -> Optional[str]:
        """Validate bash script filename to prevent command injection.

        Only allows alphanumeric characters, hyphens, dots, and underscores in the filename.
        This prevents shell command injection when the script name is used in bash commands.
        """
        if v is not None:
            file_name = v.split("/")[-1]
            cls._validate_pattern(
                file_name,
                REGEX_ALLOWED_CHARS,
                f"Invalid bash_script filename '{file_name}'. "
                f"Only alphanumeric characters, hyphens, dots, and underscores are allowed in the filename.",
            )
            return v  # Return the original path, not just the filename

    @field_validator("command")
    @classmethod
    def validate_command(cls, v: Optional[str]) -> Optional[str]:
        """Validate command is not empty and not too long."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("command cannot be empty")

            # Check line count
            line_count = len(v.splitlines())
            if line_count > 100:
                raise ValueError(
                    f"command is too long ({line_count} lines). "
                    f"Commands longer than 100 lines should use 'bash_script' instead. "
                    f"Create a separate .sh file and reference it with 'bash_script: path/to/script.sh'"
                )
        return v

    @field_validator("budget_policy_id")
    @classmethod
    def validate_budget_policy_id(cls, v: Optional[str]) -> Optional[str]:
        """Validate budget_policy_id is a valid lowercase UUID."""
        if v is not None:
            v = v.strip()
            if not re.match(REGEX_UUID, v):
                raise ValueError(
                    f"Invalid budget_policy_id '{v}'. "
                    f"Must be a lowercase UUID in the format 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' "
                    f"(e.g., 'a1b2c3d4-e5f6-7890-abcd-ef1234567890')"
                )
        return v

    @model_validator(mode="after")
    def validate_script_fields(self) -> "YamlConfig":
        """Ensure exactly one script field is provided."""
        fields_provided = [
            self.bash_script is not None,
            self.command is not None,
        ]

        if sum(fields_provided) > 1:
            raise ValueError(
                "Cannot specify multiple script fields. " "Choose exactly one: 'bash_script', or 'command'"
            )

        if sum(fields_provided) == 0:
            raise ValueError("Must specify exactly one script field: " "'bash_script', or 'command'")

        return self
