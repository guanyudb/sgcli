"""JSON envelope helpers for agent-compatible (machine-readable) output mode.

When --json is passed, all stdout is structured JSON. Human-readable Rich output
goes to stderr so stdout stays clean for programmatic consumption.
"""

import json
from datetime import datetime, timezone
from typing import Any, Dict


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def print_json_success(data: Dict[str, Any]) -> None:
    """Emit a success envelope to stdout."""
    envelope: Dict[str, Any] = {"v": 1, "ts": _now_iso(), "data": data}
    print(json.dumps(envelope), flush=True)


def print_json_error(
    code: str,
    kind: str,
    message: str,
    retryable: bool,
) -> None:
    """Emit an error envelope to stdout."""
    envelope: Dict[str, Any] = {
        "v": 1,
        "ts": _now_iso(),
        "error": {"code": code, "kind": kind, "message": message, "retryable": retryable},
    }
    print(json.dumps(envelope), flush=True)


def print_jsonl_event(event_type: str, **fields: Any) -> None:
    """Emit a JSONL event line to stdout (used for streaming log output)."""
    event: Dict[str, Any] = {"type": event_type, "ts": _now_iso(), **fields}
    print(json.dumps(event), flush=True)
