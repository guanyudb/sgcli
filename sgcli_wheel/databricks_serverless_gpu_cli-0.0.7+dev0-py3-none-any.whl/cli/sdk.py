"""Simple Python SDK for sgcli operations.

Provides clean Python functions for job submission, status, logs, and cancellation
without needing to shell out to subprocess. Designed for use in integration tests.

Usage:
    from cli.sdk import do_run, get_status, get_logs, do_cancel

    # Submit job
    result = do_run("path/to/config.yaml")
    run_id = result["run_id"]

    # Check status
    status = get_status(run_id)

    # Get logs
    logs = get_logs(run_id, node=0, local_rank=0)

    # Cancel job
    do_cancel(run_id)
"""

import argparse
import os
from pathlib import Path
from typing import Dict, List, Optional

from cli import cli_entrypoint
from cli.jobs_api_client import JobsApiClient


def _setup_auth(workspace_host: Optional[str] = None, profile: Optional[str] = None):
    """Setup authentication environment variables.

    Args:
        workspace_host: Optional workspace URL to configure
        profile: Optional Databricks profile name
    """
    if workspace_host:
        os.environ["DATABRICKS_HOST"] = workspace_host

    if profile:
        os.environ["DATABRICKS_CONFIG_PROFILE"] = profile


def do_run(
    yaml_path: str,
    overrides: Optional[List[str]] = None,
    workspace_host: Optional[str] = None,
    profile: Optional[str] = None,
    watch: bool = False,
    verbose: int = 0,
) -> Dict[str, str]:
    """Submit a training job from YAML config.

    Args:
        yaml_path: Path to YAML configuration file
        overrides: Optional list of config overrides in KEY=VALUE format
        workspace_host: Optional workspace URL
        profile: Optional Databricks profile name
        watch: If True, stream logs until completion
        verbose: Verbosity level (0=normal, 1=verbose, 2=debug)

    Returns:
        Dictionary with run_id, run_url, and job_run_name

    Raises:
        ValueError: If YAML validation fails (exit code 2)
        RuntimeError: If job submission fails (exit code 1)
    """
    # Setup authentication if provided
    if workspace_host or profile:
        _setup_auth(workspace_host=workspace_host, profile=profile)

    # Create argparse.Namespace to match CLI expectations
    args = argparse.Namespace(
        file=Path(yaml_path),
        override=overrides or [],
        profile=profile,
        watch=watch,
        verbose=verbose,
        run_system_checks=False,
        dry_run=False,
        email=None,
        image_policy="auto",
        image_timeout=900,
        no_interpolation=None,
        json=None,
    )

    # Capture the result by intercepting JobsApiClient.create_workload
    captured_result = {}

    original_create_workload = JobsApiClient.create_workload

    def patched_create_workload(self, *args, **kwargs):
        result = original_create_workload(self, *args, **kwargs)
        captured_result.update(result)
        return result

    try:
        JobsApiClient.create_workload = patched_create_workload
        exit_code = cli_entrypoint.handle_run(args)
    finally:
        JobsApiClient.create_workload = original_create_workload

    if exit_code == 2:
        raise ValueError("YAML validation failed")
    elif exit_code != 0:
        raise RuntimeError(f"Job submission failed with exit code {exit_code}")

    return captured_result


def get_status(
    run_id: str,
    workspace_host: Optional[str] = None,
    profile: Optional[str] = None,
) -> Dict:
    """Get current status of a job.

    Args:
        run_id: Job run ID
        workspace_host: Optional workspace URL
        profile: Optional Databricks profile name

    Returns:
        Dictionary with run_id, state, tasks, etc.

    Raises:
        ValueError: If run not found
        RuntimeError: If status retrieval fails
    """
    # Setup authentication if provided
    if workspace_host or profile:
        _setup_auth(workspace_host=workspace_host, profile=profile)

    # Create argparse.Namespace to match CLI expectations
    args = argparse.Namespace(
        run_id=run_id,
        verbose=0,
        watch=False,
        profile=profile,
        json=None,
    )

    # Capture the status by intercepting JobsApiClient.get_workload_status
    captured_status = {}

    original_get_workload_status = JobsApiClient.get_workload_status

    def patched_get_workload_status(self, workload_id: str):
        result = original_get_workload_status(self, workload_id)
        captured_status.update(result)
        return result

    try:
        JobsApiClient.get_workload_status = patched_get_workload_status
        exit_code = cli_entrypoint.handle_status(args)
    finally:
        JobsApiClient.get_workload_status = original_get_workload_status

    if exit_code != 0:
        error_str = str(captured_status.get("error", ""))
        if "not found" in error_str.lower():
            raise ValueError(f"Run {run_id} not found")
        raise RuntimeError(f"Failed to get status for run {run_id}")

    return captured_status


def get_logs(
    run_id: str,
    node: int = 0,
    local_rank: int = 0,
    workspace_host: Optional[str] = None,
    profile: Optional[str] = None,
) -> Optional[str]:
    """Get logs from a completed or running job.

    Args:
        run_id: Job run ID
        node: Node number (default: 0)
        local_rank: Local rank on node (default: 0)
        workspace_host: Optional workspace URL
        profile: Optional Databricks profile name

    Returns:
        Log contents as string, or None if not available

    Raises:
        RuntimeError: If log retrieval fails
    """
    # Setup authentication if provided
    if workspace_host or profile:
        _setup_auth(workspace_host=workspace_host, profile=profile)

    # Create argparse.Namespace to match CLI expectations
    args = argparse.Namespace(
        run_id=run_id,
        node=node,
        local_rank=local_rank,
        lines=None,
        debug=False,
        verbose=0,
        profile=profile,
        json=None,
    )

    # For completed jobs, we need to capture the logs output
    # The handle_logs function prints to stdout, so we'll call it
    # but capture what it would have printed
    import io
    import sys

    captured_output = io.StringIO()
    old_stdout = sys.stdout

    try:
        sys.stdout = captured_output
        exit_code = cli_entrypoint.handle_logs(args)
        sys.stdout = old_stdout
    except Exception as e:
        sys.stdout = old_stdout
        raise RuntimeError(f"Failed to get logs: {e}") from e

    if exit_code != 0:
        return None

    return captured_output.getvalue()


def do_cancel(
    run_id: str,
    workspace_host: Optional[str] = None,
    profile: Optional[str] = None,
) -> bool:
    """Cancel a running job.

    Args:
        run_id: Job run ID
        workspace_host: Optional workspace URL
        profile: Optional Databricks profile name

    Returns:
        True if cancellation accepted, False otherwise
    """
    # Setup authentication if provided
    if workspace_host or profile:
        _setup_auth(workspace_host=workspace_host, profile=profile)

    # Create argparse.Namespace to match CLI expectations
    args = argparse.Namespace(
        run_id=run_id,
        verbose=0,
        profile=profile,
        json=None,
    )

    try:
        exit_code = cli_entrypoint.handle_cancel(args)
        return exit_code == 0
    except Exception:
        # Don't raise - just return False for compatibility
        return False
