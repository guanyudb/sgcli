"""Version and changelog utilities for cli package."""

import sys

if sys.version_info >= (3, 9):
    from importlib.resources import files
else:
    # Fallback for Python 3.8
    try:
        from importlib_resources import files
    except ImportError:
        files = None


def get_changelog() -> str:
    """Get the changelog content from the installed package.

    Returns only the changelog entries starting from the "Start of CLI Changelog" marker,
    excluding the instructions section.

    Returns:
        The changelog as a string, or an error message if unavailable.

    Example:
        >>> from cli.version import get_changelog
        >>> changelog = get_changelog()
        >>> print(changelog)
    """
    try:
        if files is not None:
            changelog_file = files("cli").joinpath("changelog.md")
            full_content = changelog_file.read_text()
        else:
            # Fallback using pkg_resources
            import pkg_resources

            full_content = pkg_resources.resource_string("cli", "changelog.md").decode("utf-8")

        # Extract only the content after "Start of CLI Changelog"
        marker = "Start of CLI Changelog"
        if marker in full_content:
            return full_content.split(marker, 1)[1].strip()
        return full_content

    except (FileNotFoundError, ModuleNotFoundError, KeyError) as e:
        return f"Changelog not available: {e}"
